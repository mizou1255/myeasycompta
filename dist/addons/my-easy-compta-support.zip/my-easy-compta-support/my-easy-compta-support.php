<?php
/**
 * Plugin Name: myEasyCompta — Support Tickets
 * Description: Gestion des tickets de support soumis via le dashboard client myEasyCompta.
 * Version:     1.0.0
 * Author:      myEasyCompta
 * Text Domain: mec-support
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'MEC_SUPPORT_VERSION', '1.0.0' );
define( 'MEC_SUPPORT_PATH',    plugin_dir_path( __FILE__ ) );
define( 'MEC_SUPPORT_URL',     plugin_dir_url( __FILE__ ) );

add_action( 'admin_menu', 'mec_support_register_menu' );
add_action( 'admin_enqueue_scripts', 'mec_support_enqueue' );
add_action( 'wp_ajax_mec_support_reply', 'mec_support_handle_reply' );
add_action( 'wp_ajax_mec_support_status', 'mec_support_handle_status' );
add_action( 'wp_ajax_mec_support_list', 'mec_support_handle_list' );

// ── Menu ──────────────────────────────────────────────────────────────────────

function mec_support_register_menu(): void {
    add_menu_page(
        'Support Tickets',
        'Support MEC',
        'manage_options',
        'mec-support',
        'mec_support_render_page',
        'dashicons-tickets-alt',
        58
    );
}

// ── Assets ────────────────────────────────────────────────────────────────────

function mec_support_enqueue( string $hook ): void {
    if ( $hook !== 'toplevel_page_mec-support' ) return;
    wp_enqueue_style( 'mec-support-css', MEC_SUPPORT_URL . 'assets/support.css', [], MEC_SUPPORT_VERSION );
}

// ── AJAX: List tickets ────────────────────────────────────────────────────────

function mec_support_handle_list(): void {
    check_ajax_referer( 'mec_support_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( [], 403 );

    global $wpdb;
    $table  = $wpdb->prefix . 'mec_tickets';
    $status = sanitize_key( $_POST['status'] ?? '' );
    $search = sanitize_text_field( $_POST['search'] ?? '' );
    $page   = max( 1, (int) ( $_POST['page'] ?? 1 ) );
    $per    = 20;
    $offset = ( $page - 1 ) * $per;

    $where = '1=1';
    $vals  = [];

    if ( $status ) {
        $where .= ' AND status = %s';
        $vals[] = $status;
    }
    if ( $search ) {
        $s      = '%' . $wpdb->esc_like( $search ) . '%';
        $where .= ' AND (license_key LIKE %s OR email LIKE %s OR subject LIKE %s)';
        $vals   = array_merge( $vals, [ $s, $s, $s ] );
    }

    $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
    $total     = (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $count_sql, $vals ) ) : $wpdb->get_var( $count_sql ) );

    $sql     = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";
    $q_vals  = array_merge( $vals, [ $per, $offset ] );
    $tickets = $wpdb->get_results( $wpdb->prepare( $sql, $q_vals ), ARRAY_A ) ?: [];

    wp_send_json_success( [ 'tickets' => $tickets, 'total' => $total, 'pages' => (int) ceil( $total / $per ) ] );
}

// ── AJAX: Reply to ticket ─────────────────────────────────────────────────────

function mec_support_handle_reply(): void {
    check_ajax_referer( 'mec_support_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( [], 403 );

    global $wpdb;
    $table  = $wpdb->prefix . 'mec_tickets';
    $id     = absint( $_POST['ticket_id'] ?? 0 );
    $reply  = sanitize_textarea_field( $_POST['reply'] ?? '' );

    if ( ! $id || ! $reply ) {
        wp_send_json_error( [ 'message' => 'Paramètres manquants.' ], 400 );
    }

    $ticket = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
    if ( ! $ticket ) wp_send_json_error( [ 'message' => 'Ticket introuvable.' ], 404 );

    $wpdb->update( $table, [
        'admin_reply' => $reply,
        'replied_at'  => current_time( 'mysql' ),
        'status'      => 'closed',
    ], [ 'id' => $id ] );

    // Email the customer
    $site = get_bloginfo( 'name' ) ?: 'myEasyCompta';
    wp_mail(
        $ticket->email,
        '[' . $site . '] Réponse à votre ticket #' . $id . ' — ' . $ticket->subject,
        mec_support_reply_email( $ticket, $reply ),
        [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $site . ' <' . get_option( 'admin_email' ) . '>',
        ]
    );

    wp_send_json_success( [ 'message' => 'Réponse envoyée et ticket clôturé.' ] );
}

// ── AJAX: Update ticket status ────────────────────────────────────────────────

function mec_support_handle_status(): void {
    check_ajax_referer( 'mec_support_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( [], 403 );

    global $wpdb;
    $table  = $wpdb->prefix . 'mec_tickets';
    $id     = absint( $_POST['ticket_id'] ?? 0 );
    $status = sanitize_key( $_POST['status'] ?? '' );

    if ( ! $id || ! in_array( $status, [ 'open', 'closed', 'pending' ], true ) ) {
        wp_send_json_error( [ 'message' => 'Paramètres invalides.' ], 400 );
    }

    $wpdb->update( $table, [ 'status' => $status ], [ 'id' => $id ] );
    wp_send_json_success();
}

// ── Email template ────────────────────────────────────────────────────────────

function mec_support_reply_email( object $ticket, string $reply ): string {
    $site = esc_html( get_bloginfo( 'name' ) ?: 'myEasyCompta' );
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="font-family:\'Inter\',Arial,sans-serif;background:#0f0a1e;margin:0;padding:32px">
<div style="max-width:560px;margin:0 auto">
  <div style="background:linear-gradient(135deg,#7c3aed,#4f46e5);padding:24px 32px;border-radius:16px 16px 0 0">
    <p style="color:rgba(255,255,255,0.6);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.15em;margin:0 0 4px">⚡ ' . $site . '</p>
    <h1 style="color:#fff;font-size:20px;font-weight:900;margin:0">Réponse à votre ticket #' . (int) $ticket->id . '</h1>
  </div>
  <div style="background:#13102b;padding:28px 32px;border-radius:0 0 16px 16px;border:1px solid rgba(124,58,237,0.2);border-top:none">
    <p style="color:#94a3b8;font-size:13px;margin:0 0 16px">Sujet : <strong style="color:#fff">' . esc_html( $ticket->subject ) . '</strong></p>
    <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:16px 20px;margin-bottom:20px">
      <p style="color:#6b7280;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.15em;margin:0 0 8px">Votre message</p>
      <p style="color:#94a3b8;font-size:13px;line-height:1.7;margin:0">' . nl2br( esc_html( $ticket->message ) ) . '</p>
    </div>
    <div style="background:rgba(124,58,237,0.08);border:1px solid rgba(124,58,237,0.25);border-radius:12px;padding:16px 20px;margin-bottom:20px">
      <p style="color:#a78bfa;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.15em;margin:0 0 8px">Réponse du support</p>
      <p style="color:#e2e8f0;font-size:13px;line-height:1.7;margin:0">' . nl2br( esc_html( $reply ) ) . '</p>
    </div>
    <p style="color:#4b5563;font-size:11px;text-align:center;margin:0">Si vous avez d\'autres questions, soumettez un nouveau ticket depuis votre espace client.</p>
  </div>
</div>
</body></html>';
}

// ── Admin page ────────────────────────────────────────────────────────────────

function mec_support_render_page(): void {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $nonce = wp_create_nonce( 'mec_support_nonce' );
    ?>
    <style>
    :root { --sp-purple:#7c3aed; --sp-purple-h:#6d28d9; --sp-bg:#f8fafc; --sp-card:#fff; --sp-border:#e2e8f0; --sp-text:#1e293b; --sp-muted:#64748b; }
    body.admin-color-fresh { background:var(--sp-bg); }
    #mec-support { max-width:1100px; margin:24px auto; font-family:'Inter',-apple-system,sans-serif; color:var(--sp-text); }
    .sp-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:24px; }
    .sp-title { font-size:22px; font-weight:900; letter-spacing:-.5px; margin:0; }
    .sp-stats { display:flex; gap:12px; }
    .sp-stat { background:var(--sp-card); border:1px solid var(--sp-border); border-radius:12px; padding:12px 18px; text-align:center; min-width:80px; }
    .sp-stat strong { display:block; font-size:22px; font-weight:900; color:var(--sp-purple); }
    .sp-stat span { font-size:11px; color:var(--sp-muted); font-weight:600; }
    .sp-toolbar { display:flex; gap:10px; margin-bottom:16px; flex-wrap:wrap; align-items:center; }
    .sp-toolbar input, .sp-toolbar select { padding:9px 14px; border:2px solid var(--sp-border); border-radius:10px; font-size:13px; background:#fff; color:var(--sp-text); outline:none; transition:.2s; }
    .sp-toolbar input:focus, .sp-toolbar select:focus { border-color:var(--sp-purple); }
    .sp-btn { display:inline-flex; align-items:center; gap:6px; padding:9px 18px; border-radius:10px; font-size:13px; font-weight:700; border:none; cursor:pointer; transition:.2s; font-family:inherit; }
    .sp-btn-primary { background:var(--sp-purple); color:#fff; }
    .sp-btn-primary:hover { background:var(--sp-purple-h); }
    .sp-btn-sm { padding:5px 12px; font-size:12px; }
    .sp-btn-ghost { background:#f1f5f9; color:#475569; border:1px solid var(--sp-border); }
    .sp-btn-ghost:hover { background:var(--sp-border); }
    .sp-btn-danger { background:#fee2e2; color:#dc2626; border:1px solid #fecaca; }
    .sp-table-wrap { background:var(--sp-card); border:1px solid var(--sp-border); border-radius:16px; overflow:hidden; }
    table.sp-table { width:100%; border-collapse:collapse; }
    .sp-table thead tr { background:#f1f5f9; }
    .sp-table th { padding:12px 16px; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:var(--sp-muted); text-align:left; border-bottom:1px solid var(--sp-border); }
    .sp-table td { padding:14px 16px; font-size:13px; border-bottom:1px solid #f8fafc; vertical-align:top; }
    .sp-table tr:last-child td { border-bottom:none; }
    .sp-table tr:hover td { background:#fafbff; }
    .sp-badge { display:inline-flex; align-items:center; gap:4px; padding:3px 10px; border-radius:99px; font-size:11px; font-weight:700; }
    .sp-badge-open { background:#dcfce7; color:#166534; }
    .sp-badge-closed { background:#f1f5f9; color:#64748b; }
    .sp-badge-pending { background:#fef9c3; color:#854d0e; }
    .sp-empty { text-align:center; padding:60px 20px; color:var(--sp-muted); }
    .sp-pagination { display:flex; align-items:center; gap:8px; justify-content:flex-end; margin-top:16px; }
    .sp-modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:9999; align-items:center; justify-content:center; }
    .sp-modal-overlay.open { display:flex; }
    .sp-modal { background:#fff; border-radius:20px; padding:32px; max-width:620px; width:90%; max-height:90vh; overflow-y:auto; box-shadow:0 25px 60px rgba(0,0,0,0.25); }
    .sp-modal h3 { font-size:18px; font-weight:800; margin:0 0 20px; }
    .sp-field { margin-bottom:16px; }
    .sp-field label { display:block; font-size:12px; font-weight:700; color:var(--sp-muted); margin-bottom:6px; text-transform:uppercase; letter-spacing:.06em; }
    .sp-field textarea { width:100%; padding:12px 14px; border:2px solid var(--sp-border); border-radius:12px; font-size:13px; font-family:inherit; min-height:120px; resize:vertical; outline:none; transition:.2s; box-sizing:border-box; }
    .sp-field textarea:focus { border-color:var(--sp-purple); }
    .sp-field .sp-msg-box { background:#f8fafc; border:1px solid var(--sp-border); border-radius:10px; padding:12px 14px; font-size:13px; color:#475569; line-height:1.6; white-space:pre-wrap; }
    .sp-meta { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px; }
    .sp-meta-item { background:#f8fafc; border:1px solid var(--sp-border); border-radius:10px; padding:10px 14px; }
    .sp-meta-item small { display:block; font-size:10px; font-weight:700; color:var(--sp-muted); text-transform:uppercase; letter-spacing:.06em; margin-bottom:3px; }
    .sp-meta-item strong { font-size:13px; color:var(--sp-text); word-break:break-all; }
    .sp-modal-footer { display:flex; gap:10px; justify-content:flex-end; margin-top:20px; }
    .sp-reply-section { background:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; padding:16px; margin-bottom:16px; }
    .sp-reply-section h4 { font-size:12px; font-weight:700; color:#166534; text-transform:uppercase; letter-spacing:.06em; margin:0 0 8px; }
    .sp-reply-section p { font-size:13px; color:#166534; line-height:1.6; margin:0; white-space:pre-wrap; }
    </style>

    <div id="mec-support">
      <div class="sp-header">
        <h1 class="sp-title">🎫 Tickets de support</h1>
        <div class="sp-stats" id="sp-stats"></div>
      </div>

      <div class="sp-toolbar">
        <input type="text" id="sp-search" placeholder="Rechercher (email, clé, sujet)…" style="flex:1;min-width:200px">
        <select id="sp-filter-status">
          <option value="">Tous les statuts</option>
          <option value="open">Ouvert</option>
          <option value="pending">En attente</option>
          <option value="closed">Clôturé</option>
        </select>
        <button class="sp-btn sp-btn-primary" id="sp-refresh-btn">🔄 Actualiser</button>
      </div>

      <div class="sp-table-wrap">
        <table class="sp-table">
          <thead>
            <tr>
              <th style="width:50px">#</th>
              <th>Sujet</th>
              <th>Email</th>
              <th style="width:140px">Clé de licence</th>
              <th style="width:90px">Statut</th>
              <th style="width:130px">Date</th>
              <th style="width:100px">Actions</th>
            </tr>
          </thead>
          <tbody id="sp-tbody">
            <tr><td colspan="7" class="sp-empty">Chargement…</td></tr>
          </tbody>
        </table>
      </div>

      <div class="sp-pagination" id="sp-pagination"></div>
    </div>

    <!-- Modal -->
    <div class="sp-modal-overlay" id="sp-modal">
      <div class="sp-modal">
        <h3 id="sp-modal-title">Ticket #—</h3>
        <div id="sp-modal-body"></div>
        <div class="sp-modal-footer">
          <button class="sp-btn sp-btn-ghost" id="sp-modal-close">Fermer</button>
          <button class="sp-btn sp-btn-primary" id="sp-modal-send" style="display:none">✉️ Envoyer la réponse</button>
        </div>
      </div>
    </div>

    <script>
    (function(){
      const nonce = <?php echo wp_json_encode( $nonce ); ?>;
      const ajaxUrl = <?php echo wp_json_encode( admin_url('admin-ajax.php') ); ?>;
      let currentPage = 1, currentTicket = null;

      function badge(status){
        const map = { open:'sp-badge-open', closed:'sp-badge-closed', pending:'sp-badge-pending' };
        const lab = { open:'Ouvert', closed:'Clôturé', pending:'En attente' };
        return `<span class="sp-badge ${map[status]||''}">${lab[status]||status}</span>`;
      }

      function fmtDate(d){
        if(!d) return '—';
        return new Date(d).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
      }

      function ajax(action, data){
        return fetch(ajaxUrl, {
          method:'POST',
          headers:{'Content-Type':'application/x-www-form-urlencoded'},
          body: new URLSearchParams({action, nonce, ...data})
        }).then(r=>r.json());
      }

      function loadTickets(){
        const status = document.getElementById('sp-filter-status').value;
        const search = document.getElementById('sp-search').value;
        ajax('mec_support_list', {status, search, page: currentPage}).then(res=>{
          if(!res.success) return;
          const { tickets, total, pages } = res.data;

          // Stats
          document.getElementById('sp-stats').innerHTML = `
            <div class="sp-stat"><strong>${total}</strong><span>Total</span></div>
            <div class="sp-stat"><strong>${tickets.filter(t=>t.status==='open').length}</strong><span>Ouverts</span></div>
          `;

          const tbody = document.getElementById('sp-tbody');
          if(!tickets.length){
            tbody.innerHTML = '<tr><td colspan="7" class="sp-empty">Aucun ticket trouvé.</td></tr>';
          } else {
            tbody.innerHTML = tickets.map(t => `
              <tr>
                <td><strong>#${t.id}</strong></td>
                <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${t.subject}">${t.subject}</td>
                <td style="font-size:12px;color:#64748b">${t.email}</td>
                <td><code style="font-size:10px;background:#f1f5f9;padding:2px 6px;border-radius:4px">${t.license_key}</code></td>
                <td>${badge(t.status)}</td>
                <td style="font-size:11px;color:#94a3b8">${fmtDate(t.created_at)}</td>
                <td>
                  <button class="sp-btn sp-btn-ghost sp-btn-sm sp-view-btn" data-id="${t.id}">Voir</button>
                </td>
              </tr>
            `).join('');
          }

          // Pagination
          const pg = document.getElementById('sp-pagination');
          if(pages > 1){
            pg.innerHTML = Array.from({length: pages},(_,i)=>
              `<button class="sp-btn sp-btn-sm ${i+1===currentPage?'sp-btn-primary':'sp-btn-ghost'}" data-pg="${i+1}">${i+1}</button>`
            ).join('');
            pg.querySelectorAll('[data-pg]').forEach(b=>b.addEventListener('click',()=>{
              currentPage = +b.dataset.pg; loadTickets();
            }));
          } else { pg.innerHTML = ''; }

          tbody.querySelectorAll('.sp-view-btn').forEach(b=>b.addEventListener('click',()=>{
            openModal(tickets.find(t=>t.id==b.dataset.id));
          }));
        });
      }

      function openModal(ticket){
        currentTicket = ticket;
        document.getElementById('sp-modal-title').textContent = `Ticket #${ticket.id} — ${ticket.subject}`;
        const hasReply = !!ticket.admin_reply;
        document.getElementById('sp-modal-body').innerHTML = `
          <div class="sp-meta">
            <div class="sp-meta-item"><small>Email</small><strong>${ticket.email}</strong></div>
            <div class="sp-meta-item"><small>Clé de licence</small><strong>${ticket.license_key}</strong></div>
            <div class="sp-meta-item"><small>Statut</small><strong>${badge(ticket.status)}</strong></div>
            <div class="sp-meta-item"><small>Date</small><strong style="font-size:12px">${fmtDate(ticket.created_at)}</strong></div>
          </div>
          <div class="sp-field">
            <label>Message du client</label>
            <div class="sp-msg-box">${ticket.message}</div>
          </div>
          ${hasReply ? `<div class="sp-reply-section"><h4>✅ Réponse envoyée le ${fmtDate(ticket.replied_at)}</h4><p>${ticket.admin_reply}</p></div>` : ''}
          <div class="sp-field" id="sp-reply-field" ${hasReply?'style="display:none"':''}>
            <label>Votre réponse</label>
            <textarea id="sp-reply-text" placeholder="Rédigez votre réponse…"></textarea>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:4px">
            ${hasReply?`<button class="sp-btn sp-btn-ghost sp-btn-sm" id="sp-reopen-btn">✏️ Modifier la réponse</button>`:''}
            ${ticket.status==='closed'?`<button class="sp-btn sp-btn-ghost sp-btn-sm" id="sp-reopen-status">🔄 Rouvrir</button>`:`<button class="sp-btn sp-btn-ghost sp-btn-sm" id="sp-close-status">✓ Clôturer sans réponse</button>`}
          </div>
        `;

        document.getElementById('sp-modal-send').style.display = hasReply ? 'none' : '';

        const reopenBtn = document.getElementById('sp-reopen-btn');
        if(reopenBtn) reopenBtn.addEventListener('click',()=>{
          document.getElementById('sp-reply-field').style.display='';
          document.getElementById('sp-modal-send').style.display='';
          reopenBtn.style.display='none';
        });

        const reopenStatus = document.getElementById('sp-reopen-status');
        if(reopenStatus) reopenStatus.addEventListener('click',()=>{
          ajax('mec_support_status',{ticket_id:ticket.id,status:'open'}).then(()=>{
            closeModal(); loadTickets();
          });
        });

        const closeStatus = document.getElementById('sp-close-status');
        if(closeStatus) closeStatus.addEventListener('click',()=>{
          ajax('mec_support_status',{ticket_id:ticket.id,status:'closed'}).then(()=>{
            closeModal(); loadTickets();
          });
        });

        document.getElementById('sp-modal').classList.add('open');
      }

      function closeModal(){
        document.getElementById('sp-modal').classList.remove('open');
        currentTicket = null;
      }

      document.getElementById('sp-modal-close').addEventListener('click', closeModal);
      document.getElementById('sp-modal').addEventListener('click', e=>{
        if(e.target === document.getElementById('sp-modal')) closeModal();
      });

      document.getElementById('sp-modal-send').addEventListener('click',()=>{
        if(!currentTicket) return;
        const reply = document.getElementById('sp-reply-text').value.trim();
        if(!reply){ alert('La réponse ne peut pas être vide.'); return; }
        const btn = document.getElementById('sp-modal-send');
        btn.disabled = true; btn.textContent = 'Envoi…';
        ajax('mec_support_reply',{ticket_id:currentTicket.id,reply}).then(res=>{
          if(res.success){ closeModal(); loadTickets(); }
          else { alert(res.data?.message || 'Erreur.'); btn.disabled=false; btn.textContent='✉️ Envoyer la réponse'; }
        });
      });

      document.getElementById('sp-refresh-btn').addEventListener('click',()=>{ currentPage=1; loadTickets(); });
      document.getElementById('sp-filter-status').addEventListener('change',()=>{ currentPage=1; loadTickets(); });

      let searchTimer;
      document.getElementById('sp-search').addEventListener('input',()=>{
        clearTimeout(searchTimer);
        searchTimer = setTimeout(()=>{ currentPage=1; loadTickets(); }, 400);
      });

      loadTickets();
    })();
    </script>
    <?php
}
