<?php

namespace ECWP\Addon\Delivery;

use ECWP\API\Routes;

/**
 * Delivery Notes REST endpoints.
 *
 * GET    /delivery-notes                  list (paginated)
 * POST   /delivery-notes                  create
 * GET    /delivery-notes/{id}             single
 * PUT    /delivery-notes/{id}             update
 * DELETE /delivery-notes/{id}             delete
 * GET    /delivery-notes/{id}/pdf         download PDF
 * POST   /delivery-notes/from-invoice/{id} auto-create from invoice items
 */
class ECWP_Delivery
{
    public function __construct()
    {
        $routes = new Routes();
        $auth   = fn () => current_user_can('manage_options');

        $routes->add_route('/delivery-notes',                              'GET',    $this, 'get_notes',          $auth);
        $routes->add_route('/delivery-notes',                              'POST',   $this, 'add_note',           $auth);
        $routes->add_route('/delivery-notes/from-invoice/(?P<id>\d+)',    'POST',   $this, 'create_from_invoice', $auth);
        $routes->add_route('/delivery-notes/(?P<id>\d+)',                  'GET',    $this, 'get_note',           $auth);
        $routes->add_route('/delivery-notes/(?P<id>\d+)',                  'PUT',    $this, 'update_note',        $auth);
        $routes->add_route('/delivery-notes/(?P<id>\d+)',                  'DELETE', $this, 'delete_note',        $auth);
        $routes->add_route('/delivery-notes/(?P<id>\d+)/pdf',             'GET',    $this, 'download_pdf',       $auth);
        $routes->register_routes();
    }

    // ── List ─────────────────────────────────────────────────────────────────

    public function get_notes($request)
    {
        global $wpdb;

        $per_page  = max(1, (int) ($request->get_param('per_page') ?: 20));
        $page      = max(1, (int) ($request->get_param('page')     ?: 1));
        $offset    = ($page - 1) * $per_page;
        $status    = $request->get_param('status');
        $search    = $request->get_param('search');

        $where  = 'WHERE 1=1';
        $params = [];

        if ($status && in_array($status, ['draft', 'sent', 'delivered'], true)) {
            $where   .= ' AND d.status = %s';
            $params[] = $status;
        }
        if ($search) {
            $where   .= ' AND (d.delivery_number LIKE %s OR c.company_name LIKE %s)';
            $like     = '%' . $wpdb->esc_like(sanitize_text_field($search)) . '%';
            $params[] = $like;
            $params[] = $like;
        }

        $count_sql = "SELECT COUNT(*) FROM " . ECWP_TABLE_DELIVERY_NOTES . " d
                      LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON c.id = d.client_id $where";
        $total = (int) ($params ? $wpdb->get_var($wpdb->prepare($count_sql, ...$params)) : $wpdb->get_var($count_sql));

        $rows_sql = "SELECT d.*, c.company_name AS client_name, c.address AS client_address
                     FROM " . ECWP_TABLE_DELIVERY_NOTES . " d
                     LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON c.id = d.client_id
                     $where
                     ORDER BY d.created_at DESC
                     LIMIT %d OFFSET %d";

        $rows = $wpdb->get_results(
            $wpdb->prepare($rows_sql, ...[...$params, $per_page, $offset]),
            ARRAY_A
        );

        return ['data' => $rows ?: [], 'total' => $total, 'per_page' => $per_page, 'page' => $page, 'last_page' => (int) ceil($total / $per_page)];
    }

    // ── Single ───────────────────────────────────────────────────────────────

    public function get_note($request)
    {
        $row = $this->fetch((int) $request->get_param('id'));
        return $row ?: new \WP_Error('not_found', 'Bon introuvable.', ['status' => 404]);
    }

    // ── Create ────────────────────────────────────────────────────────────────

    public function add_note($request)
    {
        global $wpdb;
        $data = $this->sanitize($request);
        if (is_wp_error($data)) return $data;

        if (empty($data['delivery_number'])) {
            $data['delivery_number'] = $this->generate_number();
        }

        $wpdb->insert(ECWP_TABLE_DELIVERY_NOTES, $data, $this->formats($data));
        if ($wpdb->last_error) return new \WP_Error('db_error', $wpdb->last_error, ['status' => 500]);

        return $this->fetch($wpdb->insert_id);
    }

    // ── Auto-create from invoice ──────────────────────────────────────────────

    public function create_from_invoice($request)
    {
        global $wpdb;

        $invoice_id = (int) $request->get_param('id');

        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT i.*, c.id AS cid, c.company_name, c.address
             FROM " . ECWP_TABLE_INVOICES . " i
             LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON c.id = i.client_id
             WHERE i.id = %d", $invoice_id
        ), ARRAY_A);

        if (!$invoice) return new \WP_Error('not_found', 'Facture introuvable.', ['status' => 404]);

        // Fetch invoice items for notes
        $items = $wpdb->get_results($wpdb->prepare(
            "SELECT description, quantity FROM " . ECWP_TABLE_INVOICE_ELEMENTS . " WHERE invoice_id = %d", $invoice_id
        ), ARRAY_A);

        $notes_text = '';
        foreach ($items as $item) {
            $notes_text .= "- {$item['description']} (qté: {$item['quantity']})\n";
        }

        $data = [
            'invoice_id'       => $invoice_id,
            'client_id'        => $invoice['client_id'],
            'delivery_number'  => $this->generate_number(),
            'delivery_date'    => current_time('Y-m-d'),
            'notes'            => trim($notes_text),
            'delivery_address' => $invoice['address'] ?? '',
            'status'           => 'draft',
        ];

        $wpdb->insert(ECWP_TABLE_DELIVERY_NOTES, $data);
        return $this->fetch($wpdb->insert_id);
    }

    // ── Update ────────────────────────────────────────────────────────────────

    public function update_note($request)
    {
        global $wpdb;
        $id = (int) $request->get_param('id');
        if (!$this->fetch($id)) return new \WP_Error('not_found', 'Bon introuvable.', ['status' => 404]);

        $data = $this->sanitize($request);
        if (is_wp_error($data)) return $data;

        // Auto-set delivered_at
        if (($data['status'] ?? '') === 'delivered') {
            $data['delivered_at'] = current_time('mysql');
        }

        $wpdb->update(ECWP_TABLE_DELIVERY_NOTES, $data, ['id' => $id], $this->formats($data), ['%d']);
        return $this->fetch($id);
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    public function delete_note($request)
    {
        global $wpdb;
        $id = (int) $request->get_param('id');
        $ok = $wpdb->delete(ECWP_TABLE_DELIVERY_NOTES, ['id' => $id], ['%d']);
        return $ok ? ['success' => true] : new \WP_Error('not_found', 'Bon introuvable.', ['status' => 404]);
    }

    // ── PDF ───────────────────────────────────────────────────────────────────

    public function download_pdf($request)
    {
        $id   = (int) $request->get_param('id');
        $note = $this->fetch($id);
        if (!$note) return new \WP_Error('not_found', 'Bon introuvable.', ['status' => 404]);

        $html = $this->render_pdf($note);

        if (!class_exists('\Mpdf\Mpdf')) {
            $fname = 'BL-' . $note['delivery_number'] . '.html';
            header('Content-Type: text/html; charset=UTF-8');
            header('Content-Disposition: attachment; filename="' . $fname . '"');
            echo $html; // phpcs:ignore
            exit;
        }

        try {
            $mpdf = new \Mpdf\Mpdf(['margin_top' => 15, 'margin_bottom' => 15, 'margin_left' => 15, 'margin_right' => 15]);
            $mpdf->SetTitle('Bon de livraison ' . $note['delivery_number']);
            $mpdf->WriteHTML($html);
            $fname = 'BL-' . sanitize_file_name($note['delivery_number']) . '.pdf';
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $fname . '"');
            $mpdf->Output($fname, 'D');
            exit;
        } catch (\Exception $e) {
            return new \WP_Error('pdf_error', $e->getMessage(), ['status' => 500]);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function fetch(int $id): ?array
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT d.*, c.company_name AS client_name, c.address AS client_address, c.email AS client_email
             FROM " . ECWP_TABLE_DELIVERY_NOTES . " d
             LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON c.id = d.client_id
             WHERE d.id = %d", $id
        ), ARRAY_A);
        return $row ?: null;
    }

    private function sanitize($request): array|\WP_Error
    {
        $date = sanitize_text_field($request->get_param('delivery_date') ?: current_time('Y-m-d'));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return new \WP_Error('invalid_date', 'Date invalide.', ['status' => 400]);
        }
        $status = sanitize_text_field($request->get_param('status') ?: 'draft');
        if (!in_array($status, ['draft', 'sent', 'delivered'], true)) $status = 'draft';

        return [
            'invoice_id'       => $request->get_param('invoice_id')  ? (int) $request->get_param('invoice_id')  : null,
            'client_id'        => $request->get_param('client_id')   ? (int) $request->get_param('client_id')   : null,
            'delivery_number'  => sanitize_text_field($request->get_param('delivery_number') ?: ''),
            'delivery_date'    => $date,
            'notes'            => sanitize_textarea_field($request->get_param('notes') ?: ''),
            'delivery_address' => sanitize_textarea_field($request->get_param('delivery_address') ?: ''),
            'status'           => $status,
        ];
    }

    private function formats(array $data): array
    {
        $map = [
            'invoice_id' => '%d', 'client_id' => '%d', 'delivery_number' => '%s',
            'delivery_date' => '%s', 'notes' => '%s', 'delivery_address' => '%s',
            'status' => '%s', 'delivered_at' => '%s',
        ];
        return array_values(array_intersect_key($map, $data));
    }

    private function generate_number(): string
    {
        global $wpdb;
        $last = (int) ($wpdb->get_var("SELECT MAX(id) FROM " . ECWP_TABLE_DELIVERY_NOTES) ?: 0);
        return 'BL-' . str_pad($last + 1, 4, '0', STR_PAD_LEFT);
    }

    private function render_pdf(array $note): string
    {
        global $wpdb;

        // Company info from settings
        $get = fn($k) => (string) ($wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s", $k
        )) ?? '');

        $company  = $get('company_name');
        $address  = $get('company_address') . ' ' . $get('company_postal_code') . ' ' . $get('company_city');
        $siret    = $get('company_siren');

        $status_labels = ['draft' => 'Brouillon', 'sent' => 'Envoyé', 'delivered' => 'Livré'];
        $status_label  = $status_labels[$note['status']] ?? $note['status'];

        return '<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<style>
  body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 11px; color: #1e293b; }
  .header { display: flex; justify-content: space-between; margin-bottom: 32px; padding-bottom: 16px; border-bottom: 3px solid #4f46e5; }
  .company h1 { font-size: 20px; font-weight: 800; color: #4f46e5; margin: 0; }
  .company p { margin: 2px 0; color: #64748b; font-size: 10px; }
  .doc-title { text-align: right; }
  .doc-title h2 { font-size: 24px; font-weight: 800; color: #1e293b; margin: 0; }
  .doc-title p { color: #64748b; font-size: 10px; margin: 2px 0; }
  .parties { display: flex; gap: 40px; margin-bottom: 24px; }
  .party { flex: 1; background: #f8fafc; border-radius: 8px; padding: 12px; }
  .party h3 { font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.1em; color: #94a3b8; margin: 0 0 8px; }
  .party p { margin: 2px 0; font-weight: 600; }
  .notes-section { background: #f8fafc; border-radius: 8px; padding: 12px; margin-bottom: 24px; }
  .notes-section h3 { font-size: 9px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.1em; color: #94a3b8; margin: 0 0 8px; }
  .notes-section pre { font-family: inherit; margin: 0; white-space: pre-wrap; }
  .status-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 10px; font-weight: 800; background: #ede9fe; color: #4f46e5; }
  .footer { margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 12px; color: #94a3b8; font-size: 9px; text-align: center; }
  .signature-box { margin-top: 32px; border: 1px dashed #cbd5e1; border-radius: 8px; padding: 16px; text-align: center; color: #94a3b8; font-size: 10px; }
  .signature-box p { margin: 0; }
</style></head><body>
  <div class="header">
    <div class="company">
      <h1>' . esc_html($company) . '</h1>
      <p>' . esc_html($address) . '</p>
      ' . ($siret ? '<p>SIRET : ' . esc_html($siret) . '</p>' : '') . '
    </div>
    <div class="doc-title">
      <h2>BON DE LIVRAISON</h2>
      <p>N° ' . esc_html($note['delivery_number']) . '</p>
      <p>Date : ' . wp_date('d/m/Y', strtotime($note['delivery_date'])) . '</p>
      <p><span class="status-badge">' . esc_html($status_label) . '</span></p>
    </div>
  </div>

  <div class="parties">
    <div class="party">
      <h3>Expéditeur</h3>
      <p>' . esc_html($company) . '</p>
      <p>' . esc_html($address) . '</p>
    </div>
    <div class="party">
      <h3>Destinataire</h3>
      <p>' . esc_html($note['client_name'] ?? '') . '</p>
      <p>' . nl2br(esc_html($note['delivery_address'] ?: ($note['client_address'] ?? ''))) . '</p>
    </div>
  </div>

  ' . ($note['notes'] ? '<div class="notes-section"><h3>Articles / Prestations livrés</h3><pre>' . esc_html($note['notes']) . '</pre></div>' : '') . '

  <div class="signature-box">
    <p>Signature du destinataire</p>
    <br><br><br>
    <p>Date de réception : ___________________</p>
  </div>

  ' . ($note['invoice_id'] ? '<p style="margin-top:16px;font-size:10px;color:#94a3b8;">Facture liée : #' . (int) $note['invoice_id'] . '</p>' : '') . '

  <div class="footer">Document généré par myEasyCompta — ' . wp_date('d/m/Y H:i') . '</div>
</body></html>';
    }
}
