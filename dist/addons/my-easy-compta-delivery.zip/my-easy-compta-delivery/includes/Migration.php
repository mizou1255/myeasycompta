<?php

if (!defined('ABSPATH')) exit;

function ecwp_delivery_run_migration()
{
    global $wpdb;
    if (!defined('ECWP_TABLE_DELIVERY_NOTES')) return;

    $charset = $wpdb->get_charset_collate();
    $table   = ECWP_TABLE_DELIVERY_NOTES;

    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id                int(11)       NOT NULL AUTO_INCREMENT,
        invoice_id        int(11)       DEFAULT NULL,
        client_id         int(11)       DEFAULT NULL,
        delivery_number   varchar(50)   NOT NULL DEFAULT '',
        delivery_date     date          NOT NULL,
        notes             text,
        delivery_address  text,
        status            varchar(20)   NOT NULL DEFAULT 'draft' COMMENT 'draft|sent|delivered',
        delivered_at      datetime      DEFAULT NULL,
        created_at        datetime      NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at        datetime      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_invoice_id (invoice_id),
        KEY idx_client_id  (client_id),
        KEY idx_status     (status)
    ) {$charset};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    update_option('ecwp_delivery_db_version', '1.0.0');
}
