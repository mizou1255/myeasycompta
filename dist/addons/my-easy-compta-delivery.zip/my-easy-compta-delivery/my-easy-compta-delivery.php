<?php
/**
 * Plugin Name: myEasyCompta - Bons de livraison
 * Description: Générez des bons de livraison PDF liés à vos factures. Suivi des livraisons avec statut (brouillon, envoyé, livré). Indispensable pour artisans, commerçants et revendeurs.
 * Version: 1.0.0
 * Author: MELIOZ.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-delivery
 * Domain Path: /languages/
 * Requires at least: 6.2
 * Tested up to: 6.9
 * Requires PHP: 8.0
 * Requires Plugins: my-easy-compta
 * Tags: delivery, bon de livraison, pdf, invoices
 */

if (!defined('ABSPATH')) exit;

define('ECWP_DELIVERY_VERSION',  '1.0.0');
define('ECWP_DELIVERY_PATH',     plugin_dir_path(__FILE__));
define('ECWP_DELIVERY_URL',      plugins_url('', __FILE__));
define('ECWP_DELIVERY_INCLUDES', ECWP_DELIVERY_PATH . 'includes');

add_action('plugins_loaded', function () {
    if (!defined('ECWP_PREFIX')) return;
    if (!defined('ECWP_TABLE_DELIVERY_NOTES')) {
        define('ECWP_TABLE_DELIVERY_NOTES', ECWP_PREFIX . 'ecwp_delivery_notes');
    }
}, 5);

add_action('plugins_loaded', function () {
    if (!class_exists('ECWP_Easy_Compta')) return;

    require_once ECWP_DELIVERY_INCLUDES . '/Migration.php';
    require_once ECWP_DELIVERY_INCLUDES . '/Delivery.php';

    add_action('admin_init', 'ecwp_delivery_maybe_migrate');
    add_action('admin_enqueue_scripts', 'ecwp_delivery_enqueue');
    new ECWP\Addon\Delivery\ECWP_Delivery();
}, 20);

function ecwp_delivery_enqueue($hook)
{
    // deliveryAddonActive is now set by the core App.php with a proper license check.
    // Nothing to inject here.
}

function ecwp_delivery_maybe_migrate()
{
    if (get_option('ecwp_delivery_db_version') !== '1.0.0') {
        require_once ECWP_DELIVERY_INCLUDES . '/Migration.php';
        ecwp_delivery_run_migration();
    }
}

register_activation_hook(__FILE__, function () {
    if (!defined('ECWP_PREFIX')) { global $wpdb; define('ECWP_PREFIX', $wpdb->prefix); }
    if (!defined('ECWP_TABLE_DELIVERY_NOTES')) define('ECWP_TABLE_DELIVERY_NOTES', ECWP_PREFIX . 'ecwp_delivery_notes');
    require_once ECWP_DELIVERY_INCLUDES . '/Migration.php';
    ecwp_delivery_run_migration();
});
