<?php
/*
 * Template Name: myEasyCompta Dashboard
 * Template Post Type: page
 */

if (!defined('ABSPATH')) {
    exit;
}
if (!is_user_logged_in()) {
    $redirect_to = home_url('/login/');
    $login_page_id = get_option('easy_compta_login_id');
    if ($login_page_id) {
        $redirect_to = get_permalink($login_page_id);
    }
    wp_redirect($redirect_to);
    exit;
}
include_once ABSPATH . 'wp-admin/includes/plugin.php';
$is_easycompta_signature_active = is_plugin_active('my-easy-compta-signature/my-easy-compta-signature.php');

?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php wp_title(); ?></title>
    <?php // wp_head(); ?>
    <link rel="stylesheet" href="<?php echo esc_url(ECWP_USER_URL . '/assets/dist/app.min.css'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body <?php body_class(); ?>>
    <?php $license_data = get_option('ecwp_client_license_data');
    $license_key = get_option('ecwp_client_license_key');

    $plugin_exist = false;
    if (!empty($license_key)) {
        if (isset($license_data['plugins']) && is_array($license_data['plugins'])) {
            $license_plugins = $license_data['plugins'];

            $plugin_file = plugin_basename(__FILE__);
            $plugin_parts = explode('/', $plugin_file);
            $plugin_slug = $plugin_parts[0];

            foreach ($license_plugins as $p) {
                if ($plugin_slug === $p['product_slug']) {
                    $plugin_exist = true;
                    break; // Exit loop early if found
                }
            }
        }
        if (!$plugin_exist) {
            echo '<div class="admin-overlay">
                <div>
                    <p><strong>Licence requise</strong></p>
                    <p>Vous devez acheter une licence pour utiliser ce plugin. Veuillez <a href="' . esc_url(admin_url('admin.php?page=my-easy-compta#/settings?tab=16')) . '">ajouter votre clé de licence ici</a>.</p>
                    <p>Ce plugin ne peut pas être utilisé sans une licence valide.</p>
                </div>
            </div>';
            echo '<div id="my-easy-compta-user-app" class="ecwp-content blur-app"></div>';
        } else {
            echo '<div id="my-easy-compta-user-app"></div>';
        }
    } else {
        echo '<div class="admin-overlay">
                <div>
                    <p><strong>Licence requise</strong></p>
                    <p>Vous devez acheter une licence pour utiliser ce plugin. Veuillez <a href="' . esc_url(admin_url('admin.php?page=my-easy-compta#/settings?tab=16')) . '">ajouter votre clé de licence ici</a>.</p>
                    <p>Ce plugin ne peut pas être utilisé sans une licence valide.</p>
                </div>
            </div>';
        echo '<div id="my-easy-compta-user-app" class="ecwp-content blur-app"></div>';
    } ?>
    <?php require_once ECWP_PRINCIPAL_PATH . '/languages/my-easy-compta-translations.php'; ?>
    <script>
        var myEasyComptaUser = {
            'nonce': "<?php echo wp_create_nonce('wp_rest'); ?>",
            'easyComptaTranslations': <?php echo wp_json_encode($translations); ?>,
        };
    </script>
    <script src="<?php echo esc_url(ECWP_USER_URL . '/assets/dist/app.min.js'); ?>" type="module"></script>
    <?php wp_footer(); ?>
</body>

</html>