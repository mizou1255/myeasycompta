<?php
/*
 * Template Name: Login page
 * Template Post Type: page
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Vérifie si l'utilisateur est déjà connecté
if (is_user_logged_in()) {
    $redirect_to = home_url();

    $dashboard_page_id = get_option('easy_compta_dashboard_page_id');
    if ($dashboard_page_id) {
        $redirect_to = get_permalink($dashboard_page_id);
    }
    wp_redirect($redirect_to);
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    if (!isset($_POST['ecwp_login_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ecwp_login_nonce'])), 'ecwp_login')) {
        wp_die(esc_html__('Security check failed. Please try again.', 'my-easy-compta'));
    }
    $username = sanitize_user(wp_unslash($_POST['username'] ?? ''));
    $password = isset($_POST['password']) ? wp_unslash($_POST['password']) : '';
    $remember = isset($_POST['remember']) ? true : false;

    $credentials = [
        'user_login' => $username,
        'user_password' => $password,
        'remember' => $remember,
    ];

    $user = wp_signon($credentials, false);
    if (is_wp_error($user)) {
        $error = '<div role="alert" class="alert alert-error text-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-alert-circle">
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0" />
            <path d="M12 8v4" />
            <path d="M12 16h.01" />
        </svg>
        <span>' . __('Error! The username or password you entered is incorrect.', 'my-easy-compta') . '</span>
        </div>';
    } else {
        $redirect_to = home_url();

        $dashboard_page_id = get_option('easy_compta_dashboard_page_id');
        if ($dashboard_page_id) {
            $redirect_to = get_permalink($dashboard_page_id);
        }

        wp_redirect($redirect_to);
        exit;
    }
}
?>

<!DOCTYPE html>
<html <?php language_attributes();?>>

<head>
    <meta charset="<?php bloginfo('charset');?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php wp_title();?></title>
    <link rel="stylesheet" href="<?php echo esc_url(ECWP_USER_URL . '/assets/dist/app.min.css'); ?>">
</head>

<body <?php body_class();?>>
    <div class="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8 flex justify-center">
            <form class="ecwp-login-form" action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" method="POST">
                <?php
echo $error;
?>
                <input type="hidden" name="action" value="login">
                <?php wp_nonce_field('ecwp_login', 'ecwp_login_nonce'); ?>
                <div class="flex-column">
                    <label for="username"><?php esc_html_e('Email or username', 'my-easy-compta');?> </label>
                </div>
                <div class="inputForm">
                    <svg height="20" viewBox="0 0 32 32" width="20" xmlns="http://www.w3.org/2000/svg">
                        <g id="Layer_3" data-name="Layer 3">
                            <path
                                d="m30.853 13.87a15 15 0 0 0 -29.729 4.082 15.1 15.1 0 0 0 12.876 12.918 15.6 15.6 0 0 0 2.016.13 14.85 14.85 0 0 0 7.715-2.145 1 1 0 1 0 -1.031-1.711 13.007 13.007 0 1 1 5.458-6.529 2.149 2.149 0 0 1 -4.158-.759v-10.856a1 1 0 0 0 -2 0v1.726a8 8 0 1 0 .2 10.325 4.135 4.135 0 0 0 7.83.274 15.2 15.2 0 0 0 .823-7.455zm-14.853 8.13a6 6 0 1 1 6-6 6.006 6.006 0 0 1 -6 6z">
                            </path>
                        </g>
                    </svg>
                    <input type="text" id="username" name="username" class="input"
                        placeholder="<?php esc_html_e('Enter your Email or username', 'my-easy-compta');?>">
                </div>

                <div class="flex-column">
                    <label for="password"><?php esc_html_e('Password', 'my-easy-compta');?></label>
                </div>
                <div class="inputForm">
                    <svg height="20" viewBox="-64 0 512 512" width="20" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="m336 512h-288c-26.453125 0-48-21.523438-48-48v-224c0-26.476562 21.546875-48 48-48h288c26.453125 0 48 21.523438 48 48v224c0 26.476562-21.546875 48-48 48zm-288-288c-8.8125 0-16 7.167969-16 16v224c0 8.832031 7.1875 16 16 16h288c8.8125 0 16-7.167969 16-16v-224c0-8.832031-7.1875-16-16-16zm0 0">
                        </path>
                        <path
                            d="m304 224c-8.832031 0-16-7.167969-16-16v-80c0-52.929688-43.070312-96-96-96s-96 43.070312-96 96v80c0 8.832031-7.167969 16-16 16s-16-7.167969-16-16v-80c0-70.59375 57.40625-128 128-128s128 57.40625 128 128v80c0 8.832031-7.167969 16-16 16zm0 0">
                        </path>
                    </svg>
                    <input type="password" id="password" name="password" class="input"
                        placeholder="<?php esc_html_e('Enter your Password', 'my-easy-compta');?>">

                    <svg viewBox="0 0 576 512" height="1em" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M288 32c-80.8 0-145.5 36.8-192.6 80.6C48.6 156 17.3 208 2.5 243.7c-3.3 7.9-3.3 16.7 0 24.6C17.3 304 48.6 356 95.4 399.4C142.5 443.2 207.2 480 288 480s145.5-36.8 192.6-80.6c46.8-43.5 78.1-95.4 93-131.1c3.3-7.9 3.3-16.7 0-24.6c-14.9-35.7-46.2-87.7-93-131.1C433.5 68.8 368.8 32 288 32zM144 256a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm144-64c0 35.3-28.7 64-64 64c-7.1 0-13.9-1.2-20.3-3.3c-5.5-1.8-11.9 1.6-11.7 7.4c.3 6.9 1.3 13.8 3.2 20.7c13.7 51.2 66.4 81.6 117.6 67.9s81.6-66.4 67.9-117.6c-11.1-41.5-47.8-69.4-88.6-71.1c-5.8-.2-9.2 6.1-7.4 11.7c2.1 6.4 3.3 13.2 3.3 20.3z">
                        </path>
                    </svg>
                </div>

                <div class="flex-row">
                    <a href="<?php echo esc_url(wp_lostpassword_url()); ?>"
                        class="span"><?php esc_html_e('Forgot password?', 'my-easy-compta');?></a>
                </div>
                <button type="submit" class="button-submit"><?php esc_html_e('Sign In', 'my-easy-compta');?></button>
            </form>
        </div>
    </div>

</body>

</html>