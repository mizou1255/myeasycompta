<?php

namespace ECWP\User;

use ECWP\Admin\Settings\ECWP_Settings;
use ECWP\API\Routes;

class ECWPUser_APP
{
    protected $routes;

    public function __construct()
    {
        if ($this->has_valid_license()) {
            add_filter('theme_page_templates', array($this, 'ecwp_add_page_template'));
            add_filter('page_template', array($this, 'ecwp_redirect_page_template'));
            add_action('ecwp_add_user', array($this, 'create_wordpress_user_for_client'), 10, 1);
            add_action('init', array($this, 'get_current_wordpress_user'));

            $this->routes = new Routes();
            $this->register_api_routes();
        }
    }

    public function ecwp_add_page_template($templates)
    {
        $templates['dashboard-template.php'] = 'myEasyCompta Dashboard';
        $templates['login-template.php'] = 'myEasyCompta Login';
        return $templates;
    }

    public function ecwp_redirect_page_template($template)
    {
        $page_template = get_page_template_slug();
        if ('dashboard-template.php' === $page_template) {
            $template = ECWP_USER_PATH_DIR . '/templates/dashboard-template.php';
        }
        if ('login-template.php' === $page_template) {
            $template = ECWP_USER_PATH_DIR . '/templates/login-template.php';
        }
        return $template;
    }

    /**
     * @return [type]
     */
    public function register_api_routes()
    {
        $this->routes->add_route('/user/options', 'GET', $this, 'get_options', function () {
            return current_user_can('subscriber');
        });
        $this->routes->add_route('/user/options/currency/(?P<id>\d+)', 'GET', $this, 'get_currency', function () {
            return current_user_can('subscriber');
        });
        $this->routes->add_route('/user/options/vat/(?P<id>\d+)', 'GET', $this, 'get_vat', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user/details/(?P<id>\d+)', 'GET', $this, 'get_client_details', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user/logout', 'POST', $this, 'logout_user', function () {
            return current_user_can('subscriber');
        });

        $this->routes->register_routes();
    }

    public function get_current_wordpress_user()
    {
        $current_user_id = get_current_user_id();
        return $current_user_id;
    }

    public function get_options()
    {
        global $wpdb;
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT meta_key, meta_value FROM %i
        WHERE meta_key IN (
            'default_currency',
            'logo_url',
            'logo_width',
            'vat_active',
            'default_vat',
            'date_format',
            'company_name',
            'company_address',
            'postal_code',
            'city',
            'country',
            'company_phone',
            'mobile_phone',
            'easy_compta_signature_addon_active',
            'easy_compta_payment_addon_active',
            'stripe_mode',
            'stripe_public_key_test',
            'stripe_public_key_live'
            )",
                ECWP_TABLE_SETTINGS
            ),
            OBJECT_K
        );

        // Override addon status based on license
        if (isset($results['easy_compta_signature_addon_active'])) {
            $results['easy_compta_signature_addon_active']->meta_value = $this->check_addon_license('my-easy-compta-signature') ? '1' : '0';
        }
        if (isset($results['easy_compta_payment_addon_active'])) {
            $results['easy_compta_payment_addon_active']->meta_value = $this->check_addon_license('my-easy-compta-payment') ? '1' : '0';
        }

        return rest_ensure_response($results);
    }

    private function check_addon_license($slug)
    {
        $license_data = get_option('ecwp_client_license_data');
        if (!is_array($license_data) || !isset($license_data['plugins']) || !is_array($license_data['plugins'])) {
            return false;
        }

        foreach ($license_data['plugins'] as $p) {
            if ($slug === $p['product_slug']) {
                return true;
            }
        }
        return false;
    }
    public function get_currency(\WP_REST_Request $request)
    {
        global $wpdb;
        $currency_id = $request->get_param('id');
        $currency_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE id = %d", ECWP_TABLE_CURRENCY, $currency_id));

        if (!$currency_data) {
            return new \WP_Error('currency_not_found', 'Currency not found', array('status' => 404));
        }

        return rest_ensure_response($currency_data);
    }

    public function get_vat(\WP_REST_Request $request)
    {
        global $wpdb;
        $vat_id = $request->get_param('id');
        $vat_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE id = %d", ECWP_TABLE_VATS, $vat_id));

        if (!$vat_data) {
            return new \WP_Error('vat_not_found', 'VAT not found', array('status' => 404));
        }

        return rest_ensure_response($vat_data);
    }

    public function get_client_details($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $params = $request->get_params();
        $client_id = absint($params['id']);
        global $wpdb;
        $client_details = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM %i WHERE id = %d",
                ECWP_TABLE_CLIENTS,
                $client_id
            ),
            ARRAY_A
        );

        if (!$client_details) {
            return new \WP_Error('client_not_found', __('Client not found.', 'my-easy-compta'), array('status' => 404));
        }

        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        if ((int) $client_details['user_id'] !== (int) $current_user_id) {
            return new \WP_Error('unauthorized', __('You are not authorized to view this client.'), array('status' => 403));
        }

        return rest_ensure_response($client_details);
    }

    /************ CREATE USER WORDPRESS AFTER ADD USER */
    public function create_wordpress_user_for_client($client_data)
    {
        global $wpdb;
        $email = $client_data['email'];
        $client_id = $client_data['id'];
        $username = $this->generate_unique_username($client_data['company_name']);
        $password = wp_generate_password();

        if (username_exists($username) || email_exists($email)) {
            return new \WP_Error('username_email_exists', __('Username or Email already exists.', 'my-easy-compta'), array('status' => 403));
        }

        if (!isset($client_data['user_create']) || !$client_data['user_create']) {
            return;
        }

        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            return new \WP_Error('error_creating_user', __('Error creating user:' . $user_id->get_error_message(), 'my-easy-compta'), array('status' => 403));
        }

        wp_update_user(array(
            'ID' => $user_id,
            'nickname' => $client_data['manager_name'],
            'display_name' => $client_data['manager_name'],
        ));

        $variables = [
            '{CLIENT}' => $client_data['company_name'],
            '{USERNAME}' => $username,
            '{PASSWORD}' => $password,
        ];

        $headers = array('Content-Type: text/html; charset=UTF-8');

        $settings = new ECWP_Settings();
        $email_subject = $settings->get_setting('email_create_account_subject');
        $email_message = $settings->get_setting('email_create_account_content');

        foreach ($variables as $key => $value) {
            $email_message = str_replace($key, $value, $email_message);
        }

        $mail_sent = wp_mail($email, $email_subject, $email_message, $headers);

        update_user_meta($user_id, 'billing_company', $client_data['company_name']);
        update_user_meta($user_id, 'billing_phone', $client_data['phone']);
        update_user_meta($user_id, 'billing_address_1', $client_data['address']);
        update_user_meta($user_id, 'billing_city', $client_data['city']);
        update_user_meta($user_id, 'billing_postcode', $client_data['postal_code']);
        update_user_meta($user_id, 'billing_country', $client_data['country']);

        $client = $wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE id = %d", ECWP_TABLE_CLIENTS, absint($client_id)));
        if ($client) {
            $result = $wpdb->update(
                ECWP_TABLE_CLIENTS,
                array('user_id' => $user_id),
                array('id' => absint($client_id))
            );

            if ($result === false) {
                return new \WP_Error('db_update_error', __('Error updating client table', 'my-easy-compta'), array('status' => 500));
            }
        }
    }

    private function generate_unique_username($company_name)
    {
        $clean_company_name = preg_replace('/[^A-Za-z0-9\-]/', '', $company_name);
        if (empty($clean_company_name)) {
            $clean_company_name = 'client';
        }

        $base_username = sanitize_user($clean_company_name, true);
        $username = $base_username;

        $suffix_length = rand(2, 3);
        $suffix = '';
        for ($i = 0; $i < $suffix_length; $i++) {
            $suffix .= mt_rand(0, 9);
        }

        while (username_exists($username)) {
            $username = $base_username . '' . $suffix;
            $suffix_length = rand(2, 3);
            $suffix = '';
            for ($i = 0; $i < $suffix_length; $i++) {
                $suffix .= mt_rand(0, 9);
            }
        }

        return $username;
    }

    public function logout_user($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        $valid_nonce = wp_verify_nonce($nonce, 'wp_rest');

        if (!$valid_nonce) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        wp_logout();
        wp_safe_redirect(home_url());
        exit;
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

}
