<?php

namespace ECWP\User;

class ECWPUser_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
        $this->create_pages();
    }
    public function database_update()
    {
        global $wpdb;
        $this->insert_meta_key_if_not_exists('easy_compta_user_addon_active', 1);
        $this->insert_meta_key_if_not_exists('email_create_account_subject', __('Bienvenue', 'my-easy-compta'));
        $this->insert_meta_key_if_not_exists('email_create_account_content', '<p>Bonjour <strong>{CLIENT}</strong>,</p><p><br></p><p>Vous trouverez ci-dessous vos accès sur notre plateforme myEasyCompta : </p><p><br></p><p>Login : <strong>{USERNAME}</strong> </p><p>Mot de passe : <strong>{PASSWORD}</strong></p><p><br></p><p>Cordialement.</p>');

        $column_id_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW COLUMNS FROM %i LIKE 'user_id'",
            ECWP_TABLE_CLIENTS
        ));

        $column_create_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW COLUMNS FROM %i LIKE 'user_create'",
            ECWP_TABLE_CLIENTS
        ));

        if (!$column_id_exists) {
            $wpdb->query($wpdb->prepare(
                "ALTER TABLE %i ADD COLUMN user_id int(11) NOT NULL DEFAULT 0",
                ECWP_TABLE_CLIENTS
            ));
        } else {
            // Upgrade tinyint(1) → int(11) for sites with >127 WP users
            $col_type = $wpdb->get_var($wpdb->prepare(
                "SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = 'user_id'",
                ECWP_TABLE_CLIENTS
            ));
            if ($col_type && stripos($col_type, 'tinyint') !== false) {
                $wpdb->query($wpdb->prepare(
                    "ALTER TABLE %i MODIFY COLUMN user_id int(11) NOT NULL DEFAULT 0",
                    ECWP_TABLE_CLIENTS
                ));
            }
        }

        if (!$column_create_exists) {
            $wpdb->query($wpdb->prepare(
                "ALTER TABLE %i ADD COLUMN user_create tinyint(1) NOT NULL DEFAULT 0",
                ECWP_TABLE_CLIENTS
            ));
        }
    }
    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_user_addon_active'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'email_create_account_subject'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'email_create_account_content'));
        $wpdb->query($wpdb->prepare(
            "ALTER TABLE %i DROP COLUMN user_id",
            ECWP_TABLE_CLIENTS
        ));
        $wpdb->query($wpdb->prepare(
            "ALTER TABLE %i DROP COLUMN user_create",
            ECWP_TABLE_CLIENTS
        ));

        $this->delete_pages();
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM %i WHERE meta_key = %s",
            ECWP_TABLE_SETTINGS, $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                ECWP_TABLE_SETTINGS,
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }
    public function create_pages()
    {
        $template = plugin_dir_path(__FILE__) . 'dashboard-template.php';
        $template_login = plugin_dir_path(__FILE__) . 'login-template.php';
        $dashboard_page = get_page_by_path('ec-dashboard');
        if (!$dashboard_page) {
            $dashboard_page_args = array(
                'post_title' => __('myEasyCompta Dashboard', 'my-easy-compta'),
                'post_content' => '',
                'post_status' => 'publish',
                'post_author' => get_current_user_id(),
                'post_type' => 'page',
                'page_template' => str_replace(plugin_dir_path(__FILE__), '', $template),
            );
            $dashboard_page_id = wp_insert_post($dashboard_page_args);
            update_option('easy_compta_dashboard_page_id', $dashboard_page_id);
            update_post_meta($dashboard_page_id, '_wp_page_template', 'dashboard-template.php');
        }
        $login_page = get_page_by_path('ec-login');
        if (!$login_page) {
            $login_page_args = array(
                'post_title' => __('Login', 'my-easy-compta'),
                'post_content' => '',
                'post_status' => 'publish',
                'post_author' => get_current_user_id(),
                'post_type' => 'page',
                'page_template' => str_replace(plugin_dir_path(__FILE__), '', $template_login),
            );
            $login_page_id = wp_insert_post($login_page_args);
            update_option('easy_compta_login_id', $login_page_id);
            update_post_meta($login_page_id, '_wp_page_template', 'login-template.php');
        }
    }

    public function delete_pages()
    {
        $dashboard_page_id = get_option('easy_compta_dashboard_page_id');
        $login_page_id = get_option('easy_compta_login_id');
        if ($dashboard_page_id) {
            wp_delete_post($dashboard_page_id, true);
            delete_option('easy_compta_dashboard_page_id');
        }
        if ($login_page_id) {
            wp_delete_post($login_page_id, true);
            delete_option('easy_compta_login_id');
        }
    }
}
