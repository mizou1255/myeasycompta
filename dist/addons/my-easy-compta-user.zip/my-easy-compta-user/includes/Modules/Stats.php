<?php
namespace ECWP\User;

use ECWP\API\Routes;

class ECWPUser_Stats
{

    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/user-stats', 'GET', $this, 'get_stats_user', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user-stats/monthly-payments', 'GET', $this, 'get_user_payments_monthly', function () {
            return current_user_can('subscriber');
        });
        $this->routes->add_route('/user-stats/recents-payments', 'GET', $this, 'get_user_recent_payments', function () {
            return current_user_can('subscriber');
        });

        $this->routes->register_routes();
    }
    public function get_stats_user($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        $valid_nonce = wp_verify_nonce($nonce, 'wp_rest');

        if (!$valid_nonce) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }
        global $wpdb;
        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;
        $unpaid_invoices_results = $wpdb->get_results($wpdb->prepare("
            SELECT invoices.*
            FROM %i AS invoices
            LEFT JOIN %i AS clients ON invoices.client_id = clients.id
            WHERE clients.user_id = %d AND invoices.status_stats = 'unpaid'",
            ECWP_TABLE_INVOICES, ECWP_TABLE_CLIENTS,
            $current_user_id),
            OBJECT
        );

        $total_unpaid_invoices = 0;
        $count_unpaid_invoices = 0;

        if (!empty($unpaid_invoices_results)) {
            foreach ($unpaid_invoices_results as $invoice) {
                $total_unpaid_invoices += floatval($encrypt->decrypt($invoice->total_amount));
                $count_unpaid_invoices++;
            }
        }

        $paid_invoices_results = $wpdb->get_results($wpdb->prepare("
            SELECT invoices.total_amount
            FROM " . ECWP_TABLE_INVOICES . " AS invoices
            LEFT JOIN " . ECWP_TABLE_CLIENTS . " AS clients ON invoices.client_id = clients.id
            WHERE clients.user_id = %d AND invoices.status_stats = 'paid'",
            $current_user_id),
            OBJECT
        );

        $total_paid_invoices = 0;
        $count_paid_invoices = 0;

        if (!empty($paid_invoices_results)) {
            foreach ($paid_invoices_results as $invoice) {
                $total_paid_invoices += floatval($encrypt->decrypt($invoice->total_amount));
                $count_paid_invoices++;
            }
        }

        $total_invoices = $wpdb->get_row($wpdb->prepare("
        SELECT COUNT(invoices.id) AS count_invoices
        FROM %i AS invoices
        LEFT JOIN %i AS clients ON invoices.client_id = clients.id
        WHERE clients.user_id = %d ",
            ECWP_TABLE_INVOICES, ECWP_TABLE_CLIENTS,
            $current_user_id),
            OBJECT);

        $total_quotes = $wpdb->get_row($wpdb->prepare("
        SELECT COUNT(quotes.id) AS count_quotes
        FROM %i AS quotes
        LEFT JOIN %i AS clients ON quotes.client_id = clients.id
        WHERE clients.user_id = %d ",
            ECWP_TABLE_QUOTES, ECWP_TABLE_CLIENTS,
            $current_user_id),
            OBJECT);

        $currency_symbol = $wpdb->get_var($wpdb->prepare("
        SELECT currencies.symbol
        FROM %i AS clients
        LEFT JOIN %i AS currencies ON clients.currency_id = currencies.id
        WHERE clients.user_id = %d
        LIMIT 1",
            ECWP_TABLE_CLIENTS, ECWP_TABLE_CURRENCY,
            $current_user_id));

        return rest_ensure_response(array(
            'total_unpaid_invoices' => $total_unpaid_invoices,
            'total_paid_invoices' => $total_paid_invoices,
            'count_unpaid_invoices' => $count_unpaid_invoices,
            'count_paid_invoices' => $count_paid_invoices,
            'symbol' => $currency_symbol,
            'total_invoices' => $total_invoices->count_invoices,
            'total_quotes' => $total_quotes->count_quotes,
        ));
    }

    public function get_user_payments_monthly($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        $valid_nonce = wp_verify_nonce($nonce, 'wp_rest');

        if (!$valid_nonce) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        global $wpdb;
        $current_year = (int) current_time('Y');
        $payments = $wpdb->get_results($wpdb->prepare("
            SELECT MONTH(payments.payment_date) as month, SUM(payments.amount) as total
            FROM %i AS payments
            LEFT JOIN %i AS clients ON payments.client_id = clients.id
            WHERE YEAR(payments.payment_date) = %d AND clients.user_id = %d
            GROUP BY MONTH(payments.payment_date)",
            ECWP_TABLE_PAYMENTS, ECWP_TABLE_CLIENTS,
            $current_year, $current_user_id),
            ARRAY_A
        );

        $months = [1 => __('January', 'my-easy-compta'),
            2 => __('February', 'my-easy-compta'),
            3 => __('March', 'my-easy-compta'),
            4 => __('April', 'my-easy-compta'),
            5 => __('May', 'my-easy-compta'),
            6 => __('June', 'my-easy-compta'),
            7 => __('July', 'my-easy-compta'),
            8 => __('August', 'my-easy-compta'),
            9 => __('September', 'my-easy-compta'),
            10 => __('October', 'my-easy-compta'),
            11 => __('November', 'my-easy-compta'),
            12 => __('December', 'my-easy-compta'),
        ];

        $monthly_data = ['months' => array_values($months),
            'payments' => array_fill(0, 12, 0),
            'expenses' => array_fill(0, 12, 0),
        ];

        foreach ($payments as $payment) {
            $monthly_data['payments'][$payment['month'] - 1] = floatval($payment['total']);
        }

        return rest_ensure_response($monthly_data);
    }

    public function get_user_recent_payments($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        $valid_nonce = wp_verify_nonce($nonce, 'wp_rest');

        if (!$valid_nonce) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        global $wpdb;
        $recent_payments = $wpdb->get_results($wpdb->prepare(
            "SELECT invoices.invoice_number,
            invoices.total_amount,
            invoices.status,
            clients.currency_id,
            currency.symbol
                FROM %i AS invoices
                INNER JOIN %i AS clients ON invoices.client_id = clients.id
                INNER JOIN %i AS currency ON clients.currency_id = currency.id
                WHERE clients.user_id = %d
                ORDER BY invoices.invoice_number DESC
                LIMIT 10",
            ECWP_TABLE_INVOICES, ECWP_TABLE_CLIENTS, ECWP_TABLE_CURRENCY,
            $current_user_id),
            ARRAY_A
        );

        if (!$recent_payments) {
            return new \WP_Error('no_payments', 'No payments found', array('status' => 404));
        }
        $decrypted_payments = [];
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        foreach ($recent_payments as $payment) {
            $payment['invoice_number'] = $encrypt->decrypt($payment['invoice_number']);
            $payment['status'] = $encrypt->decrypt($payment['status']);
            $payment['total_amount'] = $encrypt->decrypt($payment['total_amount']);
            $decrypted_payments[] = $payment;
        }

        return rest_ensure_response($decrypted_payments);
    }

}