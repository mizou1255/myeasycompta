<?php
namespace ECWP\User;

use ECWP\Admin\PDF\PDFGenerator;
use ECWP\API\Routes;

class ECWPUser_Invoices
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/user-invoices', 'GET', $this, 'get_invoices', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user-invoices/(?P<id>\d+)', 'GET', $this, 'get_invoice_details', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user-invoices/(?P<id>\d+)/items', 'GET', $this, 'get_invoice_items', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user-invoice/pdf/(?P<id>\d+)', 'GET', $this, 'generate_invoice_pdf', function () {
            return current_user_can('subscriber');
        });

        $this->routes->register_routes();
    }

    public function get_invoices($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }
        $page = isset($request['page']) ? absint($request['page']) : 1;
        $per_page = isset($request['per_page']) ? absint($request['per_page']) : 10;
        $offset = ($page - 1) * $per_page;
        global $wpdb;
        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;
        $invoices = $wpdb->get_results($wpdb->prepare("
        SELECT invoices.id,
               clients.company_name,
               currencies.symbol AS currency_symbol,
               invoices.invoice_number,
               invoices.total_amount,
               invoices.status AS encrypted_status,
               invoices.due_date,
               invoices.created_at
        FROM %i AS invoices
        LEFT JOIN %i AS clients ON invoices.client_id = clients.id
        LEFT JOIN %i AS currencies ON clients.currency_id = currencies.id
        WHERE clients.user_id = %d AND invoices.status_stats != 'draft'
        ORDER BY invoices.id DESC
        LIMIT %d, %d",
            ECWP_TABLE_INVOICES, ECWP_TABLE_CLIENTS, ECWP_TABLE_CURRENCY,
            $current_user_id, $offset, $per_page
        ), OBJECT);

        $filtered_invoices = $invoices;

        $total_count = $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(invoices.id)
                FROM %i AS invoices
                LEFT JOIN %i AS clients ON invoices.client_id = clients.id
                WHERE clients.user_id = %d AND invoices.status_stats != 'draft'", ECWP_TABLE_INVOICES, ECWP_TABLE_CLIENTS, $current_user_id
            ));
        $total_pages = ceil($total_count / $per_page);
        $data = array();
        foreach ($filtered_invoices as $invoice) {
            $data[] = array(
                'id' => $invoice->id,
                'client_name' => $invoice->company_name,
                'client_currency' => $invoice->currency_symbol,
                'invoice_number' => $encrypt->decrypt($invoice->invoice_number),
                'total_amount' => $encrypt->decrypt($invoice->total_amount),
                'status' => $encrypt->decrypt($invoice->encrypted_status),
                'due_date' => $invoice->due_date,
                'created' => $invoice->created_at,
            );
        }
        return rest_ensure_response(array(
            'invoices' => $data,
            'total_count' => $total_count,
            'total_pages' => $total_pages,
            'page' => $page,
            'per_page' => $per_page,
        ));
    }

    public function get_invoice_details($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $params = $request->get_params();
        $invoice_id = $params['id'];
        global $wpdb;
        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        $invoice_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d",
            ECWP_TABLE_INVOICES, $invoice_id),
            ARRAY_A
        );

        if (!$invoice_details) {
            return new \WP_Error('invoice_not_found', __('invoice not found.'), array('status' => 404));
        }

        $client_id = $invoice_details['client_id'];
        $client_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d", ECWP_TABLE_CLIENTS, $client_id),
            ARRAY_A
        );

        if (!$client_details) {
            return new \WP_Error('client_not_found', __('Client not found.'), array('status' => 404));
        }

        if ((int) $client_details['user_id'] !== (int) $current_user_id) {
            return new \WP_Error('unauthorized', __('You are not authorized to view this invoice.'), array('status' => 403));
        }

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;
        $invoice_details["invoice_number"] = $encrypt->decrypt($invoice_details["invoice_number"]);
        $invoice_details["status"] = $encrypt->decrypt($invoice_details["status"]);
        $invoice_details["amount"] = $encrypt->decrypt($invoice_details["amount"]);
        $invoice_details["total_amount"] = $encrypt->decrypt($invoice_details["total_amount"]);
        $invoice_details["exchange_rate"] = $encrypt->decrypt($invoice_details["exchange_rate"]);

        return rest_ensure_response($invoice_details);
    }

    public function get_invoice_items($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $invoice_id = $request['id'];
        if (!isset($invoice_id) || !is_numeric($invoice_id)) {
            return new \WP_Error('invalid_invoice_id', 'Invalid invoice ID.', array('status' => 400));
        }

        $current_user_id = get_current_user_id();
        global $wpdb;
        $invoice_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d", ECWP_TABLE_INVOICES, $invoice_id),
            ARRAY_A
        );

        if (!$invoice_details) {
            return new \WP_Error('invoice_not_found', __('invoice not found.'), array('status' => 404));
        }

        $client_id = $invoice_details['client_id'];
        $client_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d", ECWP_TABLE_CLIENTS, $client_id),
            ARRAY_A
        );

        if (!$client_details) {
            return new \WP_Error('client_not_found', __('Client not found.'), array('status' => 404));
        }

        if ((int) $client_details['user_id'] !== (int) $current_user_id) {
            return new \WP_Error('unauthorized', __('You are not authorized to view this invoice.'), array('status' => 403));
        }

        global $wpdb;
        $invoice_items = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM %i WHERE invoice_id = %d ORDER BY item_order ASC",
            ECWP_TABLE_INVOICE_ELEMENTS, $invoice_id),
        );

        if (empty($invoice_items)) {
            return new \WP_Error('no_items_found', 'No items found for the given invoice ID.', array('status' => 404));
        }

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;
        foreach ($invoice_items as $item) {
            $item->item_name = $encrypt->decrypt($item->item_name);
            $item->item_description = $encrypt->decrypt($item->item_description);
            $item->item_ref = $encrypt->decrypt($item->item_ref);
            $item->quantity = $encrypt->decrypt($item->quantity);
            $item->vat_rate = $encrypt->decrypt($item->vat_rate);
            $item->unit_price = $encrypt->decrypt($item->unit_price);
            $item->discount = $encrypt->decrypt($item->discount);
            $item->total_price = $encrypt->decrypt($item->total_price);
            $item->total_amount = $encrypt->decrypt($item->total_amount);
        }
        return rest_ensure_response($invoice_items);
    }

    public function generate_invoice_pdf(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $invoice_id = absint($request->get_param('id'));
        if (!$invoice_id) {
            return new \WP_Error('invalid_invoice_id', 'Invalid invoice ID.', array('status' => 400));
        }

        global $wpdb;
        $current_user_id = get_current_user_id();

        // Verify ownership: invoice must belong to the current subscriber's client record
        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT invoices.id FROM %i AS invoices
             LEFT JOIN %i AS clients ON invoices.client_id = clients.id
             WHERE invoices.id = %d AND clients.user_id = %d",
            ECWP_TABLE_INVOICES, ECWP_TABLE_CLIENTS, $invoice_id, $current_user_id
        ));

        if (!$invoice) {
            return new \WP_Error('unauthorized', __('You are not authorized to view this invoice.', 'my-easy-compta'), array('status' => 403));
        }

        $pdfGenerator = new PDFGenerator($wpdb);
        $pdfGenerator->generateInvoicePDF($invoice_id, "", "");
    }

}