<?php
namespace ECWP\User;

use ECWP\API\Routes;

class ECWPUser_Account
{

    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/client-info', 'GET', $this, 'get_client_info', function () {
            return current_user_can('subscriber');
        });
        $this->routes->add_route('/update-client', 'POST', $this, 'update_client_info', function () {
            return current_user_can('subscriber');
        });
        $this->routes->add_route('/update-password', 'POST', $this, 'update_user_password', function () {
            return current_user_can('subscriber');
        });

        $this->routes->register_routes();
    }

    public function get_client_info($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        $client = $this->get_client_by_user_id($current_user_id);
        $user = wp_get_current_user();

        return [
            'client' => $client,
            'user' => [
                'email' => $user->user_email,
            ],
        ];
    }

    public function get_client_by_user_id($user_id)
    {
        global $wpdb;

        $client = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT company_name, manager_name, address, city, postal_code, country, phone, mobile_phone, website
                FROM %i
                WHERE user_id = %d",
                ECWP_TABLE_CLIENTS,
                $user_id,
            ),
            ARRAY_A
        );

        return $client;
    }

    public function update_client_info($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        $client_data = $request->get_json_params();

        $this->update_client_by_user_id($current_user_id, $client_data);

        return new \WP_REST_Response('Client info updated', 200);
    }

    public function update_user_password($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        $password = $request->get_param('password');

        if (empty($password) || strlen($password) < 8) {
            return new \WP_Error('weak_password', __('Password must be at least 8 characters.', 'my-easy-compta'), array('status' => 400));
        }

        wp_set_password($password, $current_user_id);

        return new \WP_REST_Response('Password updated', 200);
    }

    function update_client_by_user_id($user_id, $client_data)
    {
        global $wpdb;
        $wpdb->update(
            ECWP_TABLE_CLIENTS,
            array(
                'manager_name' => sanitize_text_field($client_data['manager_name'] ?? ''),
                'address'      => sanitize_text_field($client_data['address'] ?? ''),
                'city'         => sanitize_text_field($client_data['city'] ?? ''),
                'postal_code'  => sanitize_text_field($client_data['postal_code'] ?? ''),
                'country'      => sanitize_text_field($client_data['country'] ?? ''),
                'phone'        => sanitize_text_field($client_data['phone'] ?? ''),
                'mobile_phone' => sanitize_text_field($client_data['mobile_phone'] ?? ''),
                'website'      => esc_url_raw($client_data['website'] ?? ''),
            ),
            array('user_id' => $user_id),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'),
            array('%d')
        );
    }
}
