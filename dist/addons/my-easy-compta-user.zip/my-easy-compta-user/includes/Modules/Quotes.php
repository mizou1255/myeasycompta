<?php
namespace ECWP\User;

use ECWP\Admin\PDF\PDFGenerator;
use ECWP\API\Routes;

class ECWPUser_Quotes
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();

    }

    private function register_api_routes()
    {
        $this->routes->add_route('/user-quotes', 'GET', $this, 'get_quotes', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user-quotes/(?P<id>\d+)', 'GET', $this, 'get_quote_details', function () {
            return current_user_can('subscriber');
        });
        $this->routes->add_route('/user-quotes/(?P<id>\d+)/items', 'GET', $this, 'get_quote_items', function () {
            return current_user_can('subscriber');
        });

        $this->routes->add_route('/user-quote/pdf/(?P<id>\d+)', 'GET', $this, 'generate_quote_pdf', function () {
            return current_user_can('subscriber');
        });

        $this->routes->register_routes();
    }

    public function get_quotes($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }
        $page = isset($request['page']) ? absint($request['page']) : 1;
        $per_page = isset($request['per_page']) ? absint($request['per_page']) : 10;
        $offset = ($page - 1) * $per_page;
        global $wpdb;
        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();

        $quotes = $wpdb->get_results($wpdb->prepare("
        SELECT quotes.id,
               clients.company_name,
               currencies.symbol AS currency_symbol,
               quotes.quote_number,
               quotes.total_amount,
               quotes.status,
               quotes.due_date,
               quotes.created_at
        FROM %i AS quotes
        LEFT JOIN %i AS clients ON quotes.client_id = clients.id
        LEFT JOIN %i AS currencies ON clients.currency_id = currencies.id
        WHERE clients.user_id = %d AND quotes.status != 'draft'
        ORDER BY quotes.id DESC
        LIMIT %d, %d",
            ECWP_TABLE_QUOTES, ECWP_TABLE_CLIENTS, ECWP_TABLE_CURRENCY,
            $current_user_id, $offset, $per_page),
            OBJECT);

        $total_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(quotes.id)
        FROM %i AS quotes
        LEFT JOIN %i AS clients ON quotes.client_id = clients.id
        WHERE clients.user_id = %d AND quotes.status != 'draft'", ECWP_TABLE_QUOTES, ECWP_TABLE_CLIENTS, $current_user_id));

        $total_pages = ceil($total_count / $per_page);

        $data = array();
        foreach ($quotes as $quote) {
            $data[] = array(
                'id' => $quote->id,
                'client_name' => $quote->company_name,
                'client_currency' => $quote->currency_symbol,
                'quote_number' => $quote->quote_number,
                'total_amount' => $quote->total_amount,
                'status' => $quote->status,
                'due_date' => $quote->due_date,
                'created' => $quote->created_at,
            );
        }

        return rest_ensure_response(array(
            'quotes' => $data,
            'total_count' => $total_count,
            'total_pages' => $total_pages,
            'page' => $page,
            'per_page' => $per_page,
        ));
    }

    public function get_quote_details($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $params = $request->get_params();
        $quote_id = $params['id'];
        global $wpdb;
        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();
        $quote_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d",
            ECWP_TABLE_QUOTES, $quote_id),
            ARRAY_A
        );

        if (!$quote_details) {
            return new \WP_Error('quote_not_found', __('Quote not found.', 'my-easy-compta'), array('status' => 404));
        }

        $client_id = $quote_details['client_id'];
        $client_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d",
            ECWP_TABLE_CLIENTS, $client_id),
            ARRAY_A
        );

        if (!$client_details) {
            return new \WP_Error('client_not_found', __('Client not found.', 'my-easy-compta'), array('status' => 404));
        }

        if ((int) $client_details['user_id'] !== (int) $current_user_id) {
            return new \WP_Error('unauthorized', __('You are not authorized to view this quote.', 'my-easy-compta'), array('status' => 403));
        }

        return rest_ensure_response($quote_details);
    }

    public function get_quote_items($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $quote_id = $request['id'];
        if (!isset($quote_id) || !is_numeric($quote_id)) {
            return new \WP_Error('invalid_quote_id', __('Invalid quote ID.', 'my-easy-compta'), array('status' => 400));
        }

        $current_user_id = get_current_user_id();
        global $wpdb;
        $quote_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d", ECWP_TABLE_QUOTES,
            $quote_id),
            ARRAY_A
        );

        if (!$quote_details) {
            return new \WP_Error('quote_not_found', __('Quote not found.', 'my-easy-compta'), array('status' => 404));
        }

        $client_id = $quote_details['client_id'];
        $client_details = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM %i WHERE id = %d", ECWP_TABLE_CLIENTS,
            $client_id),
            ARRAY_A
        );

        if (!$client_details) {
            return new \WP_Error('client_not_found', __('Client not found.', 'my-easy-compta'), array('status' => 404));
        }

        if ((int) $client_details['user_id'] !== (int) $current_user_id) {
            return new \WP_Error('unauthorized', __('You are not authorized to view this quote.', 'my-easy-compta'), array('status' => 403));
        }

        global $wpdb;
        $quote_items = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM %i WHERE quote_id = %d ORDER BY item_order ASC",
            ECWP_TABLE_QUOTE_ELEMENTS, $quote_id
        ));

        if (empty($quote_items)) {
            return new \WP_Error('no_items_found', __('No items found for the given quote ID.', 'my-easy-compta'), array('status' => 404));
        }

        return rest_ensure_response($quote_items);
    }

    public function generate_quote_pdf(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $quote_id = absint($request->get_param('id'));
        if (!$quote_id) {
            return new \WP_Error('invalid_quote_id', __('Invalid quote ID.', 'my-easy-compta'), array('status' => 400));
        }

        global $wpdb;
        $current_user_id = get_current_user_id();

        // Verify ownership: quote must belong to the current subscriber's client record
        $quote = $wpdb->get_row($wpdb->prepare(
            "SELECT quotes.id FROM %i AS quotes
             LEFT JOIN %i AS clients ON quotes.client_id = clients.id
             WHERE quotes.id = %d AND clients.user_id = %d",
            ECWP_TABLE_QUOTES, ECWP_TABLE_CLIENTS, $quote_id, $current_user_id
        ));

        if (!$quote) {
            return new \WP_Error('unauthorized', __('You are not authorized to view this quote.', 'my-easy-compta'), array('status' => 403));
        }

        $pdfGenerator = new PDFGenerator($wpdb);
        $pdfGenerator->generateQuotePDF($quote_id);
    }

}
