<?php
namespace ECWP\User;

use ECWP\API\Routes;

class ECWPUser_Payments
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/user-payments', 'GET', $this, 'get_payments', function () {
            return current_user_can('subscriber');
        });

        $this->routes->register_routes();
    }

    public function get_payments($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }
        $page = isset($request['page']) ? absint($request['page']) : 1;
        $per_page = isset($request['per_page']) ? absint($request['per_page']) : 10;
        $offset = ($page - 1) * $per_page;
        global $wpdb;
        $easy_compta_app = new ECWPUser_APP();
        $current_user_id = $easy_compta_app->get_current_wordpress_user();

        $total_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM %i p
            LEFT JOIN %i c ON p.client_id = c.id
            WHERE c.user_id = %d", ECWP_TABLE_PAYMENTS, ECWP_TABLE_CLIENTS,
            $current_user_id));

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, m.method_name, i.invoice_number, o.symbol
            FROM %i p
            LEFT JOIN %i c ON p.client_id = c.id
            LEFT JOIN %i i ON p.invoice_id = i.id
            LEFT JOIN %i m ON p.payment_method_id = m.id
            LEFT JOIN %i o ON c.currency_id = o.id
            WHERE c.user_id = %d
            ORDER BY p.id DESC
            LIMIT %d OFFSET %d",
            ECWP_TABLE_PAYMENTS, ECWP_TABLE_CLIENTS, ECWP_TABLE_INVOICES, ECWP_TABLE_PAYMENTS_METHODS, ECWP_TABLE_CURRENCY,
            $current_user_id, $per_page, $offset),
            ARRAY_A
        );

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
        $decrypted_results = [];
        foreach ($results as $r) {
            $r["invoice_number"] = $encrypt->decrypt($r["invoice_number"]);
            $decrypted_results[] = $r;
        }

        $total_pages = ceil($total_count / $per_page);
        $response = array(
            'payments' => $decrypted_results,
            'total_count' => $total_count,
            'total_pages' => $total_pages,
            'page' => $page,
            'per_page' => $per_page,
        );

        return rest_ensure_response($response);
    }
}