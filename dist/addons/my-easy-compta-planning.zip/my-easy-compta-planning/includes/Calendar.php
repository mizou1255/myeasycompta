<?php

namespace ECWP\Planning;

use ECWP\API\Routes;
use ECWP\Planning\ECWPPlanning_Events;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

class ECWPPlanning_Calendar
{
    protected $routes;

    public function __construct()
    {
        add_action('ecwp_add_planning_quote', array($this, 'create_quote_date_in_planning'), 10, 1);
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/events', 'GET', $this, 'get_events', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/events/create-event', 'POST', $this, 'create_event', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/events/delete-event/(?P<id>\d+)', 'DELETE', $this, 'delete_event', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/events/update-event/(?P<id>\d+)', 'PUT', $this, 'update_event', function () {
            return current_user_can('manage_options');
        });

        $this->routes->add_route('/settings/planning-categories', 'GET', $this, 'get_planning_categories', function () {
            return current_user_can('manage_options');
        });

        $this->routes->add_route('/settings/planning-categories', 'POST', $this, 'add_planning_categories', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/settings/planning-categories/(?P<id>\d+)', 'PUT', $this, 'edit_planning_categories', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/settings/planning-categories/(?P<id>\d+)', 'DELETE', $this, 'delete_planning_categories', function () {
            return current_user_can('manage_options');
        });

        $this->routes->register_routes();
    }

    public function create_event($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), array('status' => 403));
        }

        $params = $request->get_json_params();

        $start = null;
        if (isset($params['start']['date']) && isset($params['start']['time'])) {
            $dt = $this->combine_date_time($params['start']['date'], $params['start']['time']);
            if (is_wp_error($dt)) return $dt;
            $start = $dt->format('Y-m-d H:i:s');
        } elseif (!empty($params['start']) && is_string($params['start'])) {
            $start = sanitize_text_field($params['start']);
        }

        $end = null;
        if (isset($params['end']['date']) && isset($params['end']['time'])) {
            $dt = $this->combine_date_time($params['end']['date'], $params['end']['time']);
            if (is_wp_error($dt)) return $dt;
            $end = $dt->format('Y-m-d H:i:s');
        } elseif (!empty($params['end']) && is_string($params['end'])) {
            $end = sanitize_text_field($params['end']);
        }

        $event_data = array(
            'title'       => sanitize_text_field($params['title'] ?? ''),
            'description' => sanitize_textarea_field($params['description'] ?? ''),
            'start'       => $start,
            'end'         => $end,
            'all_day'     => !empty($params['all_day']) ? 1 : 0,
            'category_id' => !empty($params['category_id']) ? absint($params['category_id']) : 0,
        );

        $events = new ECWPPlanning_Events();
        $id = $events->create_event($event_data);

        if ($id) {
            do_action('ecwp_planning_event_added', $id, $event_data);
            return new WP_REST_Response(array('success' => true, 'message' => __('Event successfully added', 'my-easy-compta')), 200);
        } else {
            return new WP_REST_Response(array('success' => false, 'message' => __('Failed to create event', 'my-easy-compta')), 400);
        }
    }

    public function get_events()
    {
        $events = new ECWPPlanning_Events();
        return new WP_REST_Response($events->get_events(), 200);
    }

    public function get_event($request)
    {
        $id = absint($request['id']);
        $events = new ECWPPlanning_Events();
        return new WP_REST_Response($events->get_event($id), 200);
    }

    public function update_event($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), array('status' => 403));
        }

        $id = absint($request['id']);
        $params = $request->get_json_params();

        $start = null;
        if (isset($params['start']['date']) && isset($params['start']['time'])) {
            $dt = $this->combine_date_time($params['start']['date'], $params['start']['time']);
            if (is_wp_error($dt)) return $dt;
            $start = $dt->format('Y-m-d H:i:s');
        } elseif (!empty($params['start']) && is_string($params['start'])) {
            $start = sanitize_text_field($params['start']);
        }

        $end = null;
        if (isset($params['end']['date']) && isset($params['end']['time'])) {
            $dt = $this->combine_date_time($params['end']['date'], $params['end']['time']);
            if (is_wp_error($dt)) return $dt;
            $end = $dt->format('Y-m-d H:i:s');
        } elseif (!empty($params['end']) && is_string($params['end'])) {
            $end = sanitize_text_field($params['end']);
        }

        $event_data = array(
            'title'       => sanitize_text_field($params['title'] ?? ''),
            'description' => sanitize_textarea_field($params['description'] ?? ''),
            'start'       => $start,
            'end'         => $end,
            'all_day'     => !empty($params['all_day']) ? 1 : 0,
            'category_id' => !empty($params['category_id']) ? absint($params['category_id']) : 0,
        );

        $events = new ECWPPlanning_Events();
        $result = $events->update_event($id, $event_data);

        if ($result !== false) {
            return new WP_REST_Response(array('success' => true, 'message' => __('Event successfully updated', 'my-easy-compta')), 200);
        } else {
            return new WP_REST_Response(array('success' => false, 'message' => __('Failed to update event', 'my-easy-compta')), 400);
        }
    }

    private function combine_date_time($date, $time)
    {
        $datetime_str = $date . ' ' . $time;
        try {
            return new \DateTime($datetime_str);
        } catch (\Exception $e) {
            return new \WP_Error('invalid_datetime', 'Invalid date or time format: ' . $datetime_str, ['status' => 400]);
        }
    }

    public function delete_event($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), array('status' => 403));
        }

        $id = absint($request['id']);
        $events = new ECWPPlanning_Events();
        $result = $events->delete_event($id);
        if ($result) {
            return new WP_REST_Response(array('success' => true, 'message' => __('Event successfully deleted', 'my-easy-compta')), 200);
        } else {
            return new WP_REST_Response(array('success' => false, 'message' => __('Failed to delete event', 'my-easy-compta')), 500);
        }
    }

    public function get_planning_categories()
    {
        global $wpdb;
        $cats = $wpdb->get_results("SELECT * FROM " . ECWP_TABLE_PLANNING_EVENTS_CATEGORIES, ARRAY_A);
        return rest_ensure_response($cats);
    }

    public function add_planning_categories(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), array('status' => 403));
        }
        global $wpdb;
        $params = $request->get_json_params();
        $name = sanitize_text_field($params['name'] ?? '');
        $background_raw = sanitize_text_field($params['background'] ?? '');
        $color_raw = sanitize_text_field($params['color'] ?? '');
        $background = sanitize_hex_color($background_raw) ?: $this->rgbToHex($background_raw);
        $color = sanitize_hex_color($color_raw) ?: $this->rgbToHex($color_raw);
        if ($color === null || $background === null) {
            return new WP_Error('planning_update_failed', __('Invalid color input', 'my-easy-compta'), ['status' => 500]);
        }

        $result = $wpdb->insert(
            ECWP_TABLE_PLANNING_EVENTS_CATEGORIES,
            [
                'name' => $name,
                'background' => $background,
                'color' => $color,
            ]
        );

        if ($result === false) {
            return new WP_Error('vat_creation_failed', __('Failed to create planning category', 'my-easy-compta'), ['status' => 500]);
        }
        $this->generate_css_for_categories();
        return new WP_REST_Response(['id' => $wpdb->insert_id, 'name' => $name], 201);
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return [type]
     */
    public function edit_planning_categories(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', __('Nonce verification failed.', 'my-easy-compta'), array('status' => 403));
        }
        global $wpdb;
        $params = $request->get_json_params();
        $id = absint($request->get_param('id'));
        $name = sanitize_text_field($params['name'] ?? '');
        $background_raw = sanitize_text_field($params['background'] ?? '');
        $color_raw = sanitize_text_field($params['color'] ?? '');
        $background = sanitize_hex_color($background_raw) ?: $this->rgbToHex($background_raw);
        $color = sanitize_hex_color($color_raw) ?: $this->rgbToHex($color_raw);
        if ($color === null || $background === null) {
            return new WP_Error('planning_update_failed', __('Invalid color input', 'my-easy-compta'), ['status' => 500]);
        }
        $result = $wpdb->update(
            ECWP_TABLE_PLANNING_EVENTS_CATEGORIES,
            [
                'name' => $name,
                'background' => $background,
                'color' => $color,
            ],
            ['id' => $id]
        );

        if ($result === false) {
            return new WP_Error('planning_update_failed', __('Failed to update planning category', 'my-easy-compta'), ['status' => 500]);
        }

        $this->generate_css_for_categories();
        return new WP_REST_Response(['id' => $id, 'name' => $name], 200);
    }

    /**
     * @param \WP_REST_Request $request
     *
     * @return [type]
     */
    public function delete_planning_categories(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', __('Nonce verification failed.', 'my-easy-compta'), array('status' => 403));
        }
        global $wpdb;
        $id = absint($request->get_param('id'));

        $result = $wpdb->delete(
            ECWP_TABLE_PLANNING_EVENTS_CATEGORIES,
            ['id' => $id]
        );

        if ($result === false) {
            return new WP_Error('planning_deletion_failed', __('Failed to delete planning category', 'my-easy-compta'), ['status' => 500]);
        }
        $this->generate_css_for_categories();

        return new WP_REST_Response(['id' => $id], 200);
    }

    function generate_css_for_categories()
    {
        global $wpdb;
        $categories = $wpdb->get_results($wpdb->prepare("SELECT id, background, color FROM %i", ECWP_TABLE_PLANNING_EVENTS_CATEGORIES));

        $css = "";
        foreach ($categories as $category) {
            $bg  = sanitize_hex_color($category->background) ?: '#000000';
            $col = sanitize_hex_color($category->color) ?: '#ffffff';
            $css .= ".planning-" . absint($category->id) . " {\n";
            $css .= "    background-color: {$bg};\n";
            $css .= "    border-color: {$bg};\n";
            $css .= "    color: {$col};\n";
            $css .= "}\n\n";
        }

        $css_file_path = ECWP_PLANNING_PATH_DIR . 'assets/css/event-categories.css';
        $css_dir_path = ECWP_PLANNING_PATH_DIR . 'assets/css/';
        if (!file_exists($css_dir_path)) {
            mkdir($css_dir_path, 0755, true);
        }
        file_put_contents($css_file_path, $css);
    }

    private function rgbToHex($rgb)
    {
        preg_match('/\((\d+), (\d+), (\d+)\)/', $rgb, $matches);

        if (count($matches) === 4) {
            $r = intval($matches[1]);
            $g = intval($matches[2]);
            $b = intval($matches[3]);
            return sprintf("#%02x%02x%02x", $r, $g, $b);
        } else {
            return null;
        }
    }

    public function create_quote_date_in_planning($data)
    {

        $quote_id = $data['id'];
        if (isset($data['due_date'])) {
            $due_date = $data['due_date'];
            $start_date = $due_date . ' 09:00:00';
            $end_date = $due_date . ' 17:00:00';
            $event_data = array(
                'title' => __('Reminder', 'my-easy-compta') . ' ' . $data['quote_number'],
                'start' => $start_date,
                'end' => $end_date,
                'description' => __('Reminder', 'my-easy-compta') . ' ' . $data['quote_number'] . ' <br />' . $data['due_date'],
            );

            $events = new ECWPPlanning_Events();
            $event_id = $events->create_event($event_data);
        }
    }
}
