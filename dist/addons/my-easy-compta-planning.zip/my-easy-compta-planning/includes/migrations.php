<?php
namespace ECWP\Planning;

class ECWPPlanning_Migrations
{
    public function plugin_activation()
    {
        $this->create_events_table();
        $this->create_events_categories_table();
        $this->database_update();
    }

    public function database_update()
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            'easy_compta_planning_addon_active'
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => 'easy_compta_planning_addon_active',
                'meta_value' => 1,
            ));
        }
    }

    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_planning_addon_active'));
    }

    public function create_events_table()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE " . ECWP_TABLE_PLANNING_EVENTS . " (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            description text NOT NULL,
            start datetime NOT NULL,
            end datetime NOT NULL,
            all_day tinyint(1) DEFAULT 0 NOT NULL,
            category_id INT(11) NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public function create_events_categories_table()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $categories_table = $wpdb->prefix . 'ecwp_events_categories';

        $sql = "CREATE TABLE $categories_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        background varchar(7) NOT NULL,
        color varchar(7) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
}
