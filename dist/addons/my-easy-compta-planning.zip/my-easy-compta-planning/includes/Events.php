<?php
namespace ECWP\Planning;

class ECWPPlanning_Events
{
    public function create_event($data)
    {
        global $wpdb;
        $wpdb->insert(ECWP_TABLE_PLANNING_EVENTS, $data);
        return $wpdb->insert_id;
    }

    public function get_event($id)
    {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM " . ECWP_TABLE_PLANNING_EVENTS . " WHERE id = %d", $id), ARRAY_A);
    }

    public function get_events()
    {
        global $wpdb;
        $events_table = ECWP_TABLE_PLANNING_EVENTS;
        $categories_table = ECWP_TABLE_PLANNING_EVENTS_CATEGORIES;

        $query = "
        SELECT e.id, e.title, e.description, e.start, e.end, e.all_day, c.id AS category_id, c.name AS category_name, c.color AS category_color
        FROM $events_table e
        LEFT JOIN $categories_table c ON e.category_id = c.id";

        $results = $wpdb->get_results($query);

        return $results;
    }

    public function update_event($id, $data)
    {
        global $wpdb;
        return $wpdb->update(ECWP_TABLE_PLANNING_EVENTS, $data, array('id' => $id));
    }

    public function delete_event($id)
    {
        global $wpdb;
        return $wpdb->delete(ECWP_TABLE_PLANNING_EVENTS, array('id' => $id));
    }
}
