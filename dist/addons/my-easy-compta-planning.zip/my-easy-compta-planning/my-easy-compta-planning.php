<?php
/**
 * Plugin Name: myEasyCompta - Planning Addon
 * Description: Integrate a planning module to manage your schedule. Create and assign tasks with specific categories, and track project deadlines and workloads efficiently.
 * Version: 2.0.0
 * Author: Moez
 * Author URI: https://moezbettoumi.fr
 * Text Domain: my-easy-compta-planning
 * Domain Path: /languages/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.9
 * Tested up to: 6.3
 * Requires PHP: 7.4
 * Tags: accounting, planning, Vue.js, TailwindCSS
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ECWP_Easy_Compta_Planning
{
    /**
     * Plugin version
     *
     * @var string
     */
    public $version = '2.0.0';

    /**
     * Minimum required PHP version
     *
     * @var string
     */
    private $min_php = '7.4';

    private $container = [];

    /**
     * Singleton instance
     *
     * @var ECWP_Easy_Compta_Planning
     */
    private static $instance;

    /**
     * Initialize the plugin
     *
     * @return ECWP_Easy_Compta_Planning
     */
    public static function init()
    {
        if (!isset(self::$instance) && !(self::$instance instanceof ECWP_Easy_Compta_Planning)) {
            self::$instance = new ECWP_Easy_Compta_Planning();
            self::$instance->setup();
        }

        return self::$instance;
    }

    /**
     * Setup the plugin
     *
     * @return void
     */
    private function setup()
    {
        register_activation_hook(__FILE__, [$this, 'auto_deactivate']);

        if (!$this->is_supported_php()) {
            return;
        }

        $this->define_constants();
        $this->includes();
        $this->instantiate();
        $this->init_actions();
    }

    /**
     * Define plugin constants
     *
     * @return void
     */
    private function define_constants()
    {
        global $wpdb;
        define('ECWP_PLANNING_PATH', dirname(__FILE__));
        define('ECWP_PLANNING_INCLUDES', ECWP_PLANNING_PATH . '/includes');
        define('ECWP_PLANNING_PATH_DIR', plugin_dir_path(__FILE__));
        define('ECWP_PLANNING_URL', plugins_url('', __FILE__));
        if (!defined('ECWP_PRINCIPAL_PATH')) {
            define('ECWP_PRINCIPAL_PATH', WP_CONTENT_DIR . '/plugins/my-easy-compta');
        }
        if (!defined('ECWP_PREFIX')) {
            define('ECWP_PREFIX', $wpdb->prefix);
        }

        define('ECWP_TABLE_PLANNING_EVENTS', ECWP_PREFIX . 'ecwp_events');
        define('ECWP_TABLE_PLANNING_EVENTS_CATEGORIES', ECWP_PREFIX . 'ecwp_events_categories');
    }

    /**
     * Include required files
     *
     * @return void
     */
    private function includes()
    {
        require_once ECWP_PRINCIPAL_PATH . '/includes/API/Routes.php';
        require_once ECWP_PLANNING_INCLUDES . '/migrations.php';
        require_once ECWP_PLANNING_INCLUDES . '/App.php';
        require_once ECWP_PLANNING_INCLUDES . '/Calendar.php';
        require_once ECWP_PLANNING_INCLUDES . '/Events.php';
    }

    private function instantiate()
    {
        $this->container['migration'] = new ECWP\Planning\ECWPPlanning_Migrations();
        $this->container['app'] = new ECWP\Planning\ECWPPlanning_APP();
        $this->container['calendar'] = new ECWP\Planning\ECWPPlanning_Calendar();
        $this->container['events'] = new ECWP\Planning\ECWPPlanning_Events();
    }

    private function init_actions()
    {
        register_activation_hook(__FILE__, [$this->container['migration'], 'plugin_activation']);
        register_deactivation_hook(__FILE__, [$this->container['migration'], 'plugin_desactivation']);
        add_action('admin_init', [$this, 'check_plugin_dependencies']);
    }

    /**
     * Check if the PHP version is supported
     *
     * @return bool
     */
    public function is_supported_php()
    {
        return version_compare(PHP_VERSION, $this->min_php, '>=');
    }

    /**
     * Deactivate the plugin if the PHP version is not supported
     *
     * @return void
     */
    public function auto_deactivate()
    {
        if (!$this->is_supported_php()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires PHP version %s or higher.',
                        'my-easy-compta-planning'
                    ),
                    esc_html__('myEasyCompta Planning', 'my-easy-compta-planning'),
                    esc_html($this->min_php)
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta-planning'),
                ['response' => 200, 'back_link' => true]
            );
        }
        if (!is_plugin_active('my-easy-compta/my-easy-compta.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires the myEasyCompta plugin to be active.',
                        'myEasyCompta Planning'
                    ),
                    esc_html__('myEasyCompta Planning', 'my-easy-compta')
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta'),
                ['response' => 200, 'back_link' => true]
            );
        }
    }
    /**
     * Check if myEasyCompta plugin are activated
     */
    public function check_plugin_dependencies()
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            add_action('admin_notices', [$this, 'display_missing_dependencies_notice']);
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }

    /**
     * Display a notice if myEasyCompta plugin are not activated
     */
    public function display_missing_dependencies_notice()
    {?>
<div class="notice notice-error is-dismissible">
    <p><?php _e('myEasyCompta Planning requires the myEasyCompta plugin to be activated. Please activate them before activating this plugin.', 'my-easy-compta');?>
    </p>
</div>
<?php
}
}

/**
 * Initialize the ECWP_Easy_Compta_Planning plugin
 *
 * @return ECWP_Easy_Compta_Planning
 */
ECWP_Easy_Compta_Planning::init();