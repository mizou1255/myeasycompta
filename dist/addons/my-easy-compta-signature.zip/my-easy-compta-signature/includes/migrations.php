<?php

namespace ECWP\Signature;

class ECWPSignature_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
    }
    public function database_update()
    {
        global $wpdb;
        $this->insert_meta_key_if_not_exists('easy_compta_signature_addon_active', 1);
        $column_id_exists = $wpdb->get_var("SHOW COLUMNS FROM " . ECWP_TABLE_QUOTES . " LIKE 'signed'");
        $column_file_exists = $wpdb->get_var("SHOW COLUMNS FROM " . ECWP_TABLE_QUOTES . " LIKE 'file_sign'");

        if (!$column_id_exists) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_QUOTES . " ADD COLUMN signed tinyint(1) NOT NULL DEFAULT 0");
        }
        if (!$column_file_exists) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_QUOTES . " ADD COLUMN file_sign TEXT NULL DEFAULT NULL");
        }

    }
    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_signature_addon_active'));
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_QUOTES . " DROP COLUMN IF EXISTS signed");
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_QUOTES . " DROP COLUMN IF EXISTS file_sign");
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                ECWP_TABLE_SETTINGS,
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }
}
