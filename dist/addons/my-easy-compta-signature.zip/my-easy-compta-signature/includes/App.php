<?php

namespace ECWP\Signature;

use ECWP\API\Routes;

class ECWPSignature_APP
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    /**
     * @return [type]
     */
    public function register_api_routes()
    {
        $this->routes->add_route('/signature/sign-quote', 'POST', $this, 'process_quote_signature', function () {
            return current_user_can('subscriber');
        });
        $this->routes->add_route('/signature-image/(?P<filename>[^/]+)', 'GET', $this, 'serve_signature_image', function () {
            return current_user_can('manage_options');
        });

        $this->routes->register_routes();
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    public function process_quote_signature(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_REST_Response(array('message' => __('Invalid nonce', 'my-easy-compta')), 403);
        }

        if (!$this->has_valid_license()) {
            return new \WP_REST_Response(array('message' => 'License required'), 403);
        }

        $params = $request->get_json_params();

        if (!isset($params['id']) || !isset($params['signature'])) {
            return new \WP_REST_Response(array('message' => 'Missing parameters'), 400);
        }

        $quote_id = absint($params['id']);

        // Verify the quote belongs to the authenticated user's client record
        $current_user_id = get_current_user_id();
        if ($current_user_id && !current_user_can('manage_options')) {
            global $wpdb;
            $client_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM " . ECWP_TABLE_CLIENTS . " WHERE user_id = %d",
                $current_user_id
            ));
            if (!$client_id) {
                return new \WP_REST_Response(array('message' => __('Client not found', 'my-easy-compta')), 403);
            }
            $quote_owner = $wpdb->get_var($wpdb->prepare(
                "SELECT client_id FROM " . ECWP_TABLE_QUOTES . " WHERE id = %d",
                $quote_id
            ));
            if ((int) $quote_owner !== (int) $client_id) {
                return new \WP_REST_Response(array('message' => __('Access denied', 'my-easy-compta')), 403);
            }
        }
        $signature_data = $params['signature'];

        $upload_dir = wp_upload_dir();
        $upload_path = $upload_dir['basedir'] . '/signatures/';

        if (!file_exists($upload_path)) {
            mkdir($upload_path, 0750, true);
            $htaccess_file = $upload_path . '.htaccess';
            if (!file_exists($htaccess_file)) {
                $htaccess_content = "
                    # Empêcher l'accès direct aux fichiers
                    <FilesMatch \"\.\">
                        Order Deny,Allow
                        Deny from all
                    </FilesMatch>
                    ";
                file_put_contents($htaccess_file, $htaccess_content);
            }
        }

        $file_name = 'signature_' . $quote_id . '_' . uniqid() . '.png';
        $file_path = $upload_path . $file_name;

        $image_data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $signature_data["data"]));

        if ($image_data === false) {
            return new \WP_REST_Response(array('message' => 'Invalid image data'), 400);
        }

        if (file_put_contents($file_path, $image_data) === false) {
            return new \WP_REST_Response(array('message' => 'Failed to save image'), 500);
        }

        global $wpdb;
        $wpdb->update(
            ECWP_TABLE_QUOTES,
            array('signed' => 1, 'status' => 'approved', 'file_sign' => $file_name),
            array('id' => $quote_id),
            array('%d', '%s', '%s'),
            array('%d')
        );

        return new \WP_REST_Response(array('message' => __('Quote signed successfully', 'my-easy-compta')), 200);
    }

    public function serve_signature_image(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_param('_wpnonce')));
        $valid_nonce = wp_verify_nonce($nonce, 'wp_rest');
        $has_permission = current_user_can('manage_options');

        if (!$valid_nonce) {
            // Nonce invalid – no sensitive data logged.
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        if (!$has_permission) {
            // Permission denied.
            return new \WP_Error('rest_forbidden', __('API access error', 'my-easy-compta'), array('status' => 403));
        }

        // Use basename() to strip any directory components and prevent path traversal.
        $filename   = basename(sanitize_file_name($request->get_param('filename')));
        $upload_dir = wp_upload_dir();
        $signatures_dir = $upload_dir['basedir'] . '/signatures/';
        $file_path  = $signatures_dir . $filename;

        // Resolve real paths and confirm the file stays inside the signatures directory.
        $real_signatures_dir = realpath($signatures_dir);
        $real_file_path      = realpath($file_path);

        if (
            !$real_file_path ||
            !$real_signatures_dir ||
            strpos($real_file_path, $real_signatures_dir . DIRECTORY_SEPARATOR) !== 0
        ) {
            return new \WP_REST_Response(array('message' => 'File not found'), 404);
        }

        if (!file_exists($real_file_path)) {
            return new \WP_REST_Response(array('message' => 'File not found'), 404);
        }

        $file_type = wp_check_filetype($real_file_path);
        $mime      = !empty($file_type['type']) ? $file_type['type'] : 'application/octet-stream';

        header('Content-Type: ' . $mime);
        readfile($real_file_path);
        exit;
    }

}
