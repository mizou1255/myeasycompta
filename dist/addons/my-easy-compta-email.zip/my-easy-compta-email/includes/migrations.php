<?php
namespace ECWP\Emails;

class ECWPEmail_Migrations
{
    public function plugin_activation()
    {
        $this->create_email_log_table();
        $this->database_update();
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                ECWP_TABLE_SETTINGS,
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }

    public function database_update()
    {
        global $wpdb;
        $this->insert_meta_key_if_not_exists('easy_compta_email_addon_active', '1');
        $this->insert_meta_key_if_not_exists('email_log_active', '1');
        $this->insert_meta_key_if_not_exists('email_quote_subject', __('New quote', 'my-easy-compta'));
        $this->insert_meta_key_if_not_exists('email_invoice_subject', __('New invoice', 'my-easy-compta'));
        $this->insert_meta_key_if_not_exists('email_quote_content', '<h4>Devis n° {REF}</h4><p><br></p><p>Bonjour <strong>{CLIENT}</strong>,</p><p>Le devis <strong>{REF}</strong> est joint à cet e-mail.</p><p><br></p><p>Récap de devis:</p><p>Réf n° : <strong>{REF}</strong></p><p>Montant : <strong>{AMOUNT}{CURRENCY}</strong></p><p>Créé: <strong>{CREATED_DATE}</strong></p><p>Date de validité: <strong>{DUE_DATE}</strong></p><p><br></p><p>Cordialement.</p>');
        $this->insert_meta_key_if_not_exists('email_invoice_content', '<h4>Facture n° {REF}</h4><p><br></p><p>Bonjour <strong>{CLIENT}</strong>,</p><p><br></p><p>Vous trouverez ci-joint la facture de <strong>{AMOUNT}{CURRENCY}.</strong></p><p><br></p><p>Cordialement.</p>');
        $this->insert_meta_key_if_not_exists('remind_invoice_subject', __('Remind invoice', 'my-easy-compta'));
        $this->insert_meta_key_if_not_exists('remind_invoice_content', '<h4>Facture n° {REF}</h4><p><br></p><p>Bonjour <strong>{CLIENT}</strong>,</p><p><br></p><p>Sauf erreur de notre part, nous sommes toujours en attente de paiement de la facture n°<strong> {REF}</strong>, et d\'un montant de <strong>{AMOUNT}{CURRENCY}.</strong></p><p><br></p><p>Nous vous saurions gré de procéder au paiement dans les meilleurs délais.</p><p><br></p><p>Dans le cas où votre règlement aurait été adressé entre temps, nous vous prions de ne pas tenir compte de cet e-mail.</p><p><br></p><p>Vous remerciant de faire le nécessaire, et restant à votre entière disposition pour toute question, nous vous prions d\'agréer, Madame, Monsieur, l\'expression de nos salutations distinguées.</p><p><br></p><p>Cordialement.</p>');

        $this->add_sent_column_if_not_exists(ECWP_TABLE_INVOICES);
        $this->add_sent_column_if_not_exists(ECWP_TABLE_QUOTES);
    }

    private function add_sent_column_if_not_exists($table_name)
    {
        global $wpdb;
        $sent_column_exists = $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'sent'");

        if (!$sent_column_exists) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN sent tinyint(1) NOT NULL DEFAULT 0");
        }
    }

    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_email_addon_active'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'email_log_active'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'email_quote_subject'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'email_invoice_subject'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'email_quote_content'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'email_invoice_content'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'remind_invoice_subject'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'remind_invoice_content'));
    }

    public function create_email_log_table()
    {
        global $wpdb;

        $table_name = ECWP_TABLE_EMAILS_LOG;
        $charset_collate = $wpdb->get_charset_collate();

        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {

            $sql = "CREATE TABLE $table_name (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                recipient_email varchar(255) NOT NULL,
                subject varchar(255) NOT NULL,
                message text NOT NULL,
                sent_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset_collate;";

            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);

            if ($wpdb->last_error) {
                error_log("Database error on table creation: " . $wpdb->last_error);
            }
        }
    }
}
