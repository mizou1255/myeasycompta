<?php

namespace ECWP\Emails;

class ECWPEmail_APP
{
    public function __construct()
    {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_menu', [$this, 'add_menu_page'], 20);
    }

    public function enqueue_scripts($hook)
    {
        $pages = array(
            'my-easy-compta_page_my-easy-compta-email',
            'myeasycompta_page_my-easy-compta-email',
        );

        if (!in_array($hook, $pages)) {
            return;
        }

        if (defined('ECWP_URL') && defined('ECWP_VERSION')) {
            wp_enqueue_style('my-easy-compta-admin-style', ECWP_URL . '/assets/dist/style.min.css', array(), ECWP_VERSION);
        }

        wp_enqueue_style('my-easy-compta-email-app-css', ECWP_EMAIL_URL . '/assets/dist/app.min.css', array(), ECWP_VERSION);

        wp_enqueue_script('my-easy-compta-email', ECWP_EMAIL_URL . '/assets/dist/app.min.js', array(), ECWP_VERSION, true);
        add_filter('script_loader_tag', array($this, 'add_type_attribute'), 10, 2);

        if (file_exists(ECWP_PATH . '/languages/my-easy-compta-translations.php')) {
            require_once ECWP_PATH . '/languages/my-easy-compta-translations.php';
            wp_localize_script('my-easy-compta-email', 'myEasyComptaAdmin', array(
                'nonce' => wp_create_nonce('wp_rest'),
                'easyComptaTranslations' => $translations ?? array(),
            ));
        }
    }

    /**
     * @param mixed $tag
     * @param mixed $handle
     *
     * @return [type]
     */
    public function add_type_attribute($tag, $handle)
    {
        $scripts = array(
            'my-easy-compta-email',
        );

        if (in_array($handle, $scripts)) {
            return str_replace(' src', ' type="module" src', $tag);
        }

        return $tag;
    }

    public function add_menu_page()
    {
        add_submenu_page(
            'my-easy-compta',
            __('myEasyCompta Emails', 'my-easy-compta'),
            __('Emails <sup>PRO</sup>', 'my-easy-compta'),
            'manage_options',
            'my-easy-compta-email',
            array($this, 'admin_page')
        );
    }

    public function admin_page()
    {
        if (!$this->has_valid_license()) {
            echo '<div class="admin-overlay">
                <div>
                    <p><strong>Licence requise</strong></p>
                    <p>Vous devez acheter une licence pour utiliser ce plugin. Veuillez <a href="' . esc_url(admin_url('admin.php?page=my-easy-compta#/settings?tab=16')) . '">ajouter votre clé de licence ici</a>.</p>
                    <p>Ce plugin ne peut pas être utilisé sans une licence valide.</p>
                </div>
            </div>';
            echo '<div id="my-easy-compta-email-app" class="ecwp-content blur-app"></div>';
        } else {
            echo '<div id="my-easy-compta-email-app" class="ecwp-content"></div>';
        }
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }
}
