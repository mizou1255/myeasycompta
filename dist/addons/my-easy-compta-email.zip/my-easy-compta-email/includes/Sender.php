<?php

namespace ECWP\Emails;

use ECWP\Admin\PDF\PDFGenerator;
use ECWP\API\Routes;
use Exception;
use WP_Error;
use WP_REST_Response;

class ECWPEmail_Sender
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/emails/send-email', 'POST', $this, 'send_email_quote_invoice', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/emails/preview', 'POST', $this, 'preview_email', function () {
            return current_user_can('manage_options');
        });

        $this->routes->register_routes();
    }

    public function send_email_quote_invoice($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        global $wpdb;
        $params = $request->get_params();
        $client_email = sanitize_email($params['client_email']);
        $email_subject = sanitize_text_field($params['email_subject']);
        $email_message = wp_kses_post($params['email_message']);
        $id = absint($params['id']);
        $type = sanitize_text_field($params['type']);
        $variables = [];

        if (!is_email($client_email)) {
            return new WP_Error('invalid_email', 'Invalid email address', array('status' => 400));
        }
        $variables_or_error = $this->get_email_variables($id, $type);
        if (is_wp_error($variables_or_error)) {
            return $variables_or_error;
        }
        ['variables' => $variables, 'table_name' => $table_name, 'pdf_path_generator' => $pdf_path_generator] = $variables_or_error;

        try {
            $pdfGenerator = new PDFGenerator($wpdb);
            if ($type === 'quote') {
                $pdf_file_path = $pdfGenerator->generateQuotePDF($id, 'email');
            } else {
                $pdf_file_path = $pdfGenerator->generateInvoicePDF($id, null, 'email');
            }
        } catch (Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('PDF generation error: ' . $e->getMessage());
            }
            return new WP_Error('pdf_generation_error', __('Failed to generate PDF', 'my-easy-compta'), array('status' => 500));
        }

        $attachments = array($pdf_file_path);
        $headers = array('Content-Type: text/html; charset=UTF-8');

        foreach ($variables as $key => $value) {
            $email_message = str_replace($key, $value, $email_message);
        }

        $mail_sent = wp_mail($client_email, $email_subject, $email_message, $headers, $attachments);

        if ($mail_sent) {
            unlink($pdf_file_path);
            $update_result = $wpdb->update(
                $table_name,
                array('sent' => 1),
                array('id' => $id),
                array('%d'),
                array('%d')
            );
            if ($this->is_email_log_active() === '1') {
                $this->log_email($client_email, $email_subject, $email_message);
            }

            return new WP_REST_Response(array(
                'message' => 'Email sent successfully with attachment',
            ), 200);
        } else {
            return new WP_Error('email_not_sent', 'Failed to send email', array('status' => 500));
        }
    }

    /**
     * Build the variable substitution map for a given invoice/quote.
     * Returns array with keys 'variables' and 'table_name', or WP_Error on failure.
     */
    private function get_email_variables(int $id, string $type)
    {
        global $wpdb;
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        // Resolve {COMPANY_NAME} from settings
        $company_name = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM %i WHERE meta_key = 'company_name'",
            ECWP_TABLE_SETTINGS
        )) ?: '';

        if ($type === 'invoice' || $type === 'remind') {
            $result = $wpdb->get_row($wpdb->prepare(
                "SELECT inv.invoice_number, inv.due_date, inv.total_amount,
                        c.manager_name AS client_name, curr.symbol AS currency_symbol
                 FROM %i AS inv
                 LEFT JOIN %i AS c   ON inv.client_id  = c.id
                 LEFT JOIN %i AS curr ON c.currency_id  = curr.id
                 WHERE inv.id = %d",
                ECWP_TABLE_INVOICES, ECWP_TABLE_CLIENTS, ECWP_TABLE_CURRENCY, $id
            ));
            if (!$result) {
                return new WP_Error('not_found', __('Invoice not found', 'my-easy-compta'), array('status' => 404));
            }
            $inv_number = $encrypt->decrypt($result->invoice_number);
            $inv_amount = number_format((float) $encrypt->decrypt($result->total_amount), 2, '.', ',');
            $inv_amount_currency = $inv_amount . ' ' . $result->currency_symbol;
            return [
                'table_name'        => ECWP_TABLE_INVOICES,
                'pdf_path_generator' => 'invoice',
                'variables' => [
                    // Short English (legacy)
                    '{REF}'              => $inv_number,
                    '{AMOUNT}'           => $inv_amount,
                    '{CURRENCY}'         => $result->currency_symbol,
                    '{DUE_DATE}'         => wp_date('d-m-Y', strtotime($result->due_date)),
                    '{CLIENT}'           => $result->client_name,
                    '{COMPANY_NAME}'     => $company_name,
                    // Full English
                    '{INVOICE_NUMBER}'   => $inv_number,
                    '{CLIENT_NAME}'      => $result->client_name,
                    // French (defaults in Settings.vue)
                    '{numero_document}'  => $inv_number,
                    '{nom_client}'       => $result->client_name,
                    '{montant_total}'    => $inv_amount_currency,
                ],
            ];
        }

        if ($type === 'quote') {
            $result = $wpdb->get_row($wpdb->prepare(
                "SELECT q.quote_number, q.created_at, q.due_date, q.total_amount,
                        c.manager_name AS client_name, curr.symbol AS currency_symbol
                 FROM %i AS q
                 LEFT JOIN %i AS c    ON q.client_id  = c.id
                 LEFT JOIN %i AS curr ON c.currency_id = curr.id
                 WHERE q.id = %d",
                ECWP_TABLE_QUOTES, ECWP_TABLE_CLIENTS, ECWP_TABLE_CURRENCY, $id
            ));
            if (!$result) {
                return new WP_Error('not_found', __('Quote not found', 'my-easy-compta'), array('status' => 404));
            }
            $quote_amount = number_format((float) $result->total_amount, 2, '.', ',');
            $quote_amount_currency = $quote_amount . ' ' . $result->currency_symbol;
            return [
                'table_name'        => ECWP_TABLE_QUOTES,
                'pdf_path_generator' => 'quote',
                'variables' => [
                    // Short English (legacy)
                    '{REF}'              => $result->quote_number,
                    '{AMOUNT}'           => $quote_amount,
                    '{CURRENCY}'         => $result->currency_symbol,
                    '{CREATED_DATE}'     => wp_date('d-m-Y', strtotime($result->created_at)),
                    '{DUE_DATE}'         => wp_date('d-m-Y', strtotime($result->due_date)),
                    '{CLIENT}'           => $result->client_name,
                    '{COMPANY_NAME}'     => $company_name,
                    // Full English
                    '{QUOTE_NUMBER}'     => $result->quote_number,
                    '{CLIENT_NAME}'      => $result->client_name,
                    // French (defaults in Settings.vue)
                    '{numero_document}'  => $result->quote_number,
                    '{nom_client}'       => $result->client_name,
                    '{montant_total}'    => $quote_amount_currency,
                ],
            ];
        }

        return new WP_Error('invalid_type', 'Invalid type', array('status' => 400));
    }

    public function preview_email(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $id      = absint($request->get_param('id'));
        $type    = sanitize_text_field($request->get_param('type'));
        $message = wp_kses_post($request->get_param('email_message'));

        $variables_or_error = $this->get_email_variables($id, $type);
        if (is_wp_error($variables_or_error)) {
            return $variables_or_error;
        }

        foreach ($variables_or_error['variables'] as $key => $value) {
            $message = str_replace($key, $value, $message);
        }

        return rest_ensure_response(['html' => $message]);
    }

    // Method to check if email logging is active
    private function is_email_log_active()
    {
        global $wpdb;
        $result = $wpdb->get_var("SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = 'email_log_active'");
        return $result;
    }

    // Method to log the email
    private function log_email($to, $subject, $message)
    {
        global $wpdb;
        $wpdb->insert(
            ECWP_TABLE_EMAILS_LOG,
            array(
                'recipient_email' => $to,
                'subject' => $subject,
                'message' => $message,
                'sent_at' => current_time('mysql'),
            ),
            array(
                '%s',
                '%s',
                '%s',
                '%s',
            )
        );
    }

}