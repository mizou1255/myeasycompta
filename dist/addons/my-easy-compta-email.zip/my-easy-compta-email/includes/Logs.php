<?php
namespace ECWP\Emails;

use ECWP\API\Routes;

class ECWPEmail_Logs
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/emails-logs', 'GET', $this, 'get_emails_logs', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/emails-logs/(?P<id>\d+)', 'DELETE', $this, 'delete_log', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/emails-logs/(?P<id>\d+)', 'GET', $this, 'get_log', function () {
            return current_user_can('manage_options');
        });

        $this->routes->register_routes();
    }

    // Function to get all email logs with pagination
    public function get_emails_logs($request)
    {
        global $wpdb;
        $per_page = isset($request['per_page']) ? intval($request['per_page']) : 10;
        $page = isset($request['page']) ? intval($request['page']) : 1;
        $offset = ($page - 1) * $per_page;
        $total_count = $wpdb->get_var("SELECT COUNT(*) FROM " . ECWP_TABLE_EMAILS_LOG);

        $query = $wpdb->prepare("SELECT * FROM " . ECWP_TABLE_EMAILS_LOG . " ORDER BY sent_at DESC LIMIT %d OFFSET %d", $per_page, $offset);
        $results = $wpdb->get_results($query);

        $total_pages = ceil($total_count / $per_page);

        $response = array(
            'logs' => $results,
            'total_count' => $total_count,
            'total_pages' => $total_pages,
            'page' => $page,
            'per_page' => $per_page,
        );

        return rest_ensure_response($response);
    }

    // Function to delete a specific email log by ID
    public function delete_log($request)
    {
        global $wpdb;
        $id = absint($request['id']);

        $deleted = $wpdb->delete(
            ECWP_TABLE_EMAILS_LOG,
            array('id' => $id),
            array('%d')
        );

        if ($deleted === false) {
            return new \WP_REST_Response(array('success' => false, 'message' => __('Failed to delete log', 'my-easy-compta')), 500);
        }
        return new \WP_REST_Response(array('success' => true, 'message' => __('Log deleted successfully', 'my-easy-compta')), 200);
    }

    // Function to get a specific email log by ID
    public function get_log($request)
    {
        global $wpdb;
        $id = absint($request['id']);

        $log = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . ECWP_TABLE_EMAILS_LOG . " WHERE id = %d",
            $id
        ));

        if (empty($log)) {
            return new \WP_Error('log_not_found', 'Log not found', array('status' => 404));
        }

        return new \WP_REST_Response($log, 200);
    }
}
