<?php
/**
 * Plugin Name: myEasyCompta - Contrats
 * Description: Créez et gérez des contrats professionnels avec variables dynamiques, génération PDF et suivi de signature. Module complémentaire pour myEasyCompta.
 * Version: 1.0.0
 * Author: MELIOZ.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-contracts
 * Domain Path: /languages/
 * Requires at least: 6.2
 * Tested up to: 6.9
 * Requires PHP: 8.0
 * Requires Plugins: my-easy-compta
 * Tags: contracts, pdf, signature, freelance
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ECWP_CONTRACTS_VERSION', '1.0.0');
define('ECWP_CONTRACTS_PATH',    plugin_dir_path(__FILE__));
define('ECWP_CONTRACTS_URL',     plugins_url('', __FILE__));
define('ECWP_CONTRACTS_INCLUDES', ECWP_CONTRACTS_PATH . 'includes');

// Table constant (uses core prefix, defined after core loads)
add_action('plugins_loaded', function () {
    if (!defined('ECWP_PREFIX')) return;
    if (!defined('ECWP_TABLE_CONTRACTS')) {
        define('ECWP_TABLE_CONTRACTS', ECWP_PREFIX . 'ecwp_contracts');
    }
}, 5);

// Boot addon
add_action('plugins_loaded', function () {
    if (!class_exists('ECWP_Easy_Compta')) return; // Core required

    require_once ECWP_CONTRACTS_INCLUDES . '/Migration.php';
    require_once ECWP_CONTRACTS_INCLUDES . '/Contracts.php';

    // Run migration on admin_init
    add_action('admin_init', 'ecwp_contracts_maybe_migrate');

    // Register REST routes
    new ECWP\Addon\Contracts\ECWP_Contracts();

    // Enqueue addon JS (Vue component injected via wp_localize_script hook)
    add_action('admin_enqueue_scripts', 'ecwp_contracts_enqueue');
}, 20);

// ── Migration ────────────────────────────────────────────────────────────────
function ecwp_contracts_maybe_migrate()
{
    if (get_option('ecwp_contracts_db_version') !== '1.0.0') {
        ecwp_contracts_run_migration();
    }
}

// ── Enqueue ──────────────────────────────────────────────────────────────────
function ecwp_contracts_enqueue($hook)
{
    if ($hook !== 'toplevel_page_my-easy-compta') return;

    // Signal to the core Vue app that the contracts addon is active.
    // The core Sidebar.vue reads window.myEasyComptaAdmin.contractsAddonActive to show the menu item.
    wp_add_inline_script(
        'my-easy-compta-admin',
        'if(window.myEasyComptaAdmin){window.myEasyComptaAdmin.contractsAddonActive=true;}',
        'after'
    );
}

// ── Activation / Deactivation ─────────────────────────────────────────────────
register_activation_hook(__FILE__, function () {
    if (!defined('ECWP_PREFIX')) {
        global $wpdb;
        define('ECWP_PREFIX', $wpdb->prefix);
    }
    if (!defined('ECWP_TABLE_CONTRACTS')) {
        define('ECWP_TABLE_CONTRACTS', ECWP_PREFIX . 'ecwp_contracts');
    }
    require_once ECWP_CONTRACTS_INCLUDES . '/Migration.php';
    ecwp_contracts_run_migration();
});
