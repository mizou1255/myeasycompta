<?php

if (!defined('ABSPATH')) exit;

function ecwp_contracts_run_migration()
{
    global $wpdb;

    if (!defined('ECWP_TABLE_CONTRACTS')) return;

    $charset = $wpdb->get_charset_collate();
    $table   = ECWP_TABLE_CONTRACTS;

    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id          int(11) NOT NULL AUTO_INCREMENT,
        client_id   int(11) DEFAULT NULL,
        invoice_id  int(11) DEFAULT NULL,
        quote_id    int(11) DEFAULT NULL,
        title       varchar(255) NOT NULL DEFAULT '',
        body        longtext,
        variables   longtext COMMENT 'JSON key-value pairs',
        status      varchar(20) NOT NULL DEFAULT 'draft',
        signed_at   datetime DEFAULT NULL,
        sent_at     datetime DEFAULT NULL,
        created_at  datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at  datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_client_id (client_id),
        KEY idx_status (status)
    ) {$charset};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    update_option('ecwp_contracts_db_version', '1.0.0');

    ecwp_contracts_seed_default_template();
}

function ecwp_contracts_seed_default_template()
{
    global $wpdb;

    if (!defined('ECWP_TABLE_CONTRACTS')) return;

    // Only insert if the table is empty
    $count = (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . ECWP_TABLE_CONTRACTS);
    if ($count > 0) return;

    $body = '<h2 style="text-align:center;">CONTRAT DE PRESTATION DE SERVICES</h2>

<p>Entre les soussignés :</p>

<p><strong>Le Prestataire :</strong><br>
{PRESTATAIRE_NOM}<br>
{PRESTATAIRE_ADRESSE}<br>
SIRET : {PRESTATAIRE_SIRET}</p>

<p><strong>Le Client :</strong><br>
{CLIENT_NOM}<br>
{CLIENT_ADRESSE}</p>

<p>Il a été convenu ce qui suit :</p>

<h3>Article 1 — Objet de la mission</h3>
<p>{OBJET_MISSION}</p>

<h3>Article 2 — Durée</h3>
<p>La mission débutera le <strong>{DATE_DEBUT}</strong> et se terminera le <strong>{DATE_FIN}</strong>.</p>

<h3>Article 3 — Rémunération</h3>
<p>En contrepartie des services rendus, le Client versera au Prestataire la somme de <strong>{MONTANT} €</strong> HT, selon les modalités suivantes : {MODALITES_PAIEMENT}.</p>

<h3>Article 4 — Obligations du Prestataire</h3>
<p>Le Prestataire s\'engage à réaliser les missions décrites à l\'article 1 avec soin et professionnalisme, dans le respect des délais convenus.</p>

<h3>Article 5 — Confidentialité</h3>
<p>Le Prestataire s\'engage à garder confidentielles toutes les informations relatives au Client dont il pourrait avoir connaissance dans le cadre de la présente mission.</p>

<h3>Article 6 — Propriété intellectuelle</h3>
<p>Sauf disposition contraire, les livrables produits dans le cadre de cette mission sont cédés au Client à compter du paiement intégral de la facture.</p>

<h3>Article 7 — Résiliation</h3>
<p>Chacune des parties pourra résilier le présent contrat avec un préavis de <strong>{DELAI_RESILIATION}</strong> par lettre recommandée avec accusé de réception.</p>

<h3>Article 8 — Loi applicable</h3>
<p>Le présent contrat est soumis au droit français. Tout litige relèvera de la compétence des tribunaux compétents.</p>

<p>Fait à {LIEU}, le {DATE_SIGNATURE}</p>

<table style="width:100%;margin-top:40px;">
  <tr>
    <td style="width:50%;vertical-align:top;">
      <p><strong>Signature du Prestataire</strong></p>
      <br><br><br>
      <p>_______________________________</p>
    </td>
    <td style="width:50%;vertical-align:top;">
      <p><strong>Signature du Client</strong></p>
      <br><br><br>
      <p>_______________________________</p>
    </td>
  </tr>
</table>';

    $variables = wp_json_encode([
        'PRESTATAIRE_NOM'     => '',
        'PRESTATAIRE_ADRESSE' => '',
        'PRESTATAIRE_SIRET'   => '',
        'CLIENT_NOM'          => '{client_name}',
        'CLIENT_ADRESSE'      => '{client_address}',
        'OBJET_MISSION'       => '',
        'DATE_DEBUT'          => '',
        'DATE_FIN'            => '',
        'MONTANT'             => '',
        'MODALITES_PAIEMENT'  => '30 jours fin de mois',
        'DELAI_RESILIATION'   => '15 jours',
        'LIEU'                => '',
        'DATE_SIGNATURE'      => wp_date('d/m/Y'),
    ], JSON_UNESCAPED_UNICODE);

    $wpdb->insert(
        ECWP_TABLE_CONTRACTS,
        [
            'title'     => 'Modèle — Contrat de prestation de services',
            'body'      => $body,
            'variables' => $variables,
            'status'    => 'draft',
        ],
        ['%s', '%s', '%s', '%s']
    );
}
