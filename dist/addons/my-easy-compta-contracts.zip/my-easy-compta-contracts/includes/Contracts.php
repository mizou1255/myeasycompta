<?php

namespace ECWP\Addon\Contracts;

use ECWP\API\Routes;

/**
 * Contracts addon — REST endpoints for contract management.
 *
 * GET    /contracts              list (paginated)
 * POST   /contracts              create
 * GET    /contracts/variables    available template variables
 * GET    /contracts/{id}         single
 * PUT    /contracts/{id}         update
 * DELETE /contracts/{id}         delete
 * GET    /contracts/{id}/pdf     PDF download
 */
class ECWP_Contracts
{
    public function __construct()
    {
        $routes = new Routes();
        $auth   = fn () => current_user_can('manage_options');

        $routes->add_route('/contracts',                  'GET',    $this, 'get_contracts',   $auth);
        $routes->add_route('/contracts',                  'POST',   $this, 'add_contract',    $auth);
        $routes->add_route('/contracts/variables',        'GET',    $this, 'get_variables',   $auth);
        $routes->add_route('/contracts/(?P<id>\d+)',      'GET',    $this, 'get_contract',    $auth);
        $routes->add_route('/contracts/(?P<id>\d+)',      'PUT',    $this, 'update_contract', $auth);
        $routes->add_route('/contracts/(?P<id>\d+)',      'DELETE', $this, 'delete_contract', $auth);
        $routes->add_route('/contracts/(?P<id>\d+)/pdf',  'GET',    $this, 'download_pdf',    $auth);
        $routes->register_routes();
    }

    // ── List ─────────────────────────────────────────────────────────────────

    public function get_contracts($request)
    {
        global $wpdb;

        $per_page = max(1, (int) ($request->get_param('per_page') ?: 20));
        $page     = max(1, (int) ($request->get_param('page')     ?: 1));
        $offset   = ($page - 1) * $per_page;
        $status   = $request->get_param('status');
        $search   = $request->get_param('search');

        $where  = 'WHERE 1=1';
        $params = [];

        if ($status) {
            $where   .= ' AND c.status = %s';
            $params[] = sanitize_text_field($status);
        }
        if ($search) {
            $where   .= ' AND c.title LIKE %s';
            $params[] = '%' . $wpdb->esc_like(sanitize_text_field($search)) . '%';
        }

        $total_query = "SELECT COUNT(*) FROM " . ECWP_TABLE_CONTRACTS . " c $where";
        $total = (int) ($params
            ? $wpdb->get_var($wpdb->prepare($total_query, ...$params))
            : $wpdb->get_var($total_query));

        $rows_query = "SELECT c.*, cl.company_name AS client_name
             FROM " . ECWP_TABLE_CONTRACTS . " c
             LEFT JOIN " . ECWP_TABLE_CLIENTS . " cl ON cl.id = c.client_id
             $where
             ORDER BY c.created_at DESC
             LIMIT %d OFFSET %d";

        $rows = $wpdb->get_results(
            $wpdb->prepare($rows_query, ...[...$params, $per_page, $offset]),
            ARRAY_A
        );

        return [
            'data'      => $rows ?: [],
            'total'     => $total,
            'per_page'  => $per_page,
            'page'      => $page,
            'last_page' => (int) ceil($total / $per_page),
        ];
    }

    // ── Single ───────────────────────────────────────────────────────────────

    public function get_contract($request)
    {
        $id  = (int) $request->get_param('id');
        $row = $this->fetch_contract($id);
        if (!$row) {
            return new \WP_Error('not_found', 'Contrat introuvable.', ['status' => 404]);
        }
        return $row;
    }

    // ── Create ────────────────────────────────────────────────────────────────

    public function add_contract($request)
    {
        global $wpdb;

        $data = $this->sanitize($request);
        if (is_wp_error($data)) return $data;

        $wpdb->insert(ECWP_TABLE_CONTRACTS, $data, $this->formats($data));

        if ($wpdb->last_error) {
            return new \WP_Error('db_error', $wpdb->last_error, ['status' => 500]);
        }

        return $this->fetch_contract($wpdb->insert_id);
    }

    // ── Update ────────────────────────────────────────────────────────────────

    public function update_contract($request)
    {
        global $wpdb;

        $id = (int) $request->get_param('id');
        if (!$this->fetch_contract($id)) {
            return new \WP_Error('not_found', 'Contrat introuvable.', ['status' => 404]);
        }

        $data = $this->sanitize($request);
        if (is_wp_error($data)) return $data;

        $wpdb->update(ECWP_TABLE_CONTRACTS, $data, ['id' => $id], $this->formats($data), ['%d']);

        if ($wpdb->last_error) {
            return new \WP_Error('db_error', $wpdb->last_error, ['status' => 500]);
        }

        return $this->fetch_contract($id);
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    public function delete_contract($request)
    {
        global $wpdb;

        $id      = (int) $request->get_param('id');
        $deleted = $wpdb->delete(ECWP_TABLE_CONTRACTS, ['id' => $id], ['%d']);

        if (!$deleted) {
            return new \WP_Error('not_found', 'Contrat introuvable.', ['status' => 404]);
        }

        return ['success' => true];
    }

    // ── PDF Download ──────────────────────────────────────────────────────────

    public function download_pdf($request)
    {
        $id       = (int) $request->get_param('id');
        $contract = $this->fetch_contract($id);

        if (!$contract) {
            return new \WP_Error('not_found', 'Contrat introuvable.', ['status' => 404]);
        }

        global $wpdb;

        $title = $this->substitute_variables($contract['title'] ?? '', $contract);
        $body  = $this->substitute_variables($contract['body']  ?? '', $contract);

        // mPDF ignores <br> inside <p> — convert to paragraph breaks for reliable rendering
        $body = preg_replace('/<br\s*\/?>/i', '</p><p>', $body);

        // Fetch branding from settings
        $get_setting = fn (string $k) => (string) ($wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s", $k
        )) ?? '');

        $pdf_color    = sanitize_hex_color($get_setting('pdf_color')) ?: '#4f46e5';
        $company_name = $get_setting('company_name');

        // Resolve logo URL → absolute filesystem path (same logic as PDFGenerator)
        $logo_path = '';
        $logo_url  = $get_setting('logo_url');
        if ($logo_url) {
            $upload_dir = wp_upload_dir();
            if (strpos($logo_url, $upload_dir['baseurl']) === 0) {
                $logo_path = str_replace($upload_dir['baseurl'], $upload_dir['basedir'], $logo_url);
            } elseif (filter_var($logo_url, FILTER_VALIDATE_URL)) {
                $scheme = wp_parse_url($logo_url, PHP_URL_SCHEME);
                if (in_array(strtolower((string) $scheme), ['http', 'https'], true)) {
                    $logo_path = esc_url_raw($logo_url);
                }
            } else {
                $logo_path = $logo_url;
            }
        }

        $html = $this->render_pdf_html($title, $body, $pdf_color, $company_name, (int) $contract['id'], $logo_path);

        if (!class_exists('\Mpdf\Mpdf')) {
            // Fallback: return HTML as download
            $filename = sanitize_file_name($title) . '_' . $id . '.html';
            header('Content-Type: text/html; charset=UTF-8');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            echo $html; // phpcs:ignore
            exit;
        }

        try {
            $mpdf = new \Mpdf\Mpdf([
                'margin_top'    => 0,
                'margin_bottom' => 15,
                'margin_left'   => 0,
                'margin_right'  => 0,
                'margin_header' => 0,
                'margin_footer' => 0,
            ]);
            $mpdf->SetTitle($title);
            $mpdf->WriteHTML($html);

            $filename = sanitize_file_name($title ?: 'contrat') . '_' . $id . '.pdf';
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: no-cache, no-store, must-revalidate');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (\Exception $e) {
            return new \WP_Error('pdf_error', $e->getMessage(), ['status' => 500]);
        }
    }

    // ── Variables list ────────────────────────────────────────────────────────

    public function get_variables(): array
    {
        return [
            '{CLIENT_NAME}'       => 'Nom / raison sociale du client',
            '{CLIENT_EMAIL}'      => 'Email du client',
            '{CLIENT_ADDRESS}'    => 'Adresse du client',
            '{CLIENT_PHONE}'      => 'Téléphone du client',
            '{COMPANY_NAME}'      => 'Nom de votre entreprise',
            '{COMPANY_SIRET}'     => 'SIRET de votre entreprise',
            '{COMPANY_ADDRESS}'   => 'Adresse de votre entreprise',
            '{START_DATE}'        => 'Date de début (aujourd\'hui par défaut)',
            '{AMOUNT}'            => 'Montant du contrat',
            '{INVOICE_NUMBER}'    => 'Numéro de facture liée',
            '{QUOTE_NUMBER}'      => 'Numéro de devis lié',
            '{CONTRACT_ID}'       => 'Identifiant unique du contrat',
            '{TODAY}'             => 'Date du jour',
        ];
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function sanitize($request): array|\WP_Error
    {
        $title = sanitize_text_field($request->get_param('title') ?? '');
        if (!$title) {
            return new \WP_Error('missing_title', 'Le titre est requis.', ['status' => 400]);
        }

        $status = sanitize_text_field($request->get_param('status') ?? 'draft');
        if (!in_array($status, ['draft', 'sent', 'signed', 'archived'], true)) {
            $status = 'draft';
        }

        $variables = $request->get_param('variables');

        return [
            'title'      => $title,
            'body'       => wp_kses_post($request->get_param('body') ?? ''),
            'status'     => $status,
            'client_id'  => $request->get_param('client_id')  ? (int) $request->get_param('client_id')  : null,
            'invoice_id' => $request->get_param('invoice_id') ? (int) $request->get_param('invoice_id') : null,
            'quote_id'   => $request->get_param('quote_id')   ? (int) $request->get_param('quote_id')   : null,
            'variables'  => is_array($variables) ? wp_json_encode($variables) : null,
            'signed_at'  => $status === 'signed' ? current_time('mysql') : null,
            'sent_at'    => $status === 'sent'   ? current_time('mysql') : null,
        ];
    }

    private function formats(array $data): array
    {
        $map = [
            'client_id'  => '%d', 'invoice_id' => '%d', 'quote_id' => '%d',
            'title'      => '%s', 'body'        => '%s', 'status'   => '%s',
            'variables'  => '%s', 'signed_at'   => '%s', 'sent_at'  => '%s',
        ];
        // Formats must be in the same order as $data's keys (wpdb requirement).
        $formats = [];
        foreach ($data as $key => $_) {
            $formats[] = $map[$key] ?? '%s';
        }
        return $formats;
    }

    private function fetch_contract(int $id): ?array
    {
        global $wpdb;

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT c.*, cl.company_name AS client_name
             FROM " . ECWP_TABLE_CONTRACTS . " c
             LEFT JOIN " . ECWP_TABLE_CLIENTS . " cl ON cl.id = c.client_id
             WHERE c.id = %d",
            $id
        ), ARRAY_A);

        if (!$row) return null;
        $row['variables'] = $row['variables'] ? json_decode($row['variables'], true) : [];
        return $row;
    }

    private function substitute_variables(string $body, array $contract): string
    {
        global $wpdb;

        // Client data
        $client = [];
        if (!empty($contract['client_id'])) {
            $client = $wpdb->get_row($wpdb->prepare(
                "SELECT company_name, email, address, phone FROM " . ECWP_TABLE_CLIENTS . " WHERE id = %d",
                (int) $contract['client_id']
            ), ARRAY_A) ?: [];
        }

        // Company data from core Settings
        $get_setting = function (string $key) use ($wpdb): string {
            return (string) ($wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s", $key
            )) ?? '');
        };

        // Invoice / quote numbers
        $invoice_number = '';
        $quote_number   = '';
        if (!empty($contract['invoice_id']) && class_exists('\ECWP\Admin\Encrypt\ECWP_Encrypt')) {
            $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
            $row     = $wpdb->get_row($wpdb->prepare(
                "SELECT invoice_number FROM " . ECWP_TABLE_INVOICES . " WHERE id = %d",
                (int) $contract['invoice_id']
            ), ARRAY_A);
            $invoice_number = $row ? $encrypt->decrypt($row['invoice_number']) : '';
        }
        if (!empty($contract['quote_id'])) {
            $row          = $wpdb->get_row($wpdb->prepare(
                "SELECT quote_number FROM " . ECWP_TABLE_QUOTES . " WHERE id = %d",
                (int) $contract['quote_id']
            ), ARRAY_A);
            $quote_number = $row ? $row['quote_number'] : '';
        }

        $custom_vars = is_array($contract['variables']) ? $contract['variables'] : [];

        $replacements = [
            '{CLIENT_NAME}'     => $client['company_name'] ?? '',
            '{CLIENT_EMAIL}'    => $client['email']        ?? '',
            '{CLIENT_ADDRESS}'  => $client['address']      ?? '',
            '{CLIENT_PHONE}'    => $client['phone']        ?? '',
            '{COMPANY_NAME}'    => $get_setting('company_name'),
            '{COMPANY_SIRET}'   => $get_setting('company_siren'),
            '{COMPANY_ADDRESS}' => $get_setting('company_address'),
            '{START_DATE}'      => wp_date('d/m/Y'),
            '{AMOUNT}'          => $custom_vars['amount'] ?? '',
            '{INVOICE_NUMBER}'  => $invoice_number,
            '{QUOTE_NUMBER}'    => $quote_number,
            '{CONTRACT_ID}'     => (string) ($contract['id'] ?? ''),
            '{TODAY}'           => wp_date('d/m/Y'),
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $body);
    }

    private function render_pdf_html(string $title, string $body, string $pdf_color = '#4f46e5', string $company_name = '', int $contract_id = 0, string $logo_path = ''): string
    {
        $c    = esc_html($pdf_color);
        $date = wp_date('d/m/Y');
        $ref  = $contract_id ? 'Réf. #' . str_pad((string) $contract_id, 4, '0', STR_PAD_LEFT) : '';

        $rgb            = $this->hex_to_rgb($pdf_color);
        $color_light_bg = "rgba({$rgb},0.07)";
        $color_mid_bg   = "rgba({$rgb},0.18)";

        // Logo HTML (max-height 48px to keep header compact)
        $logo_html = '';
        if ($logo_path && (file_exists($logo_path) || filter_var($logo_path, FILTER_VALIDATE_URL))) {
            $logo_html = '<img src="' . esc_attr($logo_path) . '" style="max-height:52px;max-width:180px;" />';
        }

        // Header: logo left / company + meta right (table layout for mPDF)
        $header_inner = $logo_html
            ? '<table style="width:100%;border-collapse:collapse;margin-bottom:0;">
                 <tr>
                   <td style="width:auto;vertical-align:middle;padding-right:16px;">' . $logo_html . '</td>
                   <td style="vertical-align:middle;text-align:right;">
                     <div style="font-size:13px;font-weight:800;color:' . $c . ';">' . esc_html($company_name) . '</div>
                     <div style="font-size:9px;color:#94a3b8;margin-top:2px;">' . $date . ($ref ? ' &nbsp;·&nbsp; ' . $ref : '') . '</div>
                   </td>
                 </tr>
               </table>'
            : '<div style="font-size:13px;font-weight:800;color:' . $c . ';">' . esc_html($company_name) . '</div>
               <div style="font-size:9px;color:#94a3b8;margin-top:2px;">' . $date . ($ref ? ' &nbsp;·&nbsp; ' . $ref : '') . '</div>';

        return '<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<style>
  body {
    font-family: DejaVu Sans, Arial, sans-serif;
    font-size: 11px;
    color: #1e293b;
    line-height: 1.8;
    background: #fff;
    margin: 0;
    padding: 0;
  }

  .top-bar { background: ' . $c . '; height: 7px; width: 100%; }

  .page { padding: 24px 28px 0 28px; }

  .doc-header-wrap {
    padding-bottom: 14px;
    border-bottom: 2px solid ' . $c . ';
    margin-bottom: 20px;
  }

  .doc-title {
    font-size: 18px;
    font-weight: 800;
    color: ' . $c . ';
    line-height: 1.3;
    margin-top: 16px;
    margin-bottom: 3px;
  }

  .doc-meta { font-size: 9px; color: #94a3b8; }

  p { margin-top: 0; margin-bottom: 8px; }

  h1, h2 {
    font-size: 12px;
    font-weight: 800;
    color: #0f172a;
    background-color: ' . $color_light_bg . ';
    border-left: 4px solid ' . $c . ';
    padding: 6px 10px;
    margin-top: 20px;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
  }

  h3 {
    font-size: 11.5px;
    font-weight: 800;
    color: ' . $c . ';
    margin-top: 16px;
    margin-bottom: 5px;
    border-bottom: 1px solid ' . $color_mid_bg . ';
    padding-bottom: 3px;
  }

  strong, b { font-weight: 700; }
  em, i     { font-style: italic; }
  ul, ol    { margin-left: 16px; margin-bottom: 8px; }
  li        { margin-bottom: 2px; }

  table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
  td, th { padding: 6px 10px; vertical-align: top; }

  .doc-footer {
    background-color: ' . $color_light_bg . ';
    border-top: 1px solid ' . $color_mid_bg . ';
    padding: 9px 28px;
    margin-top: 32px;
    font-size: 8px;
    color: #64748b;
    text-align: center;
  }
</style>
</head>
<body>

<div class="top-bar"></div>

<div class="page">

  <div class="doc-header-wrap">
    ' . $header_inner . '
    <div class="doc-title">' . esc_html($title) . '</div>
    <div class="doc-meta">Contrat généré le ' . $date . ($ref ? ' &nbsp;·&nbsp; ' . $ref : '') . '</div>
  </div>

  <div class="doc-body">' . $body . '</div>

</div>

<div class="doc-footer">
  Document généré par myEasyCompta' . ($company_name ? ' &nbsp;·&nbsp; ' . esc_html($company_name) : '') . ' &nbsp;·&nbsp; ' . $date . '
</div>

</body>
</html>';
    }

    private function hex_to_rgb(string $hex): string
    {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        return "$r,$g,$b";
    }
}
