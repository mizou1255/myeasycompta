<?php
/**
 * Plugin Name: myEasyCompta - Devis interactif en ligne
 * Description: Partagez vos devis via un lien public sécurisé. Le client peut consulter, accepter ou refuser le devis directement en ligne, sans créer de compte.
 * Version: 1.0.0
 * Author: MELIOZ.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-online-quote
 * Domain Path: /languages/
 * Requires at least: 6.2
 * Tested up to: 6.9
 * Requires PHP: 8.0
 * Requires Plugins: my-easy-compta
 * Tags: devis, online quote, partage, lien public, acceptation
 */

if (!defined('ABSPATH')) exit;

define('ECWP_ONLINE_QUOTE_VERSION',  '1.0.0');
define('ECWP_ONLINE_QUOTE_PATH',     plugin_dir_path(__FILE__));
define('ECWP_ONLINE_QUOTE_URL',      plugins_url('', __FILE__));
define('ECWP_ONLINE_QUOTE_INCLUDES', ECWP_ONLINE_QUOTE_PATH . 'includes');

add_action('plugins_loaded', function () {
    if (!defined('ECWP_PREFIX')) return;
    if (!defined('ECWP_TABLE_QUOTE_TOKENS')) {
        define('ECWP_TABLE_QUOTE_TOKENS', ECWP_PREFIX . 'ecwp_quote_tokens');
    }
}, 5);

/**
 * Returns true if the active license covers the online-quote addon.
 */
function ecwp_online_quote_has_license(): bool
{
    $data = get_option('ecwp_client_license_data', []);
    if (empty($data) || !is_array($data)) return false;

    // Check expiry
    if (!empty($data['expires_at']) && strtotime($data['expires_at']) < time()) return false;

    $addons = $data['addons'] ?? [];
    if (in_array('_bundle', $addons, true)) return true;

    return in_array('online-quote', $addons, true) || in_array('online_quote', $addons, true);
}

add_action('plugins_loaded', function () {
    if (!class_exists('ECWP_Easy_Compta')) return;

    require_once ECWP_ONLINE_QUOTE_INCLUDES . '/Migration.php';
    require_once ECWP_ONLINE_QUOTE_INCLUDES . '/OnlineQuote.php';
    require_once ECWP_ONLINE_QUOTE_INCLUDES . '/PublicPage.php';
    require_once ECWP_ONLINE_QUOTE_INCLUDES . '/AdminUI.php';

    add_action('admin_init', 'ecwp_online_quote_maybe_migrate');

    // Public page always available (honours already-generated links)
    new ECWP\Addon\OnlineQuote\ECWP_OnlineQuote_PublicPage();

    // REST routes: public ones always available, admin ones gated at REST level
    new ECWP\Addon\OnlineQuote\ECWP_OnlineQuote();

    // Admin UI only if core admin is loaded
    new ECWP\Addon\OnlineQuote\ECWP_OnlineQuote_AdminUI();

    // onlineQuoteAddonActive est déjà géré par le core plugin via is_addon_active_by_prefix()
    // Inutile de surcharger ici — le plugin actif = licence valide (le téléchargement l'exige)
}, 20);

function ecwp_online_quote_maybe_migrate()
{
    if (get_option('ecwp_online_quote_db_version') !== '1.2.0') {
        require_once ECWP_ONLINE_QUOTE_INCLUDES . '/Migration.php';
        ecwp_online_quote_run_migration();
    }
}

register_activation_hook(__FILE__, function () {
    if (!defined('ECWP_PREFIX')) { global $wpdb; define('ECWP_PREFIX', $wpdb->prefix); }
    if (!defined('ECWP_TABLE_QUOTE_TOKENS')) define('ECWP_TABLE_QUOTE_TOKENS', ECWP_PREFIX . 'ecwp_quote_tokens');
    require_once ECWP_ONLINE_QUOTE_INCLUDES . '/Migration.php';
    ecwp_online_quote_run_migration();
});
