<?php

namespace ECWP\Addon\OnlineQuote;

if (!defined('ABSPATH')) exit;

/**
 * Intercepts /?ecwp_online_quote={token} and renders the public quote page.
 */
class ECWP_OnlineQuote_PublicPage
{
    public function __construct()
    {
        add_action('template_redirect', [$this, 'maybe_render']);
    }

    public function maybe_render()
    {
        $token = isset($_GET['ecwp_online_quote']) ? sanitize_text_field(wp_unslash($_GET['ecwp_online_quote'])) : '';
        if (!$token) return;

        // Serve our standalone HTML page – no WordPress theme
        $this->render_page($token);
        exit;
    }

    private function render_page(string $token)
    {
        global $wpdb;
        $table = ECWP_TABLE_QUOTE_TOKENS;

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE token = %s", $token));

        $site_name = get_bloginfo('name');
        $expired   = false;
        $error     = '';

        if (!$row) {
            $error = 'Ce lien est invalide ou a été révoqué.';
        } elseif ($row->expires_at && strtotime($row->expires_at) < current_time('timestamp')) {
            $expired = true;
            $error   = 'Ce lien a expiré.';
        }

        $api_base = rest_url('my-easy-compta/v1/online-quote/' . esc_attr($token));
        $nonce    = wp_create_nonce('wp_rest');
        ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Devis en ligne — <?php echo esc_html($site_name); ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    * { font-family: 'Inter', sans-serif; }
    .loader { border: 3px solid #e2e8f0; border-top-color: #7c3aed; border-radius: 50%; width: 40px; height: 40px; animation: spin .8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    @media print { .no-print { display: none !important; } }
  </style>
</head>
<body class="bg-slate-50 min-h-screen">

<?php if ($error): ?>
  <div class="flex items-center justify-center min-h-screen">
    <div class="bg-white rounded-3xl shadow-xl p-10 text-center max-w-md">
      <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </div>
      <h1 class="text-xl font-black text-slate-800 mb-2">Lien invalide</h1>
      <p class="text-slate-500"><?php echo esc_html($error); ?></p>
    </div>
  </div>
<?php else: ?>

  <div id="app" class="max-w-4xl mx-auto py-10 px-4">
    <!-- Loading -->
    <div id="loading" class="flex items-center justify-center py-24">
      <div class="loader"></div>
    </div>

    <!-- Content (hidden until loaded) -->
    <div id="content" class="hidden space-y-6">

      <!-- Status banner (shown if already actioned) -->
      <div id="status-banner" class="hidden rounded-2xl p-4 text-sm font-bold text-center"></div>

      <!-- Quote card -->
      <div class="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">

        <!-- Header -->
        <div class="bg-gradient-to-r from-purple-600 to-indigo-600 p-8 text-white">
          <div class="flex items-start justify-between">
            <div>
              <p class="text-purple-200 text-xs uppercase tracking-widest font-bold mb-1">Devis</p>
              <h1 id="quote-number" class="text-3xl font-black"></h1>
              <p id="quote-date" class="text-purple-200 mt-1 text-sm"></p>
            </div>
            <div id="company-logo-wrap" class="hidden">
              <img id="company-logo" src="" alt="Logo" class="h-16 object-contain bg-white/10 rounded-xl p-2" />
            </div>
          </div>
        </div>

        <div class="p-8 space-y-8">

          <!-- Parties -->
          <div class="grid grid-cols-2 gap-8">
            <div>
              <p class="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">De</p>
              <p id="company-name" class="font-black text-slate-900 text-lg"></p>
              <p id="company-address" class="text-sm text-slate-500 mt-1 whitespace-pre-line"></p>
              <p id="company-email" class="text-sm text-slate-500"></p>
            </div>
            <div>
              <p class="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">À</p>
              <p id="client-name" class="font-black text-slate-900 text-lg"></p>
              <p id="client-address" class="text-sm text-slate-500 mt-1 whitespace-pre-line"></p>
              <p id="client-email" class="text-sm text-slate-500"></p>
            </div>
          </div>

          <!-- Optional items notice -->
          <div id="optional-notice" class="hidden bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3 text-sm text-amber-700 flex items-start gap-3">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M12 2a10 10 0 100 20A10 10 0 0012 2z"/></svg>
            <span>Ce devis contient des éléments <strong>optionnels</strong>. Cochez ceux que vous souhaitez inclure — le total se met à jour automatiquement.</span>
          </div>

          <!-- Items table -->
          <div class="overflow-hidden rounded-2xl border border-slate-100">
            <table class="w-full text-sm">
              <thead>
                <tr class="bg-slate-50 border-b border-slate-100">
                  <th class="p-3 text-center text-xs font-black text-slate-400 uppercase tracking-wider w-12" id="th-select"></th>
                  <th class="p-3 text-left text-xs font-black text-slate-400 uppercase tracking-wider">Désignation</th>
                  <th class="p-3 text-right text-xs font-black text-slate-400 uppercase tracking-wider">Qté</th>
                  <th class="p-3 text-right text-xs font-black text-slate-400 uppercase tracking-wider">P.U. HT</th>
                  <th class="p-3 text-right text-xs font-black text-slate-400 uppercase tracking-wider">TVA</th>
                  <th class="p-3 text-right text-xs font-black text-slate-400 uppercase tracking-wider">Total HT</th>
                </tr>
              </thead>
              <tbody id="items-body"></tbody>
            </table>
          </div>

          <!-- Totals -->
          <div class="flex justify-end">
            <div class="w-64 space-y-2 text-sm">
              <div class="flex justify-between text-slate-500">
                <span>Total HT</span><span id="total-ht" class="font-bold text-slate-900"></span>
              </div>
              <div class="flex justify-between text-slate-500">
                <span>TVA</span><span id="total-tva" class="font-bold text-slate-900"></span>
              </div>
              <div class="flex justify-between border-t border-slate-200 pt-2 font-black text-slate-900 text-base">
                <span>Total TTC</span><span id="total-ttc"></span>
              </div>
            </div>
          </div>

          <!-- Due date -->
          <p id="due-date-line" class="text-xs text-slate-400 hidden">
            Ce devis est valable jusqu'au <span id="due-date" class="font-bold text-slate-600"></span>
          </p>
        </div>
      </div>

      <!-- Action buttons (shown only if not yet actioned & not expired) -->
      <div id="action-panel" class="hidden no-print">
        <div class="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-5">
          <h2 class="text-lg font-black text-slate-900 mb-1">Votre réponse</h2>
          <p class="text-sm text-slate-500">Vous pouvez accepter ou refuser ce devis directement en ligne.</p>

          <!-- Commentaire -->
          <textarea id="comment-input" rows="2" placeholder="Commentaire optionnel..." class="w-full px-4 py-3 rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"></textarea>

          <!-- Signature électronique -->
          <div>
            <div class="flex items-center justify-between mb-2">
              <label class="text-xs font-black text-slate-500 uppercase tracking-wider">Signature électronique <span class="text-red-400">*</span></label>
              <button type="button" onclick="clearSignature()" class="text-xs text-slate-400 hover:text-red-500 transition-colors">Effacer</button>
            </div>
            <canvas id="sig-canvas" width="600" height="160"
              class="w-full rounded-2xl border-2 border-slate-200 touch-none cursor-crosshair bg-slate-50"
              style="touch-action:none"></canvas>
            <p id="sig-hint" class="text-xs text-slate-400 mt-1">Signez dans le cadre ci-dessus pour valider votre réponse.</p>
            <p id="sig-error" class="text-xs text-red-500 mt-1 hidden">La signature est obligatoire pour accepter le devis.</p>
          </div>

          <!-- Boutons -->
          <div class="flex gap-3">
            <button onclick="submitAction('rejected')" class="flex-1 px-4 py-3 rounded-2xl border-2 border-red-200 text-red-600 text-sm font-black hover:bg-red-50 transition-all">
              ✕ Refuser
            </button>
            <button onclick="submitAction('accepted')" class="flex-1 px-4 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-sm font-black shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50 transition-all">
              ✓ Accepter &amp; Signer
            </button>
          </div>
        </div>
      </div>

      <!-- Footer -->
      <p class="text-center text-xs text-slate-400 no-print">Propulsé par <strong>myEasyCompta</strong></p>

    </div><!-- #content -->
  </div><!-- #app -->

  <script>
    const API_BASE  = <?php echo wp_json_encode($api_base); ?>;
    const REST_NONCE = <?php echo wp_json_encode($nonce); ?>;
    let currency = '€';

    function fmt(n) {
      const v = parseFloat(n) || 0;
      return v.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + currency;
    }

    function fmtDate(d) {
      if (!d) return '';
      return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
    }

    function setText(id, val) {
      const el = document.getElementById(id);
      if (el) el.textContent = val || '';
    }

    async function load() {
      try {
        const res  = await fetch(API_BASE, { headers: { 'X-WP-Nonce': REST_NONCE } });
        const data = await res.json();

        if (!res.ok) { showError(data.message || 'Erreur inconnue.'); return; }

        const { quote, company, token } = data;
        currency = quote.currency_symbol || '€';

        // Header
        setText('quote-number', quote.quote_number || '');
        setText('quote-date',   'Créé le ' + fmtDate(quote.created_at));

        // Company
        if (company.logo) {
          document.getElementById('company-logo-wrap').classList.remove('hidden');
          document.getElementById('company-logo').src = company.logo;
        }
        setText('company-name',    company.name);
        setText('company-address', [company.address, company.zip + ' ' + company.city, company.country].filter(Boolean).join('\n'));
        setText('company-email',   company.email);

        // Client
        setText('client-name',    quote.company_name || '');
        setText('client-address', [quote.address, (quote.zip_code || '') + ' ' + (quote.city || ''), quote.country].filter(Boolean).join('\n').trim());
        setText('client-email',   quote.email || '');

        // Items
        const tbody  = document.getElementById('items-body');
        let hasOptional = false;
        (quote.items || []).forEach(item => {
          const isOptional = String(item.is_optional) === '1';
          if (isOptional) hasOptional = true;

          const qty  = parseFloat(item.quantity)   || 0;
          const pu   = parseFloat(item.unit_price)  || 0;
          const disc = parseFloat(item.discount)    || 0;
          const tva  = parseFloat(item.vat_rate)    || 0;
          const ht   = qty * pu * (1 - disc / 100);

          const name = escHtml(item.item_name || '');
          // Description is WYSIWYG HTML — render directly (sanitized server-side)
          const desc = item.item_description
            ? `<div class="text-xs text-slate-400 mt-1 leading-relaxed prose prose-sm max-w-none">${item.item_description}</div>`
            : '';
          const badge = isOptional
            ? `<span class="inline-block ml-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-600 align-middle">Optionnel</span>`
            : '';

          const selCell = isOptional
            ? `<td class="p-3 text-center"><input type="checkbox" checked data-item-id="${escHtml(String(item.id))}" data-qty="${qty}" data-pu="${pu}" data-disc="${disc}" data-tva="${tva}" class="item-checkbox w-4 h-4 rounded accent-purple-600 cursor-pointer" onchange="recalcTotals()" /></td>`
            : `<td class="p-3 text-center"><svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-slate-200 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg></td>`;

          const tr = document.createElement('tr');
          tr.className = 'border-b border-slate-50 last:border-0' + (isOptional ? ' optional-row' : '');
          tr.dataset.optional = isOptional ? '1' : '0';
          tr.dataset.qty  = qty;
          tr.dataset.pu   = pu;
          tr.dataset.disc = disc;
          tr.dataset.tva  = tva;
          tr.innerHTML = `
            ${selCell}
            <td class="p-3 text-slate-700">${name}${badge}${desc}</td>
            <td class="p-3 text-right text-slate-600">${qty}</td>
            <td class="p-3 text-right text-slate-600">${fmt(pu)}</td>
            <td class="p-3 text-right text-slate-500">${tva}%</td>
            <td class="p-3 text-right font-bold text-slate-900" data-total-cell>${fmt(ht)}</td>
          `;
          tbody.appendChild(tr);
        });

        if (hasOptional) {
          document.getElementById('optional-notice').classList.remove('hidden');
        }

        recalcTotals();

        // Due date
        if (quote.due_date) {
          document.getElementById('due-date-line').classList.remove('hidden');
          setText('due-date', fmtDate(quote.due_date));
        }

        // Token status
        const { action, action_at, client_comment } = token;
        if (action) {
          const banner = document.getElementById('status-banner');
          banner.classList.remove('hidden');
          if (action === 'accepted') {
            banner.className = 'rounded-2xl p-4 text-sm font-bold text-center bg-emerald-50 text-emerald-700 border border-emerald-200';
            banner.textContent = '✓ Devis accepté le ' + fmtDate(action_at) + (client_comment ? ' — ' + client_comment : '');
          } else {
            banner.className = 'rounded-2xl p-4 text-sm font-bold text-center bg-red-50 text-red-600 border border-red-200';
            banner.textContent = '✕ Devis refusé le ' + fmtDate(action_at) + (client_comment ? ' — ' + client_comment : '');
          }
        } else {
          document.getElementById('action-panel').classList.remove('hidden');
        }

        document.getElementById('loading').classList.add('hidden');
        document.getElementById('content').classList.remove('hidden');

      } catch (e) {
        showError('Impossible de charger le devis.');
      }
    }

    function escHtml(str) {
      return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    function recalcTotals() {
      let totalHT = 0, totalTVA = 0;
      document.querySelectorAll('#items-body tr').forEach(tr => {
        const isOptional = tr.dataset.optional === '1';
        const cb   = tr.querySelector('.item-checkbox');
        const cell = tr.querySelector('[data-total-cell]');

        if (isOptional && cb && !cb.checked) {
          if (cell) cell.textContent = '—';
          return;
        }

        const q = parseFloat(tr.dataset.qty)  || 0;
        const p = parseFloat(tr.dataset.pu)   || 0;
        const d = parseFloat(tr.dataset.disc) || 0;
        const t = parseFloat(tr.dataset.tva)  || 0;
        const ht   = q * p * (1 - d / 100);
        const tvaA = ht * t / 100;
        totalHT  += ht;
        totalTVA += tvaA;
        if (cell) cell.textContent = fmt(ht);
      });
      setText('total-ht',  fmt(totalHT));
      setText('total-tva', fmt(totalTVA));
      setText('total-ttc', fmt(totalHT + totalTVA));
    }

    function getSelectedItems() {
      const ids = [];
      document.querySelectorAll('#items-body .item-checkbox:checked').forEach(cb => {
        ids.push(parseInt(cb.dataset.itemId, 10));
      });
      return ids;
    }

    // ── Signature pad ────────────────────────────────────────────────────────
    let sigCanvas, sigCtx, sigDrawing = false, sigEmpty = true;

    function initSignaturePad() {
      sigCanvas = document.getElementById('sig-canvas');
      if (!sigCanvas) return;
      sigCtx = sigCanvas.getContext('2d');
      sigCtx.lineWidth   = 2;
      sigCtx.lineCap     = 'round';
      sigCtx.lineJoin    = 'round';
      sigCtx.strokeStyle = '#1e293b';

      const getPos = (e) => {
        const rect = sigCanvas.getBoundingClientRect();
        const scaleX = sigCanvas.width  / rect.width;
        const scaleY = sigCanvas.height / rect.height;
        const src = e.touches ? e.touches[0] : e;
        return { x: (src.clientX - rect.left) * scaleX, y: (src.clientY - rect.top) * scaleY };
      };

      const start = (e) => { e.preventDefault(); sigDrawing = true; sigEmpty = false; const p = getPos(e); sigCtx.beginPath(); sigCtx.moveTo(p.x, p.y); };
      const move  = (e) => { e.preventDefault(); if (!sigDrawing) return; const p = getPos(e); sigCtx.lineTo(p.x, p.y); sigCtx.stroke(); };
      const end   = ()  => { sigDrawing = false; };

      sigCanvas.addEventListener('mousedown',  start);
      sigCanvas.addEventListener('mousemove',  move);
      sigCanvas.addEventListener('mouseup',    end);
      sigCanvas.addEventListener('mouseleave', end);
      sigCanvas.addEventListener('touchstart', start, { passive: false });
      sigCanvas.addEventListener('touchmove',  move,  { passive: false });
      sigCanvas.addEventListener('touchend',   end);
    }

    function clearSignature() {
      if (!sigCtx) return;
      sigCtx.clearRect(0, 0, sigCanvas.width, sigCanvas.height);
      sigEmpty = true;
    }

    function getSignatureDataURL() {
      if (!sigCanvas || sigEmpty) return null;
      return sigCanvas.toDataURL('image/png');
    }

    async function submitAction(action) {
      // Signature required only for acceptance
      if (action === 'accepted') {
        if (sigEmpty) {
          document.getElementById('sig-error').classList.remove('hidden');
          return;
        }
        document.getElementById('sig-error').classList.add('hidden');
      }

      const comment        = document.getElementById('comment-input').value;
      const signature      = action === 'accepted' ? getSignatureDataURL() : null;
      const selected_items = getSelectedItems();
      const buttons        = document.querySelectorAll('#action-panel button');
      buttons.forEach(b => { b.disabled = true; b.style.opacity = '.5'; });

      try {
        const res  = await fetch(API_BASE + '/action', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': REST_NONCE },
          body:    JSON.stringify({ action, comment, signature_data: signature, selected_items }),
        });
        const data = await res.json();

        if (!res.ok) { alert(data.message || 'Erreur.'); buttons.forEach(b => { b.disabled = false; b.style.opacity = '1'; }); return; }

        document.getElementById('action-panel').classList.add('hidden');

        const banner = document.getElementById('status-banner');
        banner.classList.remove('hidden');
        if (action === 'accepted') {
          banner.className = 'rounded-2xl p-4 text-sm font-bold text-center bg-emerald-50 text-emerald-700 border border-emerald-200';
          banner.textContent = '✓ Merci ! Votre acceptation et signature ont bien été enregistrées.';
        } else {
          banner.className = 'rounded-2xl p-4 text-sm font-bold text-center bg-red-50 text-red-600 border border-red-200';
          banner.textContent = '✕ Votre refus a bien été enregistré.';
        }
      } catch(e) {
        alert('Une erreur est survenue. Veuillez réessayer.');
        buttons.forEach(b => { b.disabled = false; b.style.opacity = '1'; });
      }
    }

    function showError(msg) {
      document.getElementById('loading').innerHTML = `<div class="text-center"><p class="text-red-500 font-bold">${escHtml(msg)}</p></div>`;
    }

    load();
    initSignaturePad();
  </script>

<?php endif; ?>
</body>
</html>
        <?php
    }
}
