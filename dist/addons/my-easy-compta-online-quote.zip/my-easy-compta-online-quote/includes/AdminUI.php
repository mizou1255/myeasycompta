<?php

namespace ECWP\Addon\OnlineQuote;

if (!defined('ABSPATH')) exit;

/**
 * Injects the "Devis interactif" panel into the Quote detail page (admin SPA).
 *
 * The Vue SPA uses hash routing (#/quotes/{id}). We detect this via JS and
 * mount our Vue panel on a dedicated div we append to the page.
 */
class ECWP_OnlineQuote_AdminUI
{
    public function __construct()
    {
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('admin_footer',          [$this, 'inject_panel_container']);
    }

    public function enqueue_scripts($hook)
    {
        // Only load on the myEasyCompta admin page
        if (!str_contains($hook, 'my-easy-compta')) return;

        $dist = ECWP_ONLINE_QUOTE_URL . '/assets/dist/';

        wp_enqueue_script(
            'ecwp-online-quote-panel',
            $dist . 'online-quote.min.js',
            [],
            ECWP_ONLINE_QUOTE_VERSION,
            true
        );
    }

    public function inject_panel_container()
    {
        $screen = get_current_screen();
        if (!$screen || !str_contains($screen->id, 'my-easy-compta')) return;
        ?>
        <!-- ecwp-online-quote: dynamic mount via JS hash detection -->
        <div id="ecwp-online-quote-panel" style="display:none;"></div>
        <script>
        (function() {
            var QUOTE_DETAIL_RE = /^#\/quotes\/(\d+)(?:\/|$)/;
            var _currentQid = null;

            function getQuoteIdFromHash() {
                var m = window.location.hash.match(QUOTE_DETAIL_RE);
                return m ? m[1] : null;
            }

            function mountPanel(quoteId) {
                var el = document.getElementById('ecwp-online-quote-panel');
                if (!el) return;

                el.style.display = 'block';

                var tryInsert = function() {
                    // Try to find the quote detail container
                    var container = document.querySelector('.space-y-8');
                    if (container && !container.contains(el)) {
                        container.appendChild(el);
                    }
                    if (typeof window.ecwpMountOnlineQuotePanel === 'function') {
                        window.ecwpMountOnlineQuotePanel(quoteId);
                    }
                };

                // Wait for Vue SPA to render the quote detail view
                setTimeout(tryInsert, 600);
            }

            function unmountPanel() {
                var el = document.getElementById('ecwp-online-quote-panel');
                if (el) el.style.display = 'none';
                if (typeof window.ecwpUnmountOnlineQuotePanel === 'function') {
                    window.ecwpUnmountOnlineQuotePanel();
                }
                _currentQid = null;
            }

            function checkRoute() {
                var qid = getQuoteIdFromHash();
                if (qid) {
                    if (qid !== _currentQid) {
                        _currentQid = qid;
                        mountPanel(qid);
                    }
                } else {
                    if (_currentQid) unmountPanel();
                }
            }

            window.addEventListener('hashchange', checkRoute);
            // Also check after initial load in case page opens directly on a quote
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', checkRoute);
            } else {
                checkRoute();
            }
        })();
        </script>
        <?php
    }
}
