<?php

namespace ECWP\Addon\OnlineQuote;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

if (!defined('ABSPATH')) exit;

class ECWP_OnlineQuote
{
    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes()
    {
        $ns = 'my-easy-compta/v1';

        // Admin: generate share link for a quote (requires license)
        register_rest_route($ns, '/quotes/(?P<id>\d+)/generate-link', [
            'methods'             => 'POST',
            'callback'            => [$this, 'generate_link'],
            'permission_callback' => function () {
                return current_user_can('manage_options') && ecwp_online_quote_has_license();
            },
        ]);

        // Admin: get token info for a quote
        register_rest_route($ns, '/quotes/(?P<id>\d+)/share-status', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_share_status'],
            'permission_callback' => function () { return current_user_can('manage_options'); },
        ]);

        // Admin: revoke token
        register_rest_route($ns, '/quotes/(?P<id>\d+)/revoke-link', [
            'methods'             => 'DELETE',
            'callback'            => [$this, 'revoke_link'],
            'permission_callback' => function () { return current_user_can('manage_options'); },
        ]);

        // Admin: reset client action so the client can re-sign
        register_rest_route($ns, '/quotes/(?P<id>\d+)/reset-token', [
            'methods'             => 'POST',
            'callback'            => [$this, 'reset_token'],
            'permission_callback' => function () { return current_user_can('manage_options'); },
        ]);

        // Public: view quote by token (NO auth)
        register_rest_route($ns, '/online-quote/(?P<token>[a-zA-Z0-9_-]+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'public_get_quote'],
            'permission_callback' => '__return_true',
        ]);

        // Public: accept or reject quote (NO auth)
        register_rest_route($ns, '/online-quote/(?P<token>[a-zA-Z0-9_-]+)/action', [
            'methods'             => 'POST',
            'callback'            => [$this, 'public_action'],
            'permission_callback' => '__return_true',
        ]);
    }

    // -------------------------------------------------------------------------
    // Admin endpoints
    // -------------------------------------------------------------------------

    public function generate_link(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $quote_id = absint($request->get_param('id'));

        if (!$quote_id) {
            return new WP_Error('invalid_id', 'Invalid quote ID.', ['status' => 400]);
        }

        // Verify quote exists
        $quote = $wpdb->get_row($wpdb->prepare(
            'SELECT id FROM ' . ECWP_TABLE_QUOTES . ' WHERE id = %d',
            $quote_id
        ));
        if (!$quote) {
            return new WP_Error('not_found', 'Quote not found.', ['status' => 404]);
        }

        $table = ECWP_TABLE_QUOTE_TOKENS;

        // Revoke existing token for this quote
        $wpdb->delete($table, ['quote_id' => $quote_id], ['%d']);

        // Generate secure random token
        $token     = bin2hex(random_bytes(32)); // 64 hex chars
        $body      = $request->get_json_params();
        $days      = isset($body['expires_days']) ? absint($body['expires_days']) : 30;
        $expires_at = $days > 0
            ? wp_date('Y-m-d H:i:s', current_time('timestamp') + $days * DAY_IN_SECONDS)
            : null;

        $wpdb->insert($table, [
            'quote_id'   => $quote_id,
            'token'      => $token,
            'expires_at' => $expires_at,
            'created_at' => current_time('mysql'),
        ], ['%d', '%s', '%s', '%s']);

        $public_url = $this->build_public_url($token);

        return rest_ensure_response([
            'token'      => $token,
            'public_url' => $public_url,
            'expires_at' => $expires_at,
        ]);
    }

    public function get_share_status(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $quote_id = absint($request->get_param('id'));
        $table    = ECWP_TABLE_QUOTE_TOKENS;

        $token = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE quote_id = %d ORDER BY id DESC LIMIT 1",
            $quote_id
        ));

        if (!$token) {
            return rest_ensure_response(['has_link' => false]);
        }

        // Build optional items summary (which were selected / declined)
        $optional_summary = [];
        if ($token->action && defined('ECWP_TABLE_QUOTE_ELEMENTS')) {
            $qe      = ECWP_TABLE_QUOTE_ELEMENTS;
            $qe_cols = $wpdb->get_col("DESCRIBE {$qe}");

            if (in_array('is_optional', $qe_cols, true)) {
                $selected = [];
                if (!empty($token->selected_items)) {
                    $decoded  = json_decode($token->selected_items, true);
                    $selected = is_array($decoded) ? array_map('intval', $decoded) : [];
                }
                $optionals = $wpdb->get_results($wpdb->prepare(
                    "SELECT id, item_name FROM {$qe} WHERE quote_id = %d AND is_optional = 1 ORDER BY item_order ASC",
                    $token->quote_id
                ), ARRAY_A);
                foreach (($optionals ?: []) as $opt) {
                    $optional_summary[] = [
                        'id'       => (int) $opt['id'],
                        'name'     => $opt['item_name'],
                        'selected' => in_array((int) $opt['id'], $selected, true),
                    ];
                }
            }
        }

        return rest_ensure_response([
            'has_link'         => true,
            'token'            => $token->token,
            'public_url'       => $this->build_public_url($token->token),
            'expires_at'       => $token->expires_at,
            'viewed_at'        => $token->viewed_at,
            'action'           => $token->action,
            'action_at'        => $token->action_at,
            'client_comment'   => $token->client_comment,
            'has_signature'    => !empty($token->signature_data),
            'signature_data'   => $token->signature_data ?: null,
            'optional_summary' => $optional_summary,
            'is_expired'       => $token->expires_at && strtotime($token->expires_at) < current_time('timestamp'),
        ]);
    }

    public function revoke_link(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $quote_id = absint($request->get_param('id'));
        $wpdb->delete(ECWP_TABLE_QUOTE_TOKENS, ['quote_id' => $quote_id], ['%d']);
        return rest_ensure_response(['success' => true]);
    }

    public function reset_token(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $quote_id = absint($request->get_param('id'));

        // Clear the action columns on the token
        $update_data    = [
            'action'         => null,
            'action_at'      => null,
            'client_comment' => null,
            'signature_data' => null,
        ];
        $update_formats = ['%s', '%s', '%s', '%s'];

        // Also clear selected_items if the column exists
        $token_columns = $wpdb->get_col('DESCRIBE ' . ECWP_TABLE_QUOTE_TOKENS);
        if (in_array('selected_items', $token_columns, true)) {
            $update_data['selected_items'] = null;
            $update_formats[]              = '%s';
        }

        $wpdb->update(ECWP_TABLE_QUOTE_TOKENS, $update_data, ['quote_id' => $quote_id], $update_formats, ['%d']);

        // Reset quote status back to pending
        $wpdb->update(ECWP_TABLE_QUOTES, ['status' => 'pending'], ['id' => $quote_id], ['%s'], ['%d']);

        return rest_ensure_response(['success' => true]);
    }

    // -------------------------------------------------------------------------
    // Public endpoints (no authentication)
    // -------------------------------------------------------------------------

    public function public_get_quote(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $token = sanitize_text_field($request->get_param('token'));
        $row   = $this->get_valid_token($token);

        if (is_wp_error($row)) return $row;

        // Mark as viewed (once)
        if (!$row->viewed_at) {
            $wpdb->update(
                ECWP_TABLE_QUOTE_TOKENS,
                ['viewed_at' => current_time('mysql')],
                ['token' => $token],
                ['%s'],
                ['%s']
            );
        }

        $quote   = $this->get_quote_data($row->quote_id);
        $company = $this->get_company_data();

        return rest_ensure_response([
            'quote'   => $quote,
            'company' => $company,
            'token'   => [
                'action'         => $row->action,
                'action_at'      => $row->action_at,
                'client_comment' => $row->client_comment,
                'expires_at'     => $row->expires_at,
            ],
        ]);
    }

    public function public_action(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        global $wpdb;
        $log   = WP_CONTENT_DIR . '/ecwp_quote_mail.log';
        $ts    = date('[Y-m-d H:i:s]');
        $token = sanitize_text_field($request->get_param('token'));
        file_put_contents($log, "$ts public_action called token=" . substr($token, 0, 8) . "...\n", FILE_APPEND | LOCK_EX);

        $row = $this->get_valid_token($token);

        if (is_wp_error($row)) {
            file_put_contents($log, "$ts get_valid_token error: " . $row->get_error_message() . "\n", FILE_APPEND | LOCK_EX);
            return $row;
        }

        // Block if already actioned
        if ($row->action) {
            file_put_contents($log, "$ts BLOCKED already_actioned={$row->action}\n", FILE_APPEND | LOCK_EX);
            return new WP_Error('already_actioned', 'This quote has already been actioned.', ['status' => 409]);
        }

        $body           = $request->get_json_params();
        $action         = in_array($body['action'] ?? '', ['accepted', 'rejected'], true) ? $body['action'] : null;
        $comment        = isset($body['comment']) ? sanitize_textarea_field($body['comment']) : '';
        $signature_data = isset($body['signature_data']) ? $body['signature_data'] : null;
        $selected_items = isset($body['selected_items']) && is_array($body['selected_items'])
            ? wp_json_encode(array_map('absint', $body['selected_items']))
            : null;

        // Validate signature_data is an image data URL (for accepted only)
        if ($action === 'accepted' && $signature_data) {
            $signature_data = trim($signature_data);
            if (strpos($signature_data, 'data:image/') !== 0 || strpos($signature_data, ';base64,') === false) {
                $signature_data = null;
            }
        } else {
            $signature_data = null; // No signature for rejection
        }

        if (!$action) {
            return new WP_Error('invalid_action', 'Action must be accepted or rejected.', ['status' => 400]);
        }

        $now = current_time('mysql');

        // Build update data — start with always-present columns
        $update_data    = [
            'action'         => $action,
            'action_at'      => $now,
            'client_comment' => $comment,
            'signature_data' => $signature_data,
        ];
        $update_formats = ['%s', '%s', '%s', '%s'];

        // Add selected_items only if the column exists (migration 1.2.0)
        $token_columns = $wpdb->get_col('DESCRIBE ' . ECWP_TABLE_QUOTE_TOKENS);
        if (in_array('selected_items', $token_columns, true)) {
            $update_data['selected_items'] = $selected_items;
            $update_formats[]              = '%s';
        }

        $wpdb->update(
            ECWP_TABLE_QUOTE_TOKENS,
            $update_data,
            ['token' => $token],
            $update_formats,
            ['%s']
        );

        // Update quote status (core system uses 'approved'/'rejected')
        $new_status = $action === 'accepted' ? 'approved' : 'rejected';
        $wpdb->update(
            ECWP_TABLE_QUOTES,
            ['status' => $new_status],
            ['id' => $row->quote_id],
            ['%s'],
            ['%d']
        );

        // Send email notification to admin
        $this->send_action_notification($row->quote_id, $action, $comment);

        // Fire action hook so core/addons can react
        do_action('ecwp_online_quote_actioned', $row->quote_id, $action, $comment);

        return rest_ensure_response([
            'success' => true,
            'action'  => $action,
        ]);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private function send_action_notification(int $quote_id, string $action, string $comment): void
    {
        $log = WP_CONTENT_DIR . '/ecwp_quote_mail.log';
        $ts  = date('[Y-m-d H:i:s]');

        try {
            global $wpdb;

            file_put_contents($log, "$ts START quote=$quote_id action=$action\n", FILE_APPEND | LOCK_EX);

            // Check if admin notification is enabled
            $notify = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
                'ecwp_notify_quote_action'
            ));
            file_put_contents($log, "$ts notify_setting=" . var_export($notify, true) . "\n", FILE_APPEND | LOCK_EX);

            if ($notify === '0') {
                file_put_contents($log, "$ts SKIPPED (disabled in settings)\n", FILE_APPEND | LOCK_EX);
                return;
            }

            $admin_email = get_option('admin_email');
            file_put_contents($log, "$ts admin_email=" . var_export($admin_email, true) . "\n", FILE_APPEND | LOCK_EX);

            if (!$admin_email) {
                file_put_contents($log, "$ts SKIPPED (no admin_email)\n", FILE_APPEND | LOCK_EX);
                return;
            }

            $quote = $wpdb->get_row($wpdb->prepare(
                "SELECT q.quote_number, c.company_name
                 FROM " . ECWP_TABLE_QUOTES . " AS q
                 LEFT JOIN " . ECWP_TABLE_CLIENTS . " AS c ON q.client_id = c.id
                 WHERE q.id = %d",
                $quote_id
            ));

            $action_emoji = $action === 'accepted' ? '✅' : '❌';
            $action_label = $action === 'accepted' ? 'accepté' : 'refusé';
            $quote_number = $quote ? ($quote->quote_number ?? "#{$quote_id}") : "#{$quote_id}";
            $client_name  = $quote ? ($quote->company_name ?? 'Client inconnu') : 'Client inconnu';

            $subject = "{$action_emoji} Devis {$quote_number} {$action_label} — {$client_name}";
            file_put_contents($log, "$ts subject=$subject\n", FILE_APPEND | LOCK_EX);

            // Use modern template if EmailTemplate class is available
            $template_file = defined('ECWP_PATH')
                ? ECWP_PATH . '/includes/Modules/EmailTemplate.php'
                : plugin_dir_path(__FILE__) . '../../my-easy-compta/includes/Modules/EmailTemplate.php';

            if (file_exists($template_file) && !class_exists('ECWP\\Admin\\EmailTemplate')) {
                require_once $template_file;
            }

            file_put_contents($log, "$ts EmailTemplate_exists=" . (class_exists('ECWP\\Admin\\EmailTemplate') ? 'yes' : 'no') . "\n", FILE_APPEND | LOCK_EX);

            if (class_exists('ECWP\\Admin\\EmailTemplate')) {
                $body = \ECWP\Admin\EmailTemplate::render(
                    $action === 'accepted' ? 'quote_accepted' : 'quote_rejected',
                    [
                        'quote_number' => $quote_number,
                        'client_name'  => $client_name,
                        'comment'      => $comment,
                        'view_url'     => admin_url('admin.php?page=my-easy-compta#/quotes/detail/' . $quote_id),
                    ]
                );
            } else {
                $body  = "<p>Bonjour,</p>";
                $body .= "<p>Le devis <strong>" . esc_html($quote_number) . "</strong> a été <strong>{$action_label}</strong> par <strong>" . esc_html($client_name) . "</strong>.</p>";
                if ($comment) $body .= "<p><em>Commentaire :</em> " . esc_html($comment) . "</p>";
            }

            $failed_reason = '';
            add_action('wp_mail_failed', function (\WP_Error $err) use (&$failed_reason) {
                $failed_reason = implode(', ', $err->get_error_messages());
            });

            $sent = wp_mail($admin_email, $subject, $body, ['Content-Type: text/html; charset=UTF-8']);
            file_put_contents($log, "$ts wp_mail=" . ($sent ? 'OK' : 'FAILED') . ($failed_reason ? " reason=$failed_reason" : '') . "\n", FILE_APPEND | LOCK_EX);

        } catch (\Throwable $e) {
            file_put_contents($log, "$ts EXCEPTION " . $e->getMessage() . " in " . $e->getFile() . ':' . $e->getLine() . "\n", FILE_APPEND | LOCK_EX);
        }
    }

    private function get_valid_token(string $token): object
    {
        global $wpdb;
        $table = ECWP_TABLE_QUOTE_TOKENS;

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE token = %s",
            $token
        ));

        if (!$row) {
            return new WP_Error('invalid_token', 'Invalid or expired link.', ['status' => 404]);
        }

        if ($row->expires_at && strtotime($row->expires_at) < current_time('timestamp')) {
            return new WP_Error('token_expired', 'This link has expired.', ['status' => 410]);
        }

        return $row;
    }

    private function get_quote_data(int $quote_id): array
    {
        global $wpdb;
        $qt = ECWP_TABLE_QUOTES;
        $ct = ECWP_TABLE_CLIENTS;
        $cr = ECWP_TABLE_CURRENCY;
        $qe = ECWP_TABLE_QUOTE_ELEMENTS;

        $quote = $wpdb->get_row($wpdb->prepare(
            "SELECT q.*, c.company_name, c.email, c.address, c.city, c.postal_code AS zip_code, c.country, c.phone,
                    cur.symbol AS currency_symbol, cur.code AS currency_code
             FROM {$qt} AS q
             LEFT JOIN {$ct}  AS c   ON q.client_id  = c.id
             LEFT JOIN {$cr}  AS cur ON c.currency_id = cur.id
             WHERE q.id = %d",
            $quote_id
        ), ARRAY_A);

        if (!$quote) return [];

        $items = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$qe} WHERE quote_id = %d ORDER BY item_order ASC",
            $quote_id
        ), ARRAY_A);

        $quote['items']          = $items ?: [];
        $quote['currency_symbol'] = $quote['currency_symbol'] ?: '€';

        return $quote;
    }

    private function get_company_data(): array
    {
        global $wpdb;
        $table = ECWP_TABLE_SETTINGS;

        $rows = $wpdb->get_results(
            "SELECT meta_key, meta_value FROM {$table}",
            ARRAY_A
        );

        $settings = [];
        foreach ($rows as $row) {
            $settings[$row['meta_key']] = $row['meta_value'];
        }

        return [
            'name'    => $settings['company_name']    ?? '',
            'address' => $settings['company_address'] ?? '',
            'city'    => $settings['company_city']    ?? '',
            'zip'     => $settings['company_zip']     ?? '',
            'country' => $settings['company_country'] ?? '',
            'email'   => $settings['company_email']   ?? '',
            'phone'   => $settings['company_phone']   ?? '',
            'logo'    => $settings['company_logo']    ?? '',
            'siret'   => $settings['company_siren']   ?? '',
            'vat'     => $settings['company_tva']     ?? '',
        ];
    }

    private function build_public_url(string $token): string
    {
        return home_url('/?ecwp_online_quote=' . $token);
    }
}
