<?php

if (!defined('ABSPATH')) exit;

function ecwp_online_quote_run_migration()
{
    global $wpdb;
    if (!defined('ECWP_TABLE_QUOTE_TOKENS')) return;

    $charset = $wpdb->get_charset_collate();
    $table   = ECWP_TABLE_QUOTE_TOKENS;

    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id             int(11)       NOT NULL AUTO_INCREMENT,
        quote_id       int(11)       NOT NULL,
        token          varchar(64)   NOT NULL,
        expires_at     datetime      DEFAULT NULL,
        viewed_at      datetime      DEFAULT NULL,
        action         varchar(20)   DEFAULT NULL COMMENT 'accepted|rejected',
        action_at      datetime      DEFAULT NULL,
        client_comment text          DEFAULT NULL,
        signature_data mediumtext    DEFAULT NULL,
        created_at     datetime      NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY idx_token    (token),
        KEY idx_quote_id        (quote_id)
    ) {$charset};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    // Add signature_data column if upgrading from 1.0.0
    $columns = $wpdb->get_col("DESCRIBE {$table}");
    if (!in_array('signature_data', $columns, true)) {
        $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `signature_data` MEDIUMTEXT DEFAULT NULL AFTER `client_comment`");
    }

    // 1.2.0 — store which optional items the client selected
    if (!in_array('selected_items', $columns, true)) {
        $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `selected_items` TEXT DEFAULT NULL AFTER `signature_data`");
    }

    // 1.2.0 — fix wrong quote statuses written by earlier versions of public_action()
    // ('accepted' → 'approved', 'refused' → 'rejected')
    if (defined('ECWP_TABLE_QUOTES')) {
        $qt = ECWP_TABLE_QUOTES;
        $wpdb->query("UPDATE `{$qt}` SET status = 'approved' WHERE status = 'accepted'");
        $wpdb->query("UPDATE `{$qt}` SET status = 'rejected' WHERE status = 'refused'");
    }

    update_option('ecwp_online_quote_db_version', '1.2.0');
}
