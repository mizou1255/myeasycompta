<?php

namespace ECWP\Addon\TimeTracking;

use ECWP\API\Routes;

/**
 * Time Tracking REST endpoints.
 *
 * GET    /time-entries                    list (paginated, filterable by client/status)
 * POST   /time-entries                    create entry
 * GET    /time-entries/{id}               single entry
 * PUT    /time-entries/{id}               update entry
 * DELETE /time-entries/{id}               delete entry
 * POST   /time-entries/timer/start        start live timer (stores start_time, no end_time)
 * PUT    /time-entries/timer/{id}/stop    stop live timer (computes duration)
 * POST   /time-entries/generate-invoice   bulk → create invoice from selected pending entries
 */
class ECWP_TimeTracking
{
    public function __construct()
    {
        $routes = new Routes();
        $auth   = fn () => current_user_can('manage_options');

        $routes->add_route('/time-entries',                         'GET',    $this, 'get_entries',       $auth);
        $routes->add_route('/time-entries',                         'POST',   $this, 'add_entry',         $auth);
        $routes->add_route('/time-entries/timer/start',             'POST',   $this, 'start_timer',       $auth);
        $routes->add_route('/time-entries/generate-invoice',        'POST',   $this, 'generate_invoice',  $auth);
        $routes->add_route('/time-entries/(?P<id>\d+)',             'GET',    $this, 'get_entry',         $auth);
        $routes->add_route('/time-entries/(?P<id>\d+)',             'PUT',    $this, 'update_entry',      $auth);
        $routes->add_route('/time-entries/(?P<id>\d+)',             'DELETE', $this, 'delete_entry',      $auth);
        $routes->add_route('/time-entries/timer/(?P<id>\d+)/stop',  'PUT',    $this, 'stop_timer',        $auth);
        $routes->register_routes();
    }

    // ── List ─────────────────────────────────────────────────────────────────

    public function get_entries($request)
    {
        global $wpdb;

        $per_page  = max(1, (int) ($request->get_param('per_page') ?: 20));
        $page      = max(1, (int) ($request->get_param('page')     ?: 1));
        $offset    = ($page - 1) * $per_page;
        $status    = $request->get_param('status');
        $client_id = (int) $request->get_param('client_id');

        $where  = 'WHERE 1=1';
        $params = [];

        if ($status && in_array($status, ['pending', 'invoiced'], true)) {
            $where   .= ' AND t.status = %s';
            $params[] = $status;
        }
        if ($client_id > 0) {
            $where   .= ' AND t.client_id = %d';
            $params[] = $client_id;
        }

        $count_sql = "SELECT COUNT(*) FROM " . ECWP_TABLE_TIME_ENTRIES . " t $where";
        $total     = (int) ($params ? $wpdb->get_var($wpdb->prepare($count_sql, ...$params)) : $wpdb->get_var($count_sql));

        $rows_sql = "SELECT t.*, c.company_name AS client_name
                     FROM " . ECWP_TABLE_TIME_ENTRIES . " t
                     LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON c.id = t.client_id
                     $where
                     ORDER BY t.start_time DESC
                     LIMIT %d OFFSET %d";

        $rows = $wpdb->get_results(
            $wpdb->prepare($rows_sql, ...[...$params, $per_page, $offset]),
            ARRAY_A
        );

        // Compute formatted duration for each row
        foreach ($rows as &$row) {
            $row['duration_formatted'] = $this->format_duration((int) $row['duration_minutes']);
            $row['amount']             = round((float) $row['hourly_rate'] * ((int) $row['duration_minutes'] / 60), 2);
        }

        return ['data' => $rows ?: [], 'total' => $total, 'per_page' => $per_page, 'page' => $page, 'last_page' => (int) ceil($total / $per_page)];
    }

    // ── Single ───────────────────────────────────────────────────────────────

    public function get_entry($request)
    {
        $row = $this->fetch((int) $request->get_param('id'));
        return $row ?: new \WP_Error('not_found', 'Entrée introuvable.', ['status' => 404]);
    }

    // ── Create (manual entry) ─────────────────────────────────────────────────

    public function add_entry($request)
    {
        global $wpdb;

        $data = $this->sanitize($request);
        if (is_wp_error($data)) return $data;

        // Compute duration if start + end given
        if ($data['start_time'] && $data['end_time'] && !$data['duration_minutes']) {
            $data['duration_minutes'] = $this->compute_duration($data['start_time'], $data['end_time']);
        }

        $wpdb->insert(ECWP_TABLE_TIME_ENTRIES, $data, $this->formats($data));
        if ($wpdb->last_error) return new \WP_Error('db_error', $wpdb->last_error, ['status' => 500]);

        return $this->fetch($wpdb->insert_id);
    }

    // ── Update ────────────────────────────────────────────────────────────────

    public function update_entry($request)
    {
        global $wpdb;
        $id = (int) $request->get_param('id');
        if (!$this->fetch($id)) return new \WP_Error('not_found', 'Entrée introuvable.', ['status' => 404]);

        $data = $this->sanitize($request);
        if (is_wp_error($data)) return $data;

        if ($data['start_time'] && $data['end_time']) {
            $data['duration_minutes'] = $this->compute_duration($data['start_time'], $data['end_time']);
        }

        $wpdb->update(ECWP_TABLE_TIME_ENTRIES, $data, ['id' => $id], $this->formats($data), ['%d']);
        return $this->fetch($id);
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    public function delete_entry($request)
    {
        global $wpdb;
        $id      = (int) $request->get_param('id');
        $deleted = $wpdb->delete(ECWP_TABLE_TIME_ENTRIES, ['id' => $id], ['%d']);
        return $deleted ? ['success' => true] : new \WP_Error('not_found', 'Entrée introuvable.', ['status' => 404]);
    }

    // ── Live Timer: Start ─────────────────────────────────────────────────────

    public function start_timer($request)
    {
        global $wpdb;

        $client_id   = (int) ($request->get_param('client_id') ?: 0);
        $project     = sanitize_text_field($request->get_param('project_name') ?: '');
        $description = sanitize_textarea_field($request->get_param('description') ?: '');
        $hourly_rate = (float) ($request->get_param('hourly_rate') ?: 0);

        // Stop any running timer for this user first
        $now = current_time('mysql');
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . ECWP_TABLE_TIME_ENTRIES . "
                 SET end_time = %s,
                     duration_minutes = TIMESTAMPDIFF(MINUTE, start_time, %s)
                 WHERE end_time IS NULL AND status = 'pending'",
                $now,
                $now
            )
        );

        $wpdb->insert(ECWP_TABLE_TIME_ENTRIES, [
            'client_id'    => $client_id ?: null,
            'project_name' => $project,
            'description'  => $description,
            'start_time'   => current_time('mysql'),
            'hourly_rate'  => $hourly_rate,
            'status'       => 'pending',
        ], ['%d', '%s', '%s', '%s', '%f', '%s']);

        return $this->fetch($wpdb->insert_id);
    }

    // ── Live Timer: Stop ──────────────────────────────────────────────────────

    public function stop_timer($request)
    {
        global $wpdb;
        $id  = (int) $request->get_param('id');
        $row = $this->fetch($id);
        if (!$row) return new \WP_Error('not_found', 'Entrée introuvable.', ['status' => 404]);

        $now      = current_time('mysql');
        $duration = $this->compute_duration($row['start_time'], $now);

        $wpdb->update(
            ECWP_TABLE_TIME_ENTRIES,
            ['end_time' => $now, 'duration_minutes' => $duration],
            ['id' => $id],
            ['%s', '%d'],
            ['%d']
        );

        return $this->fetch($id);
    }

    // ── Generate Invoice from selected entries ────────────────────────────────

    public function generate_invoice($request)
    {
        global $wpdb;

        $ids       = array_map('intval', (array) ($request->get_param('ids') ?: []));
        $client_id = (int) ($request->get_param('client_id') ?: 0);

        if (empty($ids) || !$client_id) {
            return new \WP_Error('missing_params', 'ids et client_id sont requis.', ['status' => 400]);
        }

        // Fetch entries
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $entries = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . ECWP_TABLE_TIME_ENTRIES . "
                 WHERE id IN ($placeholders) AND status = 'pending' AND client_id = %d",
                ...[...$ids, $client_id]
            ),
            ARRAY_A
        );

        if (empty($entries)) {
            return new \WP_Error('no_entries', 'Aucune entrée valide trouvée.', ['status' => 404]);
        }

        // Build invoice via core ECWP_Invoices::add_invoices() REST endpoint (internal call)
        // We compose the invoice items from time entries
        $items     = [];
        $total_ht  = 0.0;

        foreach ($entries as $e) {
            $hours  = round((int) $e['duration_minutes'] / 60, 2);
            $rate   = (float) $e['hourly_rate'];
            $amount = round($hours * $rate, 2);
            $total_ht += $amount;

            $label = $e['project_name'] ?: 'Prestation';
            if ($e['description']) $label .= ' — ' . $e['description'];

            $items[] = [
                'description' => $label,
                'quantity'    => $hours,
                'unit_price'  => $rate,
                'subtotal'    => $amount,
            ];
        }

        // Create invoice record directly (mirrors core add_invoices logic)
        $settings_table = ECWP_TABLE_SETTINGS;
        $encrypt        = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        $invoice_prefix = (string) $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$settings_table} WHERE meta_key = %s", 'invoice_prefix'
        )) ?: 'INV';

        $last_id = (int) ($wpdb->get_var("SELECT MAX(number) FROM " . ECWP_TABLE_INVOICES) ?: 0) + 1;
        $inv_number = $invoice_prefix . '-' . str_pad($last_id, 4, '0', STR_PAD_LEFT);

        $wpdb->insert(ECWP_TABLE_INVOICES, [
            'number'         => $last_id,
            'invoice_number' => $encrypt->encrypt($inv_number),
            'client_id'      => $client_id,
            'status'         => $encrypt->encrypt('unpaid'),
            'status_stats'   => 'unpaid',
            'amount'         => $encrypt->encrypt((string) $total_ht),
            'total_amount'   => $encrypt->encrypt((string) $total_ht),
            'credit'         => 0,
            'created_at'     => wp_date('Y-m-d'),
            'fiscal_status'  => 'draft',
        ]);

        $invoice_id = $wpdb->insert_id;
        if (!$invoice_id) return new \WP_Error('db_error', 'Erreur création facture.', ['status' => 500]);

        // Insert invoice items
        foreach ($items as $idx => $item) {
            $wpdb->insert(ECWP_TABLE_INVOICE_ELEMENTS, [
                'invoice_id'       => $invoice_id,
                'item_name'        => $item['description'],
                'item_ref'         => '',
                'item_category'    => 0,
                'item_description' => '',
                'quantity'         => (string) $item['quantity'],
                'vat_rate'         => '0',
                'unit_price'       => $encrypt->encrypt((string) $item['unit_price']),
                'discount'         => '0',
                'total_price'      => $encrypt->encrypt((string) $item['subtotal']),
                'total_amount'     => $encrypt->encrypt((string) $item['subtotal']),
                'item_order'       => $idx + 1,
            ]);
        }

        // Mark entries as invoiced
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . ECWP_TABLE_TIME_ENTRIES . "
                 SET status = 'invoiced', invoice_id = %d
                 WHERE id IN ($placeholders)",
                ...[$invoice_id, ...$ids]
            )
        );

        return ['invoice_id' => $invoice_id, 'invoice_number' => $inv_number, 'total' => $total_ht, 'entries_count' => count($entries)];
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function fetch(int $id): ?array
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT t.*, c.company_name AS client_name
             FROM " . ECWP_TABLE_TIME_ENTRIES . " t
             LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON c.id = t.client_id
             WHERE t.id = %d", $id
        ), ARRAY_A);

        if (!$row) return null;
        $row['duration_formatted'] = $this->format_duration((int) $row['duration_minutes']);
        $row['amount']             = round((float) $row['hourly_rate'] * ((int) $row['duration_minutes'] / 60), 2);
        return $row;
    }

    private function sanitize($request): array|\WP_Error
    {
        return [
            'client_id'        => $request->get_param('client_id')  ? (int) $request->get_param('client_id') : null,
            'project_name'     => sanitize_text_field($request->get_param('project_name')  ?: ''),
            'description'      => sanitize_textarea_field($request->get_param('description') ?: ''),
            'start_time'       => sanitize_text_field($request->get_param('start_time') ?: current_time('mysql')),
            'end_time'         => $request->get_param('end_time') ? sanitize_text_field($request->get_param('end_time')) : null,
            'duration_minutes' => (int) ($request->get_param('duration_minutes') ?: 0),
            'hourly_rate'      => (float) ($request->get_param('hourly_rate')     ?: 0),
            'status'           => 'pending',
        ];
    }

    private function formats(array $data): array
    {
        $map = [
            'client_id' => '%d', 'project_name' => '%s', 'description' => '%s',
            'start_time' => '%s', 'end_time' => '%s', 'duration_minutes' => '%d',
            'hourly_rate' => '%f', 'status' => '%s',
        ];
        return array_values(array_intersect_key($map, $data));
    }

    private function compute_duration(string $start, string $end): int
    {
        $diff = strtotime($end) - strtotime($start);
        return max(0, (int) floor($diff / 60));
    }

    private function format_duration(int $minutes): string
    {
        $h = (int) floor($minutes / 60);
        $m = $minutes % 60;
        return sprintf('%dh%02d', $h, $m);
    }
}
