<?php

if (!defined('ABSPATH')) exit;

function ecwp_time_run_migration()
{
    global $wpdb;
    if (!defined('ECWP_TABLE_TIME_ENTRIES')) return;

    $charset = $wpdb->get_charset_collate();
    $table   = ECWP_TABLE_TIME_ENTRIES;

    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id               int(11)        NOT NULL AUTO_INCREMENT,
        client_id        int(11)        DEFAULT NULL,
        project_name     varchar(255)   NOT NULL DEFAULT '',
        description      text,
        start_time       datetime       NOT NULL,
        end_time         datetime       DEFAULT NULL,
        duration_minutes int(11)        NOT NULL DEFAULT 0,
        hourly_rate      decimal(10,2)  NOT NULL DEFAULT 0.00,
        invoice_id       int(11)        DEFAULT NULL COMMENT 'Set when invoiced',
        status           varchar(20)    NOT NULL DEFAULT 'pending' COMMENT 'pending|invoiced',
        created_at       datetime       NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at       datetime       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY idx_client_id  (client_id),
        KEY idx_status     (status),
        KEY idx_invoice_id (invoice_id)
    ) {$charset};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    update_option('ecwp_time_db_version', '1.0.0');
}
