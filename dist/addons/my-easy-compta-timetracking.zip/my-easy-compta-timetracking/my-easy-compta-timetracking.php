<?php
/**
 * Plugin Name: myEasyCompta - Temps & Facturation
 * Description: Chronomètrez vos tâches par client et générez automatiquement une facture à partir des heures saisies. Indispensable pour consultants, développeurs et prestataires de services.
 * Version: 1.0.0
 * Author: MELIOZ.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-timetracking
 * Domain Path: /languages/
 * Requires at least: 6.2
 * Tested up to: 6.9
 * Requires PHP: 8.0
 * Requires Plugins: my-easy-compta
 * Tags: time tracking, billing, invoices, freelance, consulting
 */

if (!defined('ABSPATH')) exit;

define('ECWP_TIME_VERSION',  '1.0.0');
define('ECWP_TIME_PATH',     plugin_dir_path(__FILE__));
define('ECWP_TIME_URL',      plugins_url('', __FILE__));
define('ECWP_TIME_INCLUDES', ECWP_TIME_PATH . 'includes');

add_action('plugins_loaded', function () {
    if (!defined('ECWP_PREFIX')) return;
    if (!defined('ECWP_TABLE_TIME_ENTRIES')) {
        define('ECWP_TABLE_TIME_ENTRIES', ECWP_PREFIX . 'ecwp_time_entries');
    }
}, 5);

add_action('plugins_loaded', function () {
    if (!class_exists('ECWP_Easy_Compta')) return;

    require_once ECWP_TIME_INCLUDES . '/Migration.php';
    require_once ECWP_TIME_INCLUDES . '/TimeTracking.php';

    add_action('admin_init', 'ecwp_time_maybe_migrate');
    add_action('admin_enqueue_scripts', 'ecwp_time_enqueue');

    new ECWP\Addon\TimeTracking\ECWP_TimeTracking();
}, 20);

function ecwp_time_enqueue($hook)
{
    if ($hook !== 'toplevel_page_my-easy-compta') return;
    wp_add_inline_script(
        'my-easy-compta-admin',
        'if(window.myEasyComptaAdmin){window.myEasyComptaAdmin.timetrackingAddonActive=true;}',
        'after'
    );
}

function ecwp_time_maybe_migrate()
{
    if (get_option('ecwp_time_db_version') !== '1.0.0') {
        require_once ECWP_TIME_INCLUDES . '/Migration.php';
        ecwp_time_run_migration();
    }
}

register_activation_hook(__FILE__, function () {
    if (!defined('ECWP_PREFIX')) { global $wpdb; define('ECWP_PREFIX', $wpdb->prefix); }
    if (!defined('ECWP_TABLE_TIME_ENTRIES')) define('ECWP_TABLE_TIME_ENTRIES', ECWP_PREFIX . 'ecwp_time_entries');
    require_once ECWP_TIME_INCLUDES . '/Migration.php';
    ecwp_time_run_migration();
});
