<?php
/**
 * Plugin Name: myEasyCompta - Backup Addon
 * Description: myEasyCompta Backup plugin provides integrated solutions for securely backing up, restoring, and managing financial data.
 * Version: 2.0.0
 * Author: MELIOZE.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-backup
 * Domain Path: /languages/
 * Requires at least: 6.2
 * Tested up to: 6.6.1
 * Requires PHP: 8.0
 * Tags: backup, database,
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ECWP_Easy_Compta_Backup
{
    /**
     * Plugin version
     *
     * @var string
     */
    public $version = '2.0.0';

    /**
     * Minimum required PHP version
     *
     * @var string
     */
    private $min_php = '8.0';

    private $container = [];

    /**
     * Singleton instance
     *
     * @var ECWP_Easy_Compta_Backup
     */
    private static $instance;

    /**
     * Initialize the plugin
     *
     * @return ECWP_Easy_Compta_Backup
     */
    public static function init()
    {
        if (!isset(self::$instance) && !(self::$instance instanceof ECWP_Easy_Compta_Backup)) {
            self::$instance = new ECWP_Easy_Compta_Backup();
            self::$instance->setup();
        }

        return self::$instance;
    }

    /**
     * Setup the plugin
     *
     * @return void
     */
    private function setup()
    {
        register_activation_hook(__FILE__, [$this, 'auto_deactivate']);

        if (!$this->is_supported_php()) {
            return;
        }

        $this->define_constants();
        $this->includes();
        $this->instantiate();
        $this->init_actions();
    }

    /**
     * Define plugin constants
     *
     * @return void
     */
    private function define_constants()
    {
        global $wpdb;
        define('ECWP_BACKUP_PATH', dirname(__FILE__));
        define('ECWP_BACKUP_PATH_DIR', plugin_dir_path(__FILE__));
        define('ECWP_BACKUP_INCLUDES', ECWP_BACKUP_PATH . '/includes');
        define('ECWP_BACKUP_URL', plugins_url('', __FILE__));
        if (!defined('ECWP_PRINCIPAL_PATH')) {
            define('ECWP_PRINCIPAL_PATH', WP_CONTENT_DIR . '/plugins/my-easy-compta');
        }
        if (!defined('ECWP_PREFIX')) {
            define('ECWP_PREFIX', $wpdb->prefix);
        }

        define('ECWP_TABLE_BACKUP', ECWP_PREFIX . 'ecwp_backup');

    }

    /**
     * Include required files
     *
     * @return void
     */
    private function includes()
    {
        require_once ECWP_PRINCIPAL_PATH . '/includes/API/Routes.php';
        require_once ECWP_BACKUP_INCLUDES . '/migrations.php';
        require_once ECWP_BACKUP_INCLUDES . '/App.php';
        require_once ECWP_BACKUP_INCLUDES . '/Cron.php';
        require_once ECWP_BACKUP_INCLUDES . '/Notify.php';
        require_once ECWP_BACKUP_INCLUDES . '/Cloud/CloudProviderInterface.php';
        require_once ECWP_BACKUP_INCLUDES . '/Cloud/CloudManager.php';
        require_once ECWP_BACKUP_INCLUDES . '/Cloud/FTPProvider.php';
        require_once ECWP_BACKUP_INCLUDES . '/Cloud/S3Provider.php';
        require_once ECWP_BACKUP_INCLUDES . '/Cloud/DropboxProvider.php';
        require_once ECWP_BACKUP_INCLUDES . '/Backup.php';
    }

    /**
     * Instantiate necessary classes or services
     *
     * @return void
     */

    private function instantiate()
    {
        $this->container['migration'] = new ECWP\Backup\ECWPBackup_Migrations();
        $this->container['app']       = new ECWP\Backup\ECWPBackup_APP();
        $this->container['cron']      = new ECWP\Backup\ECWPBackup_Cron();
        $this->container['backup']    = new ECWP\Backup\ECWPBackup_Backup();
    }

    /**
     * Initialize actions and hooks
     *
     * @return void
     */
    private function init_actions()
    {
        add_action('admin_init', [$this, 'check_plugin_dependencies']);
        add_action('admin_init', function () {
            if (isset($this->container['migration'])) {
                $this->container['migration']->maybe_upgrade();
            }
        });
        register_activation_hook(__FILE__, [$this->container['migration'], 'plugin_activation']);
        register_deactivation_hook(__FILE__, [$this->container['migration'], 'plugin_desactivation']);
    }

    /**
     * Check if the PHP version is supported
     *
     * @return bool
     */
    public function is_supported_php()
    {
        return version_compare(PHP_VERSION, $this->min_php, '>=');
    }

    /**
     * Deactivate the plugin if the PHP version is not supported
     *
     * @return void
     */
    public function auto_deactivate()
    {
        if (!$this->is_supported_php()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires PHP version %s or higher.',
                        'my-easy-compta-backup'
                    ),
                    esc_html__('myEasyCompta Backup Addon', 'my-easy-compta-backup'),
                    esc_html($this->min_php)
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta-backup'),
                ['response' => 200, 'back_link' => true]
            );
        }
        if (!is_plugin_active('my-easy-compta/my-easy-compta.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires the myEasyCompta plugin to be active.',
                        'myEasyCompta Backup'
                    ),
                    esc_html__('myEasyCompta Backup', 'my-easy-compta')
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta'),
                ['response' => 200, 'back_link' => true]
            );
        }
    }
    /**
     * Check if myEasyCompta plugin are activated
     */
    public function check_plugin_dependencies()
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            add_action('admin_notices', [$this, 'display_missing_dependencies_notice']);
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }

    /**
     * Display a notice if myEasyCompta plugin are not activated
     */
    public function display_missing_dependencies_notice()
    {?>
<div class="notice notice-error is-dismissible">
    <p><?php _e('myEasyCompta Backup requires the myEasyCompta plugin to be activated. Please activate them before activating this plugin.', 'my-easy-compta');?>
    </p>
</div>
<?php
}
}

/**
 * Initialize the ECWP_Easy_Compta_Backup plugin
 *
 * @return ECWP_Easy_Compta_Backup
 */
ECWP_Easy_Compta_Backup::init();