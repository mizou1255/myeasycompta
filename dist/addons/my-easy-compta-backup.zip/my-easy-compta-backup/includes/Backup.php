<?php

namespace ECWP\Backup;

use ECWP\API\Routes;

class ECWPBackup_Backup
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $auth = function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        };

        // ── Existing routes ──────────────────────────────────────────────────────
        $this->routes->add_route('/backup-data',                          'POST',   $this, 'backup_data',           $auth);
        $this->routes->add_route('/backup-list',                          'GET',    $this, 'backup_list',           $auth);
        $this->routes->add_route('/delete-backup/(?P<id>\d+)',            'DELETE', $this, 'delete_backup',         $auth);
        $this->routes->add_route('/download-backup',                      'GET',    $this, 'download_backup',       $auth);
        $this->routes->add_route('/restore-backup',                       'POST',   $this, 'restore_backup',        $auth);
        $this->routes->add_route('/backup-settings',                      'GET',    $this, 'get_backup_settings',   $auth);
        $this->routes->add_route('/backup-settings',                      'POST',   $this, 'save_backup_settings',  $auth);

        // ── New routes ────────────────────────────────────────────────────────────
        $this->routes->add_route('/backup-schedule',                      'GET',    $this, 'get_schedule',          $auth);
        $this->routes->add_route('/backup-schedule',                      'POST',   $this, 'save_schedule',         $auth);
        $this->routes->add_route('/backup-cloud-config',                  'GET',    $this, 'get_cloud_config',      $auth);
        $this->routes->add_route('/backup-cloud-config',                  'POST',   $this, 'save_cloud_config',     $auth);
        $this->routes->add_route('/backup-cloud-test',                    'POST',   $this, 'test_cloud',            $auth);
        $this->routes->add_route('/backup-cloud-upload/(?P<id>\d+)',      'POST',   $this, 'cloud_upload_backup',   $auth);
        $this->routes->add_route('/backup-notifications',                 'GET',    $this, 'get_notifications',     $auth);
        $this->routes->add_route('/backup-notifications',                 'POST',   $this, 'save_notifications',    $auth);

        $this->routes->register_routes();
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    /**
     * Returns the canonical whitelist of table name constants allowed for backup/restore.
     * Using a method ensures only plugin-owned tables can ever be touched.
     */
    private function get_backup_tables(): array
    {
        if (!function_exists('is_plugin_active')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $tables = [
            ECWP_TABLE_BACKUP,
            ECWP_TABLE_CLIENTS,
            ECWP_TABLE_QUOTES,
            ECWP_TABLE_INVOICES,
            ECWP_TABLE_SETTINGS,
            ECWP_TABLE_INVOICE_ELEMENTS,
            ECWP_TABLE_QUOTE_ELEMENTS,
            ECWP_TABLE_PAYMENTS,
            ECWP_TABLE_PAYMENTS_METHODS,
            ECWP_TABLE_EXPENSES,
            ECWP_TABLE_EXPENSES_CATEGORIES,
            ECWP_TABLE_EXPENSES_ATTACHMENTS,
            ECWP_TABLE_CURRENCY,
            ECWP_TABLE_VATS,
        ];

        if (is_plugin_active('my-easy-compta-email/my-easy-compta-email.php') && defined('ECWP_TABLE_EMAILS_LOG')) {
            $tables[] = ECWP_TABLE_EMAILS_LOG;
        }
        if (is_plugin_active('my-easy-compta-planning/my-easy-compta-planning.php') && defined('ECWP_TABLE_PLANNING_EVENTS')) {
            $tables[] = ECWP_TABLE_PLANNING_EVENTS;
            $tables[] = ECWP_TABLE_PLANNING_EVENTS_CATEGORIES;
        }

        return array_unique($tables);
    }

    // =========================================================================
    // Core backup logic (shared by HTTP endpoint and cron)
    // =========================================================================

    /**
     * Perform a full backup without any HTTP context.
     * Returns an array with backup metadata on success, or WP_Error on failure.
     *
     * @return array{id:int,filename:string,filepath:string,file_size:string,checksum:string}|\WP_Error
     */
    public function do_backup_internal(): array|\WP_Error
    {
        global $wpdb;

        $tables_to_backup = $this->get_backup_tables();
        $backup_dir       = ECWP_BACKUP_PATH_DIR . '/backups/';

        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
            file_put_contents($backup_dir . '.htaccess', "Order Allow,Deny\nDeny from all\n");
        }

        // Disk space guard: require at least 50 MB free
        $free_bytes = function_exists('disk_free_space') ? disk_free_space($backup_dir) : false;
        if ($free_bytes !== false && $free_bytes < 50 * 1024 * 1024) {
            return new \WP_Error('disk_full', 'Espace disque insuffisant (minimum 50 Mo requis).');
        }

        // Build SQL dump into a string buffer, then compress
        $sql_buffer  = "-- Easy Compta Plugin Backup " . current_time('mysql') . "\n";
        $sql_buffer .= "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";

        foreach ($tables_to_backup as $table_name) {
            // Table names come exclusively from plugin-defined constants — safe to interpolate.
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $table_structure = $wpdb->get_results("SHOW CREATE TABLE `{$table_name}`", ARRAY_N);
            if ($table_structure && isset($table_structure[0][1])) {
                $sql_buffer .= "-- Table: {$table_name}\n";
                $sql_buffer .= "DROP TABLE IF EXISTS `{$table_name}`;\n";
                $sql_buffer .= $table_structure[0][1] . ";\n\n";

                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $table_data = $wpdb->get_results("SELECT * FROM `{$table_name}`", ARRAY_A);
                if ($table_data) {
                    $sql_buffer .= "-- Data for {$table_name}\n";
                    foreach ($table_data as $row) {
                        $columns = implode(', ', array_map(fn($col) => '`' . str_replace('`', '``', $col) . '`', array_keys($row)));
                        $values  = implode(', ', array_map(function ($val) use ($wpdb) {
                            return $val === null ? 'NULL' : "'" . $wpdb->_real_escape($val) . "'";
                        }, $row));
                        $sql_buffer .= "INSERT INTO `{$table_name}` ({$columns}) VALUES ({$values});\n";
                    }
                    $sql_buffer .= "\n";
                }
            }
        }

        $sql_buffer .= "SET FOREIGN_KEY_CHECKS = 1;\n";

        $checksum        = hash('sha256', $sql_buffer);
        $backup_filename = 'backup_' . wp_date('Y-m-d_His') . '.sql.gz';
        $backup_filepath = $backup_dir . $backup_filename;

        $compressed = gzencode($sql_buffer, 6);
        if ($compressed === false) {
            return new \WP_Error('compress_error', 'Échec de la compression.');
        }
        if (file_put_contents($backup_filepath, $compressed) === false) {
            return new \WP_Error('file_write_error', 'Échec de l\'écriture du fichier.');
        }

        $wpdb->insert(ECWP_TABLE_BACKUP, [
            'file_name'   => $backup_filename,
            'backup_date' => current_time('mysql'),
            'checksum'    => $checksum,
        ]);
        $backup_id = (int) $wpdb->insert_id;

        // Auto-rotation: remove oldest backups beyond the retention limit
        $retention   = max(1, (int) get_option('ecwp_backup_retention', 10));
        $old_backups = $wpdb->get_results($wpdb->prepare(
            "SELECT id, file_name FROM " . ECWP_TABLE_BACKUP . " ORDER BY backup_date DESC LIMIT 9999 OFFSET %d",
            $retention
        ));
        foreach ($old_backups as $old) {
            $old_path = $backup_dir . basename($old->file_name);
            if (file_exists($old_path)) {
                @unlink($old_path);
            }
            $wpdb->delete(ECWP_TABLE_BACKUP, ['id' => (int) $old->id]);
        }

        $file_size = file_exists($backup_filepath) ? size_format(filesize($backup_filepath), 1) : '';
        do_action('ecwp_backup_done', $backup_filename, $file_size);

        return [
            'id'        => $backup_id,
            'filename'  => $backup_filename,
            'filepath'  => $backup_filepath,
            'file_size' => $file_size,
            'checksum'  => $checksum,
        ];
    }

    // =========================================================================
    // REST handlers — existing
    // =========================================================================

    public function backup_data($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $result = $this->do_backup_internal();

        if (is_wp_error($result)) {
            // Map internal error codes to HTTP status codes
            $http_map = [
                'disk_full'       => 507,
                'compress_error'  => 500,
                'file_write_error' => 500,
            ];
            $status = $http_map[$result->get_error_code()] ?? 500;
            return new \WP_Error(
                $result->get_error_code(),
                $result->get_error_message(),
                ['status' => $status]
            );
        }

        // Trigger notification for manual backup too
        $notify = new ECWPBackup_Notify();
        $cloud_provider = null;

        $cloud = \ECWP\Backup\Cloud\CloudManager::make();
        if ($cloud && isset($result['id'])) {
            $upload = $cloud->upload($result['filepath'], $result['filename'], $result['id']);
            if (!is_wp_error($upload)) {
                $cloud_provider = get_option('ecwp_backup_cloud_provider', 'none');
            }
        }

        $notify->send_success($result['filename'], $result['file_size'], $cloud_provider ?: null);

        return rest_ensure_response(['message' => __('Backup successfully created', 'my-easy-compta')]);
    }

    public function backup_list($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $backups = $wpdb->get_results("SELECT * FROM " . ECWP_TABLE_BACKUP . " ORDER BY backup_date DESC");

        $backup_dir = ECWP_BACKUP_PATH_DIR . '/backups/';
        $response   = [];
        foreach ($backups as $backup) {
            $file_path  = $backup_dir . $backup->file_name;
            $response[] = [
                'id'             => $backup->id,
                'file_name'      => $backup->file_name,
                'file_url'       => ECWP_BACKUP_URL . '/backups/' . $backup->file_name,
                'backup_date'    => $backup->backup_date,
                'file_size'      => file_exists($file_path) ? filesize($file_path) : 0,
                'cloud_provider' => $backup->cloud_provider ?? null,
                'cloud_path'     => $backup->cloud_path     ?? null,
                'cloud_uploaded' => isset($backup->cloud_uploaded) ? (bool) $backup->cloud_uploaded : false,
                'checksum'       => $backup->checksum ?? null,
            ];
        }

        return rest_ensure_response($response);
    }

    public function delete_backup($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        global $wpdb;

        $id           = absint($request->get_param('id'));
        $backup_table = ECWP_TABLE_BACKUP;
        $backup_dir   = ECWP_BACKUP_PATH_DIR . '/backups/';

        if (!$id) {
            return new \WP_REST_Response(['message' => 'Invalid backup ID'], 400);
        }

        $backup = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $backup_table WHERE id = %d",
            $id
        ));
        if (!$backup) {
            return new \WP_REST_Response(['message' => 'Backup not found'], 404);
        }

        $file_name = basename($backup->file_name);

        $deleted = $wpdb->delete($backup_table, ['id' => $id]);
        if ($deleted === false) {
            return new \WP_REST_Response(['message' => 'Failed to delete backup record from database'], 500);
        }

        $real_backup_dir = realpath($backup_dir);
        if ($real_backup_dir) {
            $normalized = $real_backup_dir . DIRECTORY_SEPARATOR . $file_name;
            if (file_exists($normalized)) {
                if (!unlink($normalized)) {
                    error_log('myEasyCompta Backup: could not unlink ' . $normalized);
                }
            }
        }

        do_action('ecwp_backup_deleted', $file_name, $id);

        return new \WP_REST_Response(['message' => 'Backup deleted successfully'], 200);
    }

    public function download_backup(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $file_name  = basename(sanitize_file_name($request->get_param('file')));
        $backup_dir = ECWP_BACKUP_PATH_DIR . '/backups/';
        $file_path  = $backup_dir . $file_name;

        $real_backup_dir = realpath($backup_dir);
        $real_file_path  = $real_backup_dir ? realpath($file_path) : false;
        if (
            !$real_file_path ||
            !$real_backup_dir ||
            strpos($real_file_path, $real_backup_dir . DIRECTORY_SEPARATOR) !== 0
        ) {
            return new \WP_Error('file_not_found', 'File not found', ['status' => 404]);
        }

        global $wpdb;
        $registered = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . ECWP_TABLE_BACKUP . " WHERE file_name = %s",
            $file_name
        ));
        if (!$registered) {
            return new \WP_Error('file_not_found', 'File not found', ['status' => 404]);
        }

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($real_file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($real_file_path));
        readfile($real_file_path);
        exit;
    }

    public function restore_backup(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $file_name   = basename(sanitize_file_name($request->get_param('file_name')));
        $backup_dir  = ECWP_BACKUP_PATH_DIR . '/backups/';
        $backup_path = $backup_dir . $file_name;

        $real_backup_dir  = realpath($backup_dir);
        $real_backup_path = $real_backup_dir ? realpath($backup_path) : false;
        if (
            !$real_backup_path ||
            !$real_backup_dir ||
            strpos($real_backup_path, $real_backup_dir . DIRECTORY_SEPARATOR) !== 0
        ) {
            return new \WP_Error('backup_file_not_found', __('Backup file not found', 'my-easy-compta'), ['status' => 404]);
        }

        global $wpdb;

        $registered = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . ECWP_TABLE_BACKUP . " WHERE file_name = %s",
            $file_name
        ));
        if (!$registered) {
            return new \WP_Error('backup_file_not_found', __('Backup file not found', 'my-easy-compta'), ['status' => 404]);
        }

        // Create a safety backup before restoring
        $safety = $this->do_backup_internal();
        if (is_wp_error($safety)) {
            return $safety;
        }

        $this->truncate_tables();

        // Support both plain .sql and compressed .sql.gz
        $raw = file_get_contents($real_backup_path);
        if ($raw === false) {
            return new \WP_Error('read_error', __('Failed to read backup file', 'my-easy-compta'), ['status' => 500]);
        }
        if (str_ends_with($file_name, '.gz')) {
            $raw = gzdecode($raw);
            if ($raw === false) {
                return new \WP_Error('decompress_error', __('Failed to decompress backup file', 'my-easy-compta'), ['status' => 500]);
            }
        }

        // Disable FK constraints during restore to avoid dependency ordering issues
        $wpdb->query('SET FOREIGN_KEY_CHECKS=0');

        $report        = [];
        $errors        = [];
        $current_table = null;

        // Split on statement boundaries: semicolons not inside quotes
        $queries = preg_split('/;\s*\n/', $raw);
        if (!$queries) $queries = explode(";\n", $raw);

        foreach ($queries as $query) {
            $query = trim($query);
            if (empty($query)) continue;

            if (preg_match('/^INSERT\s+(?:INTO\s+)?`?(\S+?)`?\s/i', $query, $m)) {
                $tbl = $m[1];
                if ($tbl !== $current_table) {
                    $current_table = $tbl;
                    if (!isset($report[$tbl])) {
                        $report[$tbl] = ['rows' => 0, 'errors' => 0];
                    }
                }
            }

            $result = $wpdb->query($query);
            if ($result === false) {
                if ($current_table) {
                    $report[$current_table]['errors']++;
                }
                $errors[] = $wpdb->last_error;
            } elseif ($current_table && preg_match('/^INSERT/i', $query)) {
                $report[$current_table]['rows'] += $wpdb->rows_affected;
            }
        }

        $wpdb->query('SET FOREIGN_KEY_CHECKS=1');

        $report_rows = [];
        foreach ($report as $tbl => $stats) {
            $report_rows[] = [
                'table'  => $tbl,
                'rows'   => $stats['rows'],
                'errors' => $stats['errors'],
                'status' => $stats['errors'] === 0 ? 'ok' : 'error',
            ];
        }

        return rest_ensure_response([
            'message' => 'Backup restored successfully',
            'report'  => $report_rows,
            'errors'  => array_slice(array_unique($errors), 0, 10),
        ]);
    }

    public function get_backup_settings(\WP_REST_Request $request)
    {
        return rest_ensure_response([
            'retention' => (int) get_option('ecwp_backup_retention', 10),
        ]);
    }

    public function save_backup_settings(\WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $retention = absint($request->get_param('retention'));
        if ($retention < 1)   $retention = 1;
        if ($retention > 100) $retention = 100;

        update_option('ecwp_backup_retention', $retention);

        return rest_ensure_response(['retention' => $retention]);
    }

    // =========================================================================
    // REST handlers — schedule
    // =========================================================================

    public function get_schedule(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        return rest_ensure_response([
            'enabled'   => get_option('ecwp_backup_schedule_enabled', '0'),
            'frequency' => get_option('ecwp_backup_schedule_frequency', 'daily'),
            'time'      => get_option('ecwp_backup_schedule_time', '03:00'),
            'next_run'  => ECWPBackup_Cron::get_next_run(),
        ]);
    }

    public function save_schedule(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $enabled   = $request->get_param('enabled')   === true || $request->get_param('enabled') === '1' ? '1' : '0';
        $frequency = sanitize_text_field($request->get_param('frequency') ?? 'daily');
        $time      = sanitize_text_field($request->get_param('time') ?? '03:00');

        // Validate frequency
        if (!in_array($frequency, ['daily', 'weekly', 'monthly', 'none'], true)) {
            $frequency = 'daily';
        }
        // Validate time format HH:MM
        if (!preg_match('/^\d{2}:\d{2}$/', $time)) {
            $time = '03:00';
        }

        update_option('ecwp_backup_schedule_enabled', $enabled);
        update_option('ecwp_backup_schedule_frequency', $frequency);
        update_option('ecwp_backup_schedule_time', $time);

        if ($enabled === '1') {
            ECWPBackup_Cron::schedule($frequency, $time);
        } else {
            ECWPBackup_Cron::unschedule();
        }

        return rest_ensure_response([
            'enabled'   => $enabled,
            'frequency' => $frequency,
            'time'      => $time,
            'next_run'  => ECWPBackup_Cron::get_next_run(),
        ]);
    }

    // =========================================================================
    // REST handlers — cloud configuration
    // =========================================================================

    public function get_cloud_config(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $provider = get_option('ecwp_backup_cloud_provider', 'none');

        $config = [
            'provider' => $provider,
            'ftp'      => [
                'host'    => get_option('ecwp_backup_ftp_host', ''),
                'port'    => (int) get_option('ecwp_backup_ftp_port', 21),
                'user'    => get_option('ecwp_backup_ftp_user', ''),
                'pass'    => '', // never expose stored password
                'path'    => get_option('ecwp_backup_ftp_path', '/backups'),
                'ssl'     => get_option('ecwp_backup_ftp_ssl', '0'),
                'passive' => get_option('ecwp_backup_ftp_passive', '1'),
            ],
            's3'       => [
                'access_key' => get_option('ecwp_backup_s3_access_key', ''),
                'secret_key' => '', // never expose
                'bucket'     => get_option('ecwp_backup_s3_bucket', ''),
                'region'     => get_option('ecwp_backup_s3_region', 'eu-west-3'),
                'prefix'     => get_option('ecwp_backup_s3_prefix', 'myeasycompta-backups'),
                'endpoint'   => get_option('ecwp_backup_s3_endpoint', ''),
            ],
            'dropbox'  => [
                'token' => '', // never expose
                'path'  => get_option('ecwp_backup_dropbox_path', '/myeasycompta-backups'),
            ],
        ];

        return rest_ensure_response($config);
    }

    public function save_cloud_config(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $provider = sanitize_text_field($request->get_param('provider') ?? 'none');
        if (!in_array($provider, ['none', 'ftp', 's3', 'dropbox'], true)) {
            $provider = 'none';
        }
        update_option('ecwp_backup_cloud_provider', $provider);

        // FTP settings
        if ($provider === 'ftp') {
            update_option('ecwp_backup_ftp_host',    sanitize_text_field($request->get_param('ftp_host')    ?? ''));
            update_option('ecwp_backup_ftp_port',    absint($request->get_param('ftp_port') ?? 21));
            update_option('ecwp_backup_ftp_user',    sanitize_text_field($request->get_param('ftp_user')    ?? ''));
            update_option('ecwp_backup_ftp_path',    sanitize_text_field($request->get_param('ftp_path')    ?? '/backups'));
            update_option('ecwp_backup_ftp_ssl',     $request->get_param('ftp_ssl')     ? '1' : '0');
            update_option('ecwp_backup_ftp_passive', $request->get_param('ftp_passive') ? '1' : '0');
            $pass = $request->get_param('ftp_pass');
            if (!empty($pass)) {
                update_option('ecwp_backup_ftp_pass', sanitize_text_field($pass));
            }
        }

        // S3 settings
        if ($provider === 's3') {
            update_option('ecwp_backup_s3_access_key', sanitize_text_field($request->get_param('s3_access_key') ?? ''));
            update_option('ecwp_backup_s3_bucket',     sanitize_text_field($request->get_param('s3_bucket')     ?? ''));
            update_option('ecwp_backup_s3_region',     sanitize_text_field($request->get_param('s3_region')     ?? 'eu-west-3'));
            update_option('ecwp_backup_s3_prefix',     sanitize_text_field($request->get_param('s3_prefix')     ?? 'myeasycompta-backups'));
            update_option('ecwp_backup_s3_endpoint',   esc_url_raw($request->get_param('s3_endpoint') ?? ''));
            $secret = $request->get_param('s3_secret_key');
            if (!empty($secret)) {
                update_option('ecwp_backup_s3_secret_key', sanitize_text_field($secret));
            }
        }

        // Dropbox settings
        if ($provider === 'dropbox') {
            update_option('ecwp_backup_dropbox_path', sanitize_text_field($request->get_param('dropbox_path') ?? '/myeasycompta-backups'));
            $token = $request->get_param('dropbox_token');
            if (!empty($token)) {
                update_option('ecwp_backup_dropbox_token', sanitize_text_field($token));
            }
        }

        return rest_ensure_response(['provider' => $provider]);
    }

    public function test_cloud(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $cloud = \ECWP\Backup\Cloud\CloudManager::make();
        if (!$cloud) {
            return new \WP_Error('cloud_disabled', __('Aucun fournisseur cloud configuré.', 'my-easy-compta'), ['status' => 400]);
        }

        $result = $cloud->test();
        if (is_wp_error($result)) {
            return new \WP_Error($result->get_error_code(), $result->get_error_message(), ['status' => 422]);
        }

        return rest_ensure_response(['success' => true, 'message' => __('Connexion réussie.', 'my-easy-compta')]);
    }

    public function cloud_upload_backup(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $id = absint($request->get_param('id'));
        if (!$id) {
            return new \WP_Error('invalid_id', __('ID de sauvegarde invalide.', 'my-easy-compta'), ['status' => 400]);
        }

        global $wpdb;
        $backup = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . ECWP_TABLE_BACKUP . " WHERE id = %d",
            $id
        ));
        if (!$backup) {
            return new \WP_Error('not_found', __('Sauvegarde introuvable.', 'my-easy-compta'), ['status' => 404]);
        }

        $backup_dir  = ECWP_BACKUP_PATH_DIR . '/backups/';
        $local_path  = $backup_dir . basename($backup->file_name);

        if (!file_exists($local_path)) {
            return new \WP_Error('file_missing', __('Le fichier de sauvegarde est introuvable sur le disque.', 'my-easy-compta'), ['status' => 404]);
        }

        $cloud = \ECWP\Backup\Cloud\CloudManager::make();
        if (!$cloud) {
            return new \WP_Error('cloud_disabled', __('Aucun fournisseur cloud configuré.', 'my-easy-compta'), ['status' => 400]);
        }

        $result = $cloud->upload($local_path, basename($backup->file_name), $id);
        if (is_wp_error($result)) {
            return new \WP_Error($result->get_error_code(), $result->get_error_message(), ['status' => 422]);
        }

        return rest_ensure_response([
            'success'  => true,
            'message'  => __('Sauvegarde envoyée vers le cloud avec succès.', 'my-easy-compta'),
            'provider' => get_option('ecwp_backup_cloud_provider', 'none'),
        ]);
    }

    // =========================================================================
    // REST handlers — notifications
    // =========================================================================

    public function get_notifications(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        return rest_ensure_response([
            'enabled'          => get_option('ecwp_backup_notify_enabled', '0'),
            'emails'           => get_option('ecwp_backup_notify_emails', get_option('admin_email', '')),
            'notify_on_success' => get_option('ecwp_backup_notify_on_success', '1'),
            'notify_on_failure' => get_option('ecwp_backup_notify_on_failure', '1'),
        ]);
    }

    public function save_notifications(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), ['status' => 403]);
        }

        $enabled           = $request->get_param('enabled')           === true || $request->get_param('enabled')           === '1' ? '1' : '0';
        $notify_on_success = $request->get_param('notify_on_success') === true || $request->get_param('notify_on_success') === '1' ? '1' : '0';
        $notify_on_failure = $request->get_param('notify_on_failure') === true || $request->get_param('notify_on_failure') === '1' ? '1' : '0';

        // Sanitize comma-separated email list
        $raw_emails = sanitize_text_field($request->get_param('emails') ?? '');
        $valid_emails = array_values(array_filter(
            array_map('trim', explode(',', $raw_emails)),
            'is_email'
        ));
        $emails_clean = implode(', ', $valid_emails);

        update_option('ecwp_backup_notify_enabled',          $enabled);
        update_option('ecwp_backup_notify_emails',           $emails_clean);
        update_option('ecwp_backup_notify_on_success',       $notify_on_success);
        update_option('ecwp_backup_notify_on_failure',       $notify_on_failure);

        return rest_ensure_response([
            'enabled'           => $enabled,
            'emails'            => $emails_clean,
            'notify_on_success' => $notify_on_success,
            'notify_on_failure' => $notify_on_failure,
        ]);
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    private function truncate_tables(): void
    {
        global $wpdb;

        // Exclude the backup metadata table itself from truncation.
        $tables = array_filter(
            $this->get_backup_tables(),
            fn($t) => $t !== ECWP_TABLE_BACKUP
        );

        $wpdb->query('SET FOREIGN_KEY_CHECKS = 0');
        foreach ($tables as $table) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $wpdb->query("TRUNCATE TABLE `{$table}`");
        }
        $wpdb->query('SET FOREIGN_KEY_CHECKS = 1');
    }
}
