<?php
namespace ECWP\Backup;

class ECWPBackup_Migrations
{
    public function plugin_activation(): void
    {
        $this->database_update();
        $this->create_backup_table();
        $this->maybe_upgrade();
    }

    public function database_update(): void
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            'easy_compta_backup_addon_active'
        ));
        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, [
                'meta_key'   => 'easy_compta_backup_addon_active',
                'meta_value' => 1,
            ]);
        }
    }

    public function plugin_desactivation(): void
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, ['meta_key' => 'easy_compta_backup_addon_active']);
        // Unschedule any pending cron jobs
        ECWPBackup_Cron::unschedule();
    }

    public function create_backup_table(): void
    {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS " . ECWP_TABLE_BACKUP . " (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            backup_date datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            file_name varchar(255) NOT NULL,
            cloud_provider varchar(50) DEFAULT NULL,
            cloud_path varchar(500) DEFAULT NULL,
            cloud_uploaded tinyint(1) NOT NULL DEFAULT 0,
            checksum varchar(64) DEFAULT NULL,
            PRIMARY KEY (id)
        ) $charset;";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Add new columns to existing installations that were created before v2.1.0.
     * Safe to call on every admin_init — each ALTER is skipped if the column already exists.
     */
    public function maybe_upgrade(): void
    {
        global $wpdb;
        $table = ECWP_TABLE_BACKUP;

        // Guard: table must exist before we try to DESCRIBE it
        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
            return;
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $cols = $wpdb->get_col("DESCRIBE `{$table}`");

        if (!in_array('cloud_provider', $cols, true)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `cloud_provider` varchar(50) DEFAULT NULL");
        }
        if (!in_array('cloud_path', $cols, true)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `cloud_path` varchar(500) DEFAULT NULL");
        }
        if (!in_array('cloud_uploaded', $cols, true)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `cloud_uploaded` tinyint(1) NOT NULL DEFAULT 0");
        }
        if (!in_array('checksum', $cols, true)) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `checksum` varchar(64) DEFAULT NULL");
        }
    }
}
