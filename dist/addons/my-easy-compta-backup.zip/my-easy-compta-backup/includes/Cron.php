<?php
namespace ECWP\Backup;

class ECWPBackup_Cron
{
    const HOOK = 'ecwp_scheduled_backup';

    public function __construct()
    {
        add_filter('cron_schedules', [$this, 'add_schedules']);
        add_action(self::HOOK, [$this, 'run_scheduled_backup']);
    }

    public function add_schedules(array $schedules): array
    {
        $schedules['ecwp_weekly']  = ['interval' => WEEK_IN_SECONDS,     'display' => 'Hebdomadaire (myEasyCompta)'];
        $schedules['ecwp_monthly'] = ['interval' => 30 * DAY_IN_SECONDS, 'display' => 'Mensuel (myEasyCompta)'];
        return $schedules;
    }

    public function run_scheduled_backup(): void
    {
        if (get_option('ecwp_backup_schedule_enabled') !== '1') return;

        $backup = new ECWPBackup_Backup();
        $result = $backup->do_backup_internal();

        $notify = new ECWPBackup_Notify();
        if (is_wp_error($result)) {
            $notify->send_failure($result->get_error_message());
        } else {
            $cloud_provider = null;
            $cloud = \ECWP\Backup\Cloud\CloudManager::make();
            if ($cloud && isset($result['id'])) {
                $upload_result = $cloud->upload($result['filepath'], $result['filename'], (int) $result['id']);
                if (!is_wp_error($upload_result)) {
                    $cloud_provider = get_option('ecwp_backup_cloud_provider', 'none');
                }
            }
            $notify->send_success($result['filename'], $result['file_size'], $cloud_provider ?: null);
        }
    }

    public static function schedule(string $frequency, string $time = '03:00'): void
    {
        self::unschedule();
        if ($frequency === 'none') return;

        $recurrence = match ($frequency) {
            'daily'   => 'daily',
            'weekly'  => 'ecwp_weekly',
            'monthly' => 'ecwp_monthly',
            default   => 'daily',
        };

        wp_schedule_event(self::next_run_timestamp($time), $recurrence, self::HOOK);
    }

    public static function unschedule(): void
    {
        $ts = wp_next_scheduled(self::HOOK);
        if ($ts) wp_unschedule_event($ts, self::HOOK);
    }

    private static function next_run_timestamp(string $time): int
    {
        [$h, $m] = array_pad(explode(':', $time), 2, '00');
        $tz   = wp_timezone();
        $now  = new \DateTime('now', $tz);
        $next = clone $now;
        $next->setTime((int) $h, (int) $m, 0);
        if ($next <= $now) $next->modify('+1 day');
        return $next->getTimestamp();
    }

    public static function get_next_run(): ?string
    {
        $ts = wp_next_scheduled(self::HOOK);
        return $ts ? wp_date('d/m/Y H:i', $ts) : null;
    }
}
