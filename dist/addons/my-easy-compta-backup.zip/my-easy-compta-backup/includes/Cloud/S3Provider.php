<?php
namespace ECWP\Backup\Cloud;

class S3Provider implements CloudProviderInterface
{
    private string $access_key;
    private string $secret_key;
    private string $bucket;
    private string $region;
    private string $prefix;
    private string $endpoint; // custom endpoint for S3-compatible (Wasabi, DO Spaces, etc.)

    public function __construct()
    {
        $this->access_key = (string) get_option('ecwp_backup_s3_access_key', '');
        $this->secret_key = (string) get_option('ecwp_backup_s3_secret_key', '');
        $this->bucket     = (string) get_option('ecwp_backup_s3_bucket', '');
        $this->region     = (string) get_option('ecwp_backup_s3_region', 'eu-west-3');
        $this->prefix     = trim((string) get_option('ecwp_backup_s3_prefix', 'myeasycompta-backups'), '/');
        $this->endpoint   = (string) get_option('ecwp_backup_s3_endpoint', '');
    }

    public function upload(string $local_path, string $filename, int $backup_id): true|\WP_Error
    {
        if (!file_exists($local_path)) {
            return new \WP_Error('file_missing', 'Le fichier de sauvegarde est introuvable.');
        }

        $object_key = ($this->prefix ? $this->prefix . '/' : '') . $filename;
        $file_body  = file_get_contents($local_path);
        if ($file_body === false) {
            return new \WP_Error('read_error', 'Impossible de lire le fichier de sauvegarde.');
        }

        $result = $this->put_object($object_key, $file_body, 'application/gzip');
        if (is_wp_error($result)) return $result;

        global $wpdb;
        $wpdb->update(
            ECWP_TABLE_BACKUP,
            [
                'cloud_provider' => 's3',
                'cloud_path'     => "s3://{$this->bucket}/{$object_key}",
                'cloud_uploaded' => 1,
            ],
            ['id' => $backup_id]
        );

        return true;
    }

    public function test(): true|\WP_Error
    {
        return $this->head_bucket();
    }

    private function head_bucket(): true|\WP_Error
    {
        if (empty($this->access_key) || empty($this->secret_key) || empty($this->bucket)) {
            return new \WP_Error('s3_config', 'Configuration S3 incomplète (clé, secret ou bucket manquant).');
        }

        $host     = $this->bucket . '.s3.' . $this->region . '.amazonaws.com';
        $url      = 'https://' . $host . '/';
        $now      = new \DateTime('now', new \DateTimeZone('UTC'));
        $date     = $now->format('Ymd');
        $datetime = $now->format('Ymd\THis\Z');

        $body_hash = hash('sha256', '');
        $signed    = $this->sign_request('HEAD', $host, '/', '', $date, $datetime, $body_hash, '');
        if (is_wp_error($signed)) return $signed;

        $response = wp_remote_head($url, [
            'headers' => $signed['headers'],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200 || $code === 403) {
            // 403 = credentials work but no list perm — acceptable for upload-only use
            return true;
        }

        return new \WP_Error(
            's3_error',
            'Erreur S3 code ' . $code . ': ' . wp_remote_retrieve_body($response)
        );
    }

    private function put_object(string $key, string $body, string $content_type): true|\WP_Error
    {
        $host = $this->endpoint
            ? (string) parse_url($this->endpoint, PHP_URL_HOST)
            : $this->bucket . '.s3.' . $this->region . '.amazonaws.com';

        $base_url = $this->endpoint ?: 'https://' . $host;
        $url      = rtrim($base_url, '/') . '/' . ltrim($key, '/');

        $now       = new \DateTime('now', new \DateTimeZone('UTC'));
        $date      = $now->format('Ymd');
        $datetime  = $now->format('Ymd\THis\Z');
        $body_hash = hash('sha256', $body);

        $signed = $this->sign_request('PUT', $host, '/' . ltrim($key, '/'), $body, $date, $datetime, $body_hash, $content_type);
        if (is_wp_error($signed)) return $signed;

        $response = wp_remote_request($url, [
            'method'  => 'PUT',
            'body'    => $body,
            'headers' => array_merge($signed['headers'], [
                'Content-Type'   => $content_type,
                'Content-Length' => strlen($body),
            ]),
            'timeout' => 120,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) return true;

        return new \WP_Error(
            's3_upload',
            'Erreur S3 upload (' . $code . '): ' . wp_remote_retrieve_body($response)
        );
    }

    /**
     * Build AWS Signature Version 4 headers for a request.
     *
     * @return array{headers: array<string,string>}|\WP_Error
     */
    private function sign_request(
        string $method,
        string $host,
        string $path,
        string $body,
        string $date,
        string $datetime,
        string $body_hash,
        string $content_type
    ): array|\WP_Error {
        if (empty($this->access_key) || empty($this->secret_key)) {
            return new \WP_Error('s3_config', 'Clé d\'accès S3 manquante.');
        }

        if (!$body_hash) {
            $body_hash = hash('sha256', $body);
        }

        $canonical_headers = implode("\n", [
            'host:' . $host,
            'x-amz-content-sha256:' . $body_hash,
            'x-amz-date:' . $datetime,
        ]) . "\n";

        $signed_headers = 'host;x-amz-content-sha256;x-amz-date';

        $canonical_request = implode("\n", [
            $method,
            $path,
            '', // query string
            $canonical_headers,
            $signed_headers,
            $body_hash,
        ]);

        $credential_scope = $date . '/' . $this->region . '/s3/aws4_request';
        $string_to_sign   = implode("\n", [
            'AWS4-HMAC-SHA256',
            $datetime,
            $credential_scope,
            hash('sha256', $canonical_request),
        ]);

        $signing_key  = $this->derive_key($date);
        $signature    = hash_hmac('sha256', $string_to_sign, $signing_key);
        $authorization = sprintf(
            'AWS4-HMAC-SHA256 Credential=%s/%s,SignedHeaders=%s,Signature=%s',
            $this->access_key,
            $credential_scope,
            $signed_headers,
            $signature
        );

        return [
            'headers' => [
                'Host'                 => $host,
                'x-amz-date'           => $datetime,
                'x-amz-content-sha256' => $body_hash,
                'Authorization'        => $authorization,
            ],
        ];
    }

    private function derive_key(string $date): string
    {
        $k_date    = hash_hmac('sha256', $date,           'AWS4' . $this->secret_key, true);
        $k_region  = hash_hmac('sha256', $this->region,   $k_date,                   true);
        $k_service = hash_hmac('sha256', 's3',            $k_region,                 true);
        return       hash_hmac('sha256', 'aws4_request',  $k_service,                true);
    }
}
