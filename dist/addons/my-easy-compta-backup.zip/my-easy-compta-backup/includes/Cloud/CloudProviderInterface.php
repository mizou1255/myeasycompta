<?php
namespace ECWP\Backup\Cloud;

interface CloudProviderInterface
{
    /**
     * Upload a local file to the cloud.
     *
     * @param string $local_path  Absolute path to the local file.
     * @param string $filename    Remote filename to use.
     * @param int    $backup_id   DB row ID to update after upload.
     * @return true|\WP_Error
     */
    public function upload(string $local_path, string $filename, int $backup_id): true|\WP_Error;

    /**
     * Test the connection with current settings.
     *
     * @return true|\WP_Error
     */
    public function test(): true|\WP_Error;
}
