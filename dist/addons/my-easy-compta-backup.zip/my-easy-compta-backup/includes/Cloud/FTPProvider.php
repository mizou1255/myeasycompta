<?php
namespace ECWP\Backup\Cloud;

class FTPProvider implements CloudProviderInterface
{
    private string $host;
    private int    $port;
    private string $user;
    private string $pass;
    private string $path;
    private bool   $ssl;
    private bool   $passive;

    public function __construct()
    {
        $this->host    = (string) get_option('ecwp_backup_ftp_host', '');
        $this->port    = (int)    get_option('ecwp_backup_ftp_port', 21);
        $this->user    = (string) get_option('ecwp_backup_ftp_user', '');
        $this->pass    = (string) get_option('ecwp_backup_ftp_pass', '');
        $this->path    = rtrim((string) get_option('ecwp_backup_ftp_path', '/backups'), '/');
        $this->ssl     = get_option('ecwp_backup_ftp_ssl', '0') === '1';
        $this->passive = get_option('ecwp_backup_ftp_passive', '1') === '1';
    }

    public function upload(string $local_path, string $filename, int $backup_id): true|\WP_Error
    {
        if (!function_exists('ftp_connect')) {
            return new \WP_Error('ftp_unavailable', 'L\'extension PHP FTP n\'est pas disponible.');
        }

        $conn = $this->ssl
            ? @ftp_ssl_connect($this->host, $this->port, 15)
            : @ftp_connect($this->host, $this->port, 15);

        if (!$conn) {
            return new \WP_Error('ftp_connect', 'Impossible de se connecter au serveur FTP.');
        }

        if (!@ftp_login($conn, $this->user, $this->pass)) {
            ftp_close($conn);
            return new \WP_Error('ftp_login', 'Identifiants FTP invalides.');
        }

        if ($this->passive) {
            ftp_pasv($conn, true);
        }

        // Ensure remote directory exists
        $dirs    = explode('/', ltrim($this->path, '/'));
        $current = '';
        foreach ($dirs as $dir) {
            if ($dir === '') continue;
            $current .= '/' . $dir;
            if (!@ftp_chdir($conn, $current)) {
                @ftp_mkdir($conn, $current);
                @ftp_chdir($conn, $current);
            }
        }

        $remote = $this->path . '/' . $filename;
        $ok     = @ftp_put($conn, $remote, $local_path, FTP_BINARY);
        ftp_close($conn);

        if (!$ok) {
            return new \WP_Error('ftp_upload', 'Échec du transfert FTP.');
        }

        global $wpdb;
        $wpdb->update(
            ECWP_TABLE_BACKUP,
            [
                'cloud_provider' => 'ftp',
                'cloud_path'     => $remote,
                'cloud_uploaded' => 1,
            ],
            ['id' => $backup_id]
        );

        return true;
    }

    public function test(): true|\WP_Error
    {
        if (!function_exists('ftp_connect')) {
            return new \WP_Error('ftp_unavailable', 'L\'extension PHP FTP n\'est pas disponible.');
        }

        $conn = $this->ssl
            ? @ftp_ssl_connect($this->host, $this->port, 10)
            : @ftp_connect($this->host, $this->port, 10);

        if (!$conn) {
            return new \WP_Error('ftp_connect', 'Impossible de se connecter au serveur FTP.');
        }

        $ok = @ftp_login($conn, $this->user, $this->pass);
        ftp_close($conn);

        return $ok ? true : new \WP_Error('ftp_login', 'Identifiants FTP invalides.');
    }
}
