<?php
namespace ECWP\Backup\Cloud;

class DropboxProvider implements CloudProviderInterface
{
    private string $token;
    private string $path;

    public function __construct()
    {
        $this->token = (string) get_option('ecwp_backup_dropbox_token', '');
        $this->path  = rtrim((string) get_option('ecwp_backup_dropbox_path', '/myeasycompta-backups'), '/');
    }

    public function upload(string $local_path, string $filename, int $backup_id): true|\WP_Error
    {
        if (empty($this->token)) {
            return new \WP_Error('dropbox_config', 'Token Dropbox manquant.');
        }
        if (!file_exists($local_path)) {
            return new \WP_Error('file_missing', 'Fichier introuvable.');
        }

        $remote_path = $this->path . '/' . $filename;
        $file_body   = file_get_contents($local_path);
        if ($file_body === false) {
            return new \WP_Error('read_error', 'Impossible de lire le fichier.');
        }

        $response = wp_remote_post('https://content.dropboxapi.com/2/files/upload', [
            'headers' => [
                'Authorization'   => 'Bearer ' . $this->token,
                'Content-Type'    => 'application/octet-stream',
                'Dropbox-API-Arg' => wp_json_encode([
                    'path'       => $remote_path,
                    'mode'       => 'overwrite',
                    'autorename' => false,
                    'mute'       => true,
                ]),
            ],
            'body'    => $file_body,
            'timeout' => 120,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            global $wpdb;
            $wpdb->update(
                ECWP_TABLE_BACKUP,
                [
                    'cloud_provider' => 'dropbox',
                    'cloud_path'     => $remote_path,
                    'cloud_uploaded' => 1,
                ],
                ['id' => $backup_id]
            );
            return true;
        }

        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        $msg  = $json['error_summary'] ?? ('Erreur Dropbox code ' . $code);
        return new \WP_Error('dropbox_upload', $msg);
    }

    public function test(): true|\WP_Error
    {
        if (empty($this->token)) {
            return new \WP_Error('dropbox_config', 'Token Dropbox manquant.');
        }

        $response = wp_remote_post('https://api.dropboxapi.com/2/users/get_current_account', [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->token,
                'Content-Type'  => 'application/json',
            ],
            'body'    => 'null',
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) return true;

        return new \WP_Error('dropbox_auth', 'Token Dropbox invalide (code ' . $code . ').');
    }
}
