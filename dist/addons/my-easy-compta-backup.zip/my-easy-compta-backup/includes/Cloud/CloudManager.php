<?php
namespace ECWP\Backup\Cloud;

class CloudManager
{
    /**
     * Factory: returns the configured provider or null if cloud is disabled.
     */
    public static function make(): ?CloudProviderInterface
    {
        $provider = get_option('ecwp_backup_cloud_provider', 'none');

        return match ($provider) {
            'ftp'     => new FTPProvider(),
            's3'      => new S3Provider(),
            'dropbox' => new DropboxProvider(),
            default   => null,
        };
    }
}
