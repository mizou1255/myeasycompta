<?php
namespace ECWP\Backup;

class ECWPBackup_Notify
{
    public function send_success(string $filename, string $file_size, ?string $cloud_provider = null): void
    {
        if (get_option('ecwp_backup_notify_on_success') !== '1') return;
        $emails = $this->get_recipients();
        if (empty($emails)) return;

        $site    = get_bloginfo('name');
        $date    = wp_date('d/m/Y H:i');
        $subject = sprintf('✅ [%s] Sauvegarde réussie — %s', $site, $date);

        $cloud_line = $cloud_provider
            ? sprintf(
                '<tr><td style="color:#6b7280;padding:8px 0;font-size:13px;">☁️ Cloud</td><td style="font-weight:700;color:#059669;font-size:13px;">Envoyé sur %s</td></tr>',
                esc_html(ucfirst($cloud_provider))
            )
            : '';

        $site_esc     = esc_html($site);
        $date_esc     = esc_html($date);
        $filename_esc = esc_html($filename);
        $filesize_esc = esc_html($file_size);

        $body = <<<HTML
<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:520px;margin:0 auto;background:#f8fafc;padding:32px;border-radius:16px;">
  <div style="background:linear-gradient(135deg,#7c3aed,#4f46e5);padding:24px;border-radius:12px;margin-bottom:24px;text-align:center;">
    <h1 style="color:white;margin:0;font-size:22px;font-weight:900;">✅ Sauvegarde réussie</h1>
  </div>
  <p style="color:#374151;font-size:15px;">Une sauvegarde de <strong>{$site_esc}</strong> a été effectuée avec succès.</p>
  <table style="width:100%;background:white;border-radius:12px;padding:16px;border:1px solid #e5e7eb;border-collapse:collapse;">
    <tr><td style="color:#6b7280;padding:8px 0;font-size:13px;">📅 Date</td><td style="font-weight:700;color:#111827;font-size:13px;">{$date_esc}</td></tr>
    <tr><td style="color:#6b7280;padding:8px 0;font-size:13px;">📁 Fichier</td><td style="font-weight:700;color:#111827;font-size:13px;">{$filename_esc}</td></tr>
    <tr><td style="color:#6b7280;padding:8px 0;font-size:13px;">⚖️ Taille</td><td style="font-weight:700;color:#111827;font-size:13px;">{$filesize_esc}</td></tr>
    {$cloud_line}
  </table>
  <p style="color:#9ca3af;font-size:12px;margin-top:24px;text-align:center;">myEasyCompta Backup · Notification automatique</p>
</div>
HTML;

        $headers = ['Content-Type: text/html; charset=UTF-8'];
        foreach ($emails as $email) {
            wp_mail($email, $subject, $body, $headers);
        }
    }

    public function send_failure(string $error): void
    {
        if (get_option('ecwp_backup_notify_on_failure') !== '1') return;
        $emails = $this->get_recipients();
        if (empty($emails)) return;

        $site    = get_bloginfo('name');
        $date    = wp_date('d/m/Y H:i');
        $subject = sprintf('❌ [%s] Échec de sauvegarde — %s', $site, $date);

        $site_esc  = esc_html($site);
        $date_esc  = esc_html($date);
        $error_esc = esc_html($error);

        $body = <<<HTML
<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;max-width:520px;margin:0 auto;background:#f8fafc;padding:32px;border-radius:16px;">
  <div style="background:linear-gradient(135deg,#dc2626,#b91c1c);padding:24px;border-radius:12px;margin-bottom:24px;text-align:center;">
    <h1 style="color:white;margin:0;font-size:22px;font-weight:900;">❌ Échec de sauvegarde</h1>
  </div>
  <p style="color:#374151;font-size:15px;">La sauvegarde automatique de <strong>{$site_esc}</strong> a échoué le <strong>{$date_esc}</strong>.</p>
  <div style="background:#fee2e2;border:1px solid #fca5a5;border-radius:8px;padding:14px;margin:16px 0;">
    <p style="color:#991b1b;margin:0;font-size:13px;font-weight:600;">Erreur : {$error_esc}</p>
  </div>
  <p style="color:#6b7280;font-size:13px;">Connectez-vous à votre espace myEasyCompta pour relancer la sauvegarde manuellement.</p>
  <p style="color:#9ca3af;font-size:12px;margin-top:24px;text-align:center;">myEasyCompta Backup · Notification automatique</p>
</div>
HTML;

        $headers = ['Content-Type: text/html; charset=UTF-8'];
        foreach ($emails as $email) {
            wp_mail($email, $subject, $body, $headers);
        }
    }

    private function get_recipients(): array
    {
        if (get_option('ecwp_backup_notify_enabled') !== '1') return [];
        $raw = get_option('ecwp_backup_notify_emails', get_option('admin_email', ''));
        return array_values(array_filter(array_map('trim', explode(',', $raw)), 'is_email'));
    }
}
