<?php

namespace ECWP\Advance;

use ECWP\Admin\Settings\ECWP_Settings;
use ECWP\API\Routes;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

class ECWPAdvance_APP
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    /**
     * @return [type]
     */
    public function register_api_routes()
    {
        $this->routes->add_route('quotes/convert-advance/(?P<id>\d+)', 'POST', $this, 'convert_quote_to_advance_invoice', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('advance/(?P<id>\d+)', 'GET', $this, 'get_advance_invoices_by_quote_id', function () {
            return current_user_can('manage_options');
        });

        // Paiements partiels (feature Advance)
        $this->routes->add_route('invoices/(?P<id>\d+)/payments', 'GET', $this, 'get_invoice_payments', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('invoices/(?P<id>\d+)/add-payment', 'POST', $this, 'add_invoice_payment', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('invoices/(?P<id>\d+)/payments/(?P<payment_id>\d+)', 'DELETE', $this, 'delete_invoice_payment', function () {
            return current_user_can('manage_options');
        });

        $this->routes->register_routes();
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    function convert_quote_to_advance_invoice($request)
    {
        if (!$this->has_valid_license()) {
            return new \WP_REST_Response(array('message' => 'License required'), 403);
        }

        global $wpdb;
        $quote_id = absint($request['id']);
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));

        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $quote = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM %i WHERE id = %d", ECWP_TABLE_QUOTES, $quote_id),
            ARRAY_A
        );

        if (!$quote) {
            return new WP_Error('quote_not_found', __('Quote not found', 'my-easy-compta'), array('status' => 404));
        }

        $advance_type = sanitize_text_field($request['advance_type']);
        $advance_value = floatval($request['advance_value']);
        $advance_date = sanitize_text_field($request['advance_date']);

        $quote_total = floatval($quote['total_amount']); // quote fields stored plain, no decrypt needed
        $calculated_amount = 0;
        $amount_percent = 0;

        if ($advance_value <= 0) {
            return new WP_Error('invalid_advance_value', __('Le montant de l\'acompte doit être supérieur à zéro.', 'my-easy-compta'), array('status' => 400));
        }

        if ($advance_type === 'percentage') {
            if ($advance_value > 100) {
                return new WP_Error('invalid_advance_value', __('Le pourcentage de l\'acompte ne peut pas dépasser 100%.', 'my-easy-compta'), array('status' => 400));
            }
            $calculated_amount = ($advance_value / 100) * $quote_total;
            $amount_percent = $advance_value;
        } elseif ($advance_type === 'fixed') {
            if ($advance_value > $quote_total) {
                return new WP_Error('invalid_advance_value', __('Le montant de l\'acompte ne peut pas dépasser le total du devis.', 'my-easy-compta'), array('status' => 400));
            }
            $calculated_amount = $advance_value;
        } else {
            return new WP_Error('invalid_advance_type', __('Type d\'acompte invalide.', 'my-easy-compta'), array('status' => 400));
        }

        // Pre-fetch quote items and compute VAT groups before any DB writes
        $quote_items = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM " . ECWP_TABLE_QUOTE_ELEMENTS . " WHERE quote_id = %d", $quote_id),
            ARRAY_A
        );

        $grouped_items = [];
        $items_total_ttc = 0;

        foreach ($quote_items as $item) {
            $vat_rate = $item['vat_rate'];
            $item_ttc = floatval($item['total_amount']); // quote_elements fields are stored plain

            if (!isset($grouped_items[$vat_rate])) {
                $grouped_items[$vat_rate] = 0;
            }
            $grouped_items[$vat_rate] += $item_ttc;
            $items_total_ttc += $item_ttc;
        }

        if ($items_total_ttc <= 0) {
            return new WP_Error('no_items', __('Le devis ne contient aucun article.', 'my-easy-compta'), array('status' => 400));
        }

        $settings = new ECWP_Settings();
        $invoice_prefix = $settings->get_setting('invoice_prefix');

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        // Compute HT amount of the advance for the invoice `amount` field
        $advance_ht = 0;
        foreach ($grouped_items as $vat_rate => $group_total) {
            $group_advance = ($advance_type === 'percentage')
                ? ($advance_value / 100) * $group_total
                : ($group_total / $items_total_ttc) * $advance_value;
            $vat_rate_decimal = $vat_rate / 100;
            $advance_ht += $group_advance / (1 + $vat_rate_decimal);
        }

        $wpdb->query('START TRANSACTION');

        // Lock invoice number counter to prevent concurrent duplicates
        $last_invoice_id = (int) $wpdb->get_var("SELECT MAX(number) FROM " . ECWP_TABLE_INVOICES . " FOR UPDATE");
        $padded_invoice_id = str_pad($last_invoice_id + 1, 4, "0", STR_PAD_LEFT);

        $invoice_data = array(
            'number' => $last_invoice_id + 1,
            'invoice_number' => $encrypt->encrypt($invoice_prefix . '-' . $padded_invoice_id),
            'client_id' => $quote['client_id'],
            'amount' => $encrypt->encrypt($advance_ht),
            'total_amount' => $encrypt->encrypt($calculated_amount),
            'due_date' => $advance_date,
            'status' => $encrypt->encrypt('unpaid'),
            'status_stats' => 'unpaid',
            'created_at' => current_time('mysql'),
            'advance' => 1,
            'advance_amount' => $encrypt->encrypt($calculated_amount),
            'advance_percent' => $amount_percent,
            'quote_id' => $quote_id,
        );

        $wpdb->insert(ECWP_TABLE_INVOICES, $invoice_data);
        $invoice_id = $wpdb->insert_id;

        if (!$invoice_id) {
            $wpdb->query('ROLLBACK');
            return new \WP_Error('invoice_creation_failed', __('Failed to create invoice', 'my-easy-compta'), array('status' => 500));
        }

        $quote_number = $quote['quote_number']; // quote_number is stored plain (not encrypted)
        $item_order = 1;
        foreach ($grouped_items as $vat_rate => $group_total) {
            if ($advance_type === 'percentage') {
                $item_advance = ($advance_value / 100) * $group_total;
                $item_name = $encrypt->encrypt("Acompte de {$advance_value}% du devis #{$quote_number} sur un total de {$items_total_ttc}");
            } else {
                $item_advance = ($group_total / $items_total_ttc) * $advance_value;
                $item_name = $encrypt->encrypt("Acompte de " . number_format($item_advance, 2, '.', '') . " sur le devis {$quote_number} sur un total de {$items_total_ttc}");
            }

            $vat_rate_decimal = $vat_rate / 100;
            $price_ht = $item_advance / (1 + $vat_rate_decimal);

            $item_description = $encrypt->encrypt("Cet élément représente un acompte sur le devis #{$quote_number} avec un taux de TVA de {$vat_rate}%.");

            $item_data = array(
                'invoice_id'       => $invoice_id,
                'item_name'        => $item_name,
                'item_ref'         => $encrypt->encrypt('AC'),
                'item_description' => $item_description,
                'item_category'    => '',
                'quantity'         => $encrypt->encrypt(1),
                'vat_rate'         => $encrypt->encrypt($vat_rate),
                'unit_price'       => $encrypt->encrypt($price_ht),
                'discount'         => $encrypt->encrypt(0),
                'total_price'      => $encrypt->encrypt($price_ht),
                'total_amount'     => $encrypt->encrypt($item_advance),
                'item_order'       => $item_order++,
            );

            if ($wpdb->insert(ECWP_TABLE_INVOICE_ELEMENTS, $item_data) === false) {
                $wpdb->query('ROLLBACK');
                return new \WP_Error('item_insert_failed', __('Erreur lors de la création des lignes de la facture d\'acompte.', 'my-easy-compta'), array('status' => 500));
            }
        }

        $wpdb->update(
            ECWP_TABLE_QUOTES,
            array('advance' => 1),
            array('id' => $quote_id),
            array('%d'),
            array('%d')
        );

        $wpdb->query('COMMIT');

        return new WP_REST_Response(array('success' => true, 'message' => __('Quote converted to advance invoice successfully', 'my-easy-compta'), 'id' => $invoice_id), 200);
    }

    function get_advance_invoices_by_quote_id(WP_REST_Request $request)
    {
        if (!$this->has_valid_license()) {
            return new \WP_REST_Response(array('message' => 'License required'), 403);
        }

        global $wpdb;

        $quote_id = absint($request->get_param('id'));
        if (!$quote_id) {
            return new WP_Error('invalid_quote_id', __('Invalid Quote ID', 'my-easy-compta'), array('status' => 400));
        }

        $advance_invoices = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, advance_amount, created_at FROM %i WHERE advance = 1 AND quote_id = %d",
                ECWP_TABLE_INVOICES,
                $quote_id
            ),
            ARRAY_A
        );

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
        foreach ($advance_invoices as &$item) {
            $item['advance_amount'] = $encrypt->decrypt($item['advance_amount']);
        }

        if (empty($advance_invoices)) {
            return new WP_REST_Response(array(), 200);
        }

        return new WP_REST_Response($advance_invoices, 200);
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private function get_date_format(): string
    {
        global $wpdb;
        $map = [
            'DD-MM-YYYY' => 'd-m-Y', 'MM-DD-YYYY' => 'm-d-Y', 'YYYY-MM-DD' => 'Y-m-d',
            'YYYY/MM/DD' => 'Y/m/d', 'DD/MM/YYYY' => 'd/m/Y', 'MM/DD/YYYY' => 'm/d/Y',
            'YYYY.MM.DD' => 'Y.m.d', 'DD.MM.YYYY' => 'd.m.Y', 'MM.DD.YYYY' => 'm.d.Y',
        ];
        $raw = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            'date_format'
        ));
        return $map[$raw] ?? 'Y-m-d';
    }

    // ── Paiements partiels ──────────────────────────────────────────────────────

    /**
     * Retourne tous les paiements d'une facture + résumé (total / payé / restant).
     */
    public function get_invoice_payments(WP_REST_Request $request)
    {
        global $wpdb;
        $invoice_id = absint($request->get_param('id'));

        if ($invoice_id <= 0) {
            return new WP_Error('invalid_id', 'ID de facture invalide.', ['status' => 400]);
        }

        $encrypt  = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
        $fmt_date = $this->get_date_format();

        $pt = ECWP_TABLE_PAYMENTS;
        $mt = ECWP_TABLE_PAYMENTS_METHODS;
        $it = ECWP_TABLE_INVOICES;

        $payments = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT p.id, p.amount, p.payment_date, p.notes, p.payment_method_id, m.method_name
                 FROM {$pt} p
                 LEFT JOIN {$mt} m ON p.payment_method_id = m.id
                 WHERE p.invoice_id = %d
                 ORDER BY p.payment_date ASC, p.id ASC",
                $invoice_id
            ),
            ARRAY_A
        );

        $invoice = $wpdb->get_row(
            $wpdb->prepare("SELECT total_amount, paid_amount, status_stats FROM {$it} WHERE id = %d", $invoice_id)
        );

        $total_amount = $invoice ? (float) $encrypt->decrypt($invoice->total_amount) : 0.0;
        $paid_amount  = $invoice ? (float) $invoice->paid_amount : 0.0;
        $remaining    = max(0.0, $total_amount - $paid_amount);

        $formatted = array_map(function ($p) use ($fmt_date) {
            return [
                'id'                => (int) $p['id'],
                'amount'            => number_format((float) $p['amount'], 2, '.', ''),
                'payment_method'    => $p['method_name'] ?? '',
                'payment_method_id' => (int) $p['payment_method_id'],
                'payment_date'      => date_i18n($fmt_date, strtotime($p['payment_date'])),
                'payment_date_raw'  => $p['payment_date'],
                'notes'             => $p['notes'] ?? '',
            ];
        }, $payments ?: []);

        return rest_ensure_response([
            'success'          => true,
            'data'             => [
                'payments'         => $formatted,
                'total_amount'     => number_format($total_amount, 2, '.', ''),
                'paid_amount'      => number_format($paid_amount, 2, '.', ''),
                'remaining_amount' => number_format($remaining, 2, '.', ''),
                'status'           => $invoice->status_stats ?? 'unpaid',
            ],
        ]);
    }

    /**
     * Ajoute un paiement partiel à une facture.
     */
    public function add_invoice_payment(WP_REST_Request $request)
    {
        if (!$this->has_valid_license()) {
            return new WP_REST_Response(['message' => 'License required'], 403);
        }

        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', 'Nonce verification failed.', ['status' => 403]);
        }

        global $wpdb;
        $invoice_id        = absint($request->get_param('id'));
        $amount            = (float) $request->get_param('amount');
        $payment_method_id = absint($request->get_param('payment_method_id'));
        $payment_date      = sanitize_text_field($request->get_param('payment_date') ?: wp_date('Y-m-d'));
        $notes             = sanitize_textarea_field($request->get_param('notes') ?? '');

        if ($amount <= 0) {
            return new WP_Error('invalid_amount', 'Le montant doit être supérieur à zéro.', ['status' => 422]);
        }

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
        $it      = ECWP_TABLE_INVOICES;

        $invoice = $wpdb->get_row(
            $wpdb->prepare("SELECT id, client_id, total_amount, paid_amount, status_stats FROM {$it} WHERE id = %d", $invoice_id)
        );

        if (!$invoice) {
            return new WP_Error('not_found', 'Facture introuvable.', ['status' => 404]);
        }

        if ($invoice->status_stats === 'draft') {
            return new WP_Error('draft_invoice', 'Impossible d\'ajouter un paiement sur un brouillon.', ['status' => 422]);
        }

        $total_amount = (float) $encrypt->decrypt($invoice->total_amount);
        $current_paid = (float) $invoice->paid_amount;
        $remaining    = $total_amount - $current_paid;

        if ($amount > $remaining + 0.005) {
            return new WP_Error(
                'exceeds_balance',
                sprintf('Le montant (%.2f) dépasse le solde restant (%.2f).', $amount, $remaining),
                ['status' => 422]
            );
        }

        $inserted = $wpdb->insert(
            ECWP_TABLE_PAYMENTS,
            [
                'invoice_id'        => $invoice_id,
                'client_id'         => (int) $invoice->client_id,
                'amount'            => $amount,
                'payment_method_id' => $payment_method_id,
                'payment_date'      => $payment_date,
                'notes'             => $notes,
            ],
            ['%d', '%d', '%f', '%d', '%s', '%s']
        );

        if (!$inserted) {
            return new WP_Error('db_error', 'Erreur lors de l\'insertion du paiement.', ['status' => 500]);
        }

        $payment_id = $wpdb->insert_id;
        $this->sync_invoice_paid_amount($invoice_id);

        do_action('ecwp_payment_added', $payment_id, $invoice_id, $amount);

        return new WP_REST_Response([
            'success'    => true,
            'message'    => __('Paiement ajouté avec succès.', 'my-easy-compta'),
            'payment_id' => $payment_id,
        ], 201);
    }

    /**
     * Supprime un paiement lié à une facture spécifique et resynchronise.
     */
    public function delete_invoice_payment(WP_REST_Request $request)
    {
        if (!$this->has_valid_license()) {
            return new WP_REST_Response(['message' => 'License required'], 403);
        }

        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('invalid_nonce', 'Nonce verification failed.', ['status' => 403]);
        }

        global $wpdb;
        $invoice_id = absint($request->get_param('id'));
        $payment_id = absint($request->get_param('payment_id'));

        $belongs = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM " . ECWP_TABLE_PAYMENTS . " WHERE id = %d AND invoice_id = %d",
                $payment_id,
                $invoice_id
            )
        );

        if (!$belongs) {
            return new WP_Error('not_found', 'Paiement introuvable pour cette facture.', ['status' => 404]);
        }

        $result = $wpdb->delete(ECWP_TABLE_PAYMENTS, ['id' => $payment_id], ['%d']);

        if ($result) {
            $this->sync_invoice_paid_amount($invoice_id);
            return new WP_REST_Response(['success' => true, 'message' => 'Paiement supprimé.'], 200);
        }

        return new WP_REST_Response(['success' => false, 'message' => 'Échec de la suppression.'], 500);
    }

    /**
     * Recalcule paid_amount et met à jour le statut d'une facture.
     * Statuts : unpaid | partial | paid
     */
    private function sync_invoice_paid_amount(int $invoice_id): void
    {
        global $wpdb;

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        $paid_amount = (float) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(amount), 0) FROM " . ECWP_TABLE_PAYMENTS . " WHERE invoice_id = %d",
                $invoice_id
            )
        );

        $invoice = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT total_amount, status_stats FROM " . ECWP_TABLE_INVOICES . " WHERE id = %d",
                $invoice_id
            )
        );

        if (!$invoice) {
            return;
        }

        $old_status   = $invoice->status_stats ?? 'unpaid';
        $total_amount = (float) $encrypt->decrypt($invoice->total_amount);

        if ($paid_amount <= 0.005) {
            $new_status  = 'unpaid';
            $paid_amount = 0.0;
        } elseif ($paid_amount >= $total_amount - 0.005) {
            $new_status  = 'paid';
            $paid_amount = $total_amount;
        } else {
            $new_status = 'partial';
        }

        $wpdb->update(
            ECWP_TABLE_INVOICES,
            [
                'paid_amount'  => $paid_amount,
                'status'       => $encrypt->encrypt($new_status),
                'status_stats' => $new_status,
            ],
            ['id' => $invoice_id],
            ['%f', '%s', '%s'],
            ['%d']
        );

        do_action('ecwp_invoice_payment_synced', $invoice_id, $paid_amount, $new_status);

        if ($new_status !== $old_status) {
            do_action('ecwp_invoice_status_changed', $invoice_id, $old_status, $new_status);
        }
    }

}
