<?php

namespace ECWP\Advance;

class ECWPAdvance_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
    }
    public function database_update()
    {
        global $wpdb;
        $this->insert_meta_key_if_not_exists('easy_compta_advance_addon_active', 1);

        $columns_invoices = $wpdb->get_col("DESCRIBE " . ECWP_TABLE_INVOICES);
        $columns_quotes   = $wpdb->get_col("DESCRIBE " . ECWP_TABLE_QUOTES);

        if (!in_array('advance', $columns_invoices, true)) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " ADD COLUMN advance tinyint(1) NOT NULL DEFAULT 0");
        }
        if (!in_array('advance_amount', $columns_invoices, true)) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " ADD COLUMN advance_amount varchar(255) NOT NULL DEFAULT ''");
        }
        if (!in_array('advance_percent', $columns_invoices, true)) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " ADD COLUMN advance_percent int(11) NOT NULL DEFAULT 0");
        }
        if (!in_array('quote_id', $columns_invoices, true)) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " ADD COLUMN quote_id int(11) NOT NULL DEFAULT 0");
        }
        // Paiements partiels : colonne paid_amount
        if (!in_array('paid_amount', $columns_invoices, true)) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " ADD COLUMN paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER total_amount");

            // Initialiser paid_amount depuis les paiements existants
            if (defined('ECWP_TABLE_PAYMENTS')) {
                $wpdb->query(
                    "UPDATE " . ECWP_TABLE_INVOICES . " i
                     SET i.paid_amount = (
                         SELECT COALESCE(SUM(p.amount), 0)
                         FROM " . ECWP_TABLE_PAYMENTS . " p
                         WHERE p.invoice_id = i.id
                     )
                     WHERE i.paid_amount = 0"
                );
            }
        }
        if (!in_array('advance', $columns_quotes, true)) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_QUOTES . " ADD COLUMN advance tinyint(1) NOT NULL DEFAULT 0");
        }
    }
    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_advance_addon_active'));
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " DROP COLUMN IF EXISTS advance");
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " DROP COLUMN IF EXISTS advance_amount");
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " DROP COLUMN IF EXISTS advance_percent");
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " DROP COLUMN IF EXISTS quote_id");
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " DROP COLUMN IF EXISTS paid_amount");
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_QUOTES . " DROP COLUMN IF EXISTS advance");
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM %i WHERE meta_key = %s", ECWP_TABLE_SETTINGS,
            $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                ECWP_TABLE_SETTINGS,
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }
}
