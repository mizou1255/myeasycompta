<?php
/**
 * Plugin Name: myEasyCompta - Advance Addon
 * Description: This addon extends the functionality of myEasyCompta by providing advanced payment features, including deposit management. Easily manage partial payments, create invoices for deposits, and streamline the accounting process for businesses dealing with advance payments. Built with Vue.js and styled using TailwindCSS, this addon enhances the flexibility and usability of myEasyCompta.
 * Version: 2.0.0
 * Author: MELIOZE.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-advance
 * Domain Path: /languages/
 * Requires at least: 6.3
 * Tested up to: 6.9
 * Requires PHP: 8.1
 * Tags: accounting, quotes, invoices, expenses, Vue.js, TailwindCSS
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ECWP_Easy_Compta_Advance
{
    /**
     * Version du plugin
     *
     * @var string
     */
    public $version = '1.0.1';

    /**
     * Version PHP minimale requise
     *
     * @var string
     */
    private $min_php = '7.4';

    /**
     * Conteneur pour les instances de classe
     *
     * @var array
     */
    private $container = [];

    /**
     * Instance singleton
     *
     * @var ECWP_Easy_Compta_Advance
     */
    private static $instance;

    /**
     * Initialisation du plugin
     *
     * @return ECWP_Easy_Compta_Advance
     */
    public static function init()
    {
        if (!isset(self::$instance) && !(self::$instance instanceof ECWP_Easy_Compta_Advance)) {
            self::$instance = new ECWP_Easy_Compta_Advance();
            self::$instance->setup();
        }

        return self::$instance;
    }

    /**
     * Configuration initiale du plugin
     *
     * @return void
     */
    private function setup()
    {

        register_activation_hook(__FILE__, [$this, 'auto_deactivate']);

        if (!$this->is_supported_php()) {
            return;
        }

        $this->define_constants();
        $this->includes();
        $this->instantiate();
        $this->init_actions();
    }

    /**
     * Définir les constantes du plugin
     *
     * @return void
     */
    private function define_constants()
    {
        define('ECWP_ADVANCE_PATH', dirname(__FILE__));
        define('ECWP_ADVANCE_INCLUDES', ECWP_ADVANCE_PATH . '/includes');
        define('ECWP_ADVANCE_PATH_DIR', plugin_dir_path(__FILE__));
        define('ECWP_ADVANCE_URL', plugins_url('', __FILE__));
        if (!defined('ECWP_PRINCIPAL_PATH')) {
            define('ECWP_PRINCIPAL_PATH', WP_CONTENT_DIR . '/plugins/my-easy-compta');
        }

        define('ECWP_ADVANCE_SETTINGS_VAR', 'easy_compta_advance_addon_active');
    }

    /**
     * Inclure les fichiers requis
     *
     * @return void
     */
    private function includes()
    {
        require_once ECWP_PRINCIPAL_PATH . '/includes/API/Routes.php';
        require_once ECWP_ADVANCE_INCLUDES . '/migrations.php';
        require_once ECWP_ADVANCE_INCLUDES . '/App.php';
    }

    /**
     * Instancier les classes nécessaires
     *
     * @return void
     */
    private function instantiate()
    {
        $this->container['migration'] = new ECWP\Advance\ECWPAdvance_Migrations();
        $this->container['app'] = new ECWP\Advance\ECWPAdvance_APP();
    }

    /**
     * Initialiser les hooks d'action WordPress
     *
     * @return void
     */
    private function init_actions()
    {
        register_activation_hook(__FILE__, [$this->container['migration'], 'plugin_activation']);
        register_deactivation_hook(__FILE__, [$this->container['migration'], 'plugin_desactivation']);
        add_action('admin_init', [$this, 'check_plugin_dependencies']);
        // Garantir que le setting et les colonnes sont présents à chaque chargement
        add_action('admin_init', [$this->container['migration'], 'database_update']);
    }

    /**
     * Vérifier si la version PHP est supportée
     *
     * @return bool
     */
    public function is_supported_php()
    {
        return version_compare(PHP_VERSION, $this->min_php, '>=');
    }

    /**
     * Désactiver le plugin si la version PHP n'est pas supportée
     *
     * @return void
     */
    public function auto_deactivate()
    {
        if (!$this->is_supported_php()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'Le plugin %s nécessite PHP version %s ou supérieure.',
                        'my-easy-compta'
                    ),
                    esc_html__('myEasyCompta Advance addon', 'my-easy-compta'),
                    esc_html($this->min_php)
                ),
                esc_html__('Erreur d\'activation du plugin', 'my-easy-compta'),
                ['response' => 200, 'back_link' => true]
            );
        }
        if (!is_plugin_active('my-easy-compta/my-easy-compta.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires the myEasyCompta plugin to be active.',
                        'myEasyCompta Advance'
                    ),
                    esc_html__('myEasyCompta Advance', 'my-easy-compta')
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta'),
                ['response' => 200, 'back_link' => true]
            );
        }
    }
    /**
     * Check if myEasyCompta plugin are activated
     */
    public function check_plugin_dependencies()
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            add_action('admin_notices', [$this, 'display_missing_dependencies_notice']);
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }

    /**
     * Display a notice if myEasyCompta plugin are not activated
     */
    public function display_missing_dependencies_notice()
    {?>
<div class="notice notice-error is-dismissible">
    <p><?php _e('myEasyCompta Advance requires the myEasyCompta plugin to be activated. Please activate them before activating this plugin.', 'my-easy-compta');?>
    </p>
</div>
<?php
}
}

/**
 * Initialiser le plugin Mon_Plugin_Compta
 *
 * @return ECWP_Easy_Compta_Advance
 */

ECWP_Easy_Compta_Advance::init();