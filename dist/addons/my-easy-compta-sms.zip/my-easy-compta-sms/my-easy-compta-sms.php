<?php
/**
 * Plugin Name: myEasyCompta - Notifications SMS
 * Description: Envoyez des SMS automatiques à vos clients ou à l'admin lors d'événements clés : facture envoyée, paiement reçu, devis accepté, facture en retard. Compatible Twilio et OVH SMS.
 * Version: 1.0.0
 * Author: MELIOZ.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-sms
 * Domain Path: /languages/
 * Requires at least: 6.2
 * Tested up to: 6.9
 * Requires PHP: 8.0
 * Requires Plugins: my-easy-compta
 * Tags: sms, notifications, twilio, ovh, facture, devis
 */

if (!defined('ABSPATH')) exit;

define('ECWP_SMS_VERSION',  '1.0.0');
define('ECWP_SMS_PATH',     plugin_dir_path(__FILE__));
define('ECWP_SMS_URL',      plugins_url('', __FILE__));
define('ECWP_SMS_INCLUDES', ECWP_SMS_PATH . 'includes');

add_action('plugins_loaded', function () {
    if (!class_exists('ECWP_Easy_Compta')) return;

    require_once ECWP_SMS_INCLUDES . '/SMS.php';
    require_once ECWP_SMS_INCLUDES . '/Hooks.php';

    new ECWP\Addon\SMS\ECWP_SMS();
    new ECWP\Addon\SMS\ECWP_SMS_Hooks();

    add_action('admin_enqueue_scripts', function ($hook) {
        if ($hook !== 'toplevel_page_my-easy-compta') return;
        wp_add_inline_script('my-easy-compta-admin', 'if(window.myEasyComptaAdmin){window.myEasyComptaAdmin.smsAddonActive=true;}', 'after');
    });
}, 20);
