<?php

namespace ECWP\Addon\SMS;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

if (!defined('ABSPATH')) exit;

class ECWP_SMS
{
    /** @var array<string, string> Default message templates */
    private const DEFAULT_TEMPLATES = [
        'invoice_sent'     => 'Bonjour {CLIENT_NAME}, votre facture {INVOICE_NUMBER} d\'un montant de {AMOUNT} vous a été envoyée. {COMPANY_NAME}',
        'payment_received' => 'Bonjour {CLIENT_NAME}, nous avons bien reçu votre paiement de {AMOUNT} pour la facture {INVOICE_NUMBER}. Merci ! {COMPANY_NAME}',
        'quote_accepted'   => 'Bonjour {CLIENT_NAME}, votre devis {QUOTE_NUMBER} a été accepté. Nous vous contacterons prochainement. {COMPANY_NAME}',
        'invoice_overdue'  => 'Bonjour {CLIENT_NAME}, la facture {INVOICE_NUMBER} de {AMOUNT} est en retard de paiement. Merci de régulariser. {COMPANY_NAME}',
    ];

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes()
    {
        $ns = 'my-easy-compta/v1';
        $auth = function () { return current_user_can('manage_options'); };

        register_rest_route($ns, '/sms/settings', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_settings'],
            'permission_callback' => $auth,
        ]);

        register_rest_route($ns, '/sms/settings', [
            'methods'             => 'POST',
            'callback'            => [$this, 'save_settings'],
            'permission_callback' => $auth,
        ]);

        register_rest_route($ns, '/sms/test', [
            'methods'             => 'POST',
            'callback'            => [$this, 'send_test'],
            'permission_callback' => $auth,
        ]);

        register_rest_route($ns, '/sms/logs', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_logs'],
            'permission_callback' => $auth,
        ]);

        register_rest_route($ns, '/sms/logs', [
            'methods'             => 'DELETE',
            'callback'            => [$this, 'clear_logs'],
            'permission_callback' => $auth,
        ]);

        register_rest_route($ns, '/sms/send-manual', [
            'methods'             => 'POST',
            'callback'            => [$this, 'send_manual'],
            'permission_callback' => $auth,
        ]);

        register_rest_route($ns, '/sms/logs-for-doc', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_logs_for_doc'],
            'permission_callback' => $auth,
        ]);
    }

    // -------------------------------------------------------------------------

    public function get_settings(): WP_REST_Response
    {
        $settings = get_option('ecwp_sms_settings', []);

        // Merge with defaults
        $defaults = [
            'provider'         => 'twilio',   // twilio | ovh
            'enabled'          => false,
            // Twilio (SMS)
            'twilio_sid'       => '',
            'twilio_token'     => '',
            'twilio_from'      => '',
            // WhatsApp provider: twilio_wa | meta
            'wa_provider'          => 'twilio_wa',
            // Twilio WhatsApp
            'twilio_whatsapp_from' => '',     // e.g. whatsapp:+14155238886
            // Meta WhatsApp Business API
            'meta_wa_token'        => '',     // permanent access token
            'meta_wa_phone_id'     => '',     // Phone number ID from Meta dashboard
            // OVH
            'ovh_app_key'      => '',
            'ovh_app_secret'   => '',
            'ovh_consumer_key' => '',
            'ovh_service_name' => '',
            'ovh_sender'       => '',
            // Events — channel: sms | whatsapp | both
            'events' => [
                'invoice_sent'     => ['enabled' => true,  'recipient' => 'client', 'channel' => 'sms'],
                'payment_received' => ['enabled' => true,  'recipient' => 'client', 'channel' => 'sms'],
                'quote_accepted'   => ['enabled' => true,  'recipient' => 'admin',  'channel' => 'sms'],
                'invoice_overdue'  => ['enabled' => false, 'recipient' => 'client', 'channel' => 'sms'],
            ],
            // Templates
            'templates' => self::DEFAULT_TEMPLATES,
            // Admin phone for admin-targeted events
            'admin_phone' => '',
            // Mode: auto (send on events) | manual (only via NavBar button)
            'mode' => 'auto',
        ];

        return rest_ensure_response(array_replace_recursive($defaults, $settings));
    }

    public function save_settings(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $body = $request->get_json_params();

        $settings = [
            'provider'              => sanitize_text_field($body['provider']              ?? 'twilio'),
            'enabled'               => (bool) ($body['enabled'] ?? false),
            'twilio_sid'            => sanitize_text_field($body['twilio_sid']            ?? ''),
            'twilio_token'          => sanitize_text_field($body['twilio_token']          ?? ''),
            'twilio_from'           => sanitize_text_field($body['twilio_from']           ?? ''),
            'twilio_whatsapp_from'  => sanitize_text_field($body['twilio_whatsapp_from']  ?? ''),
            'wa_provider'           => in_array($body['wa_provider'] ?? 'twilio_wa', ['twilio_wa', 'meta'], true) ? $body['wa_provider'] : 'twilio_wa',
            'meta_wa_token'         => sanitize_text_field($body['meta_wa_token']         ?? ''),
            'meta_wa_phone_id'      => sanitize_text_field($body['meta_wa_phone_id']      ?? ''),
            'ovh_app_key'           => sanitize_text_field($body['ovh_app_key']           ?? ''),
            'ovh_app_secret'        => sanitize_text_field($body['ovh_app_secret']        ?? ''),
            'ovh_consumer_key'      => sanitize_text_field($body['ovh_consumer_key']      ?? ''),
            'ovh_service_name'      => sanitize_text_field($body['ovh_service_name']      ?? ''),
            'ovh_sender'            => sanitize_text_field($body['ovh_sender']            ?? ''),
            'admin_phone'           => sanitize_text_field($body['admin_phone']           ?? ''),
            'mode'                  => in_array($body['mode'] ?? 'auto', ['auto', 'manual'], true) ? $body['mode'] : 'auto',
            'events'                => [],
            'templates'             => [],
        ];

        $allowed_events   = ['invoice_sent', 'payment_received', 'quote_accepted', 'invoice_overdue'];
        $allowed_channels = ['sms', 'whatsapp', 'both'];
        foreach ($allowed_events as $event) {
            $ev = $body['events'][$event] ?? [];
            $settings['events'][$event] = [
                'enabled'   => (bool) ($ev['enabled'] ?? false),
                'recipient' => in_array($ev['recipient'] ?? 'client', ['client', 'admin', 'both'], true) ? $ev['recipient'] : 'client',
                'channel'   => in_array($ev['channel']   ?? 'sms',    $allowed_channels, true)           ? $ev['channel']   : 'sms',
            ];
        }

        foreach ($allowed_events as $event) {
            $tpl = $body['templates'][$event] ?? self::DEFAULT_TEMPLATES[$event];
            $settings['templates'][$event] = sanitize_textarea_field($tpl);
        }

        update_option('ecwp_sms_settings', $settings);

        return rest_ensure_response(['success' => true]);
    }

    public function send_test(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $body  = $request->get_json_params();
        $phone = sanitize_text_field($body['phone'] ?? '');
        $msg   = sanitize_textarea_field($body['message'] ?? 'Test SMS depuis myEasyCompta.');

        if (empty($phone)) {
            return new WP_Error('missing_phone', 'Numéro de téléphone requis.', ['status' => 400]);
        }

        $result = $this->send_sms($phone, $msg);

        if (is_wp_error($result)) {
            return $result;
        }

        return rest_ensure_response(['success' => true, 'message' => 'SMS de test envoyé.']);
    }

    public function get_logs(): WP_REST_Response
    {
        $logs = get_option('ecwp_sms_logs', []);
        // Return newest first, max 100
        $logs = array_slice(array_reverse($logs), 0, 100);
        return rest_ensure_response($logs);
    }

    public function clear_logs(): WP_REST_Response
    {
        update_option('ecwp_sms_logs', []);
        return rest_ensure_response(['success' => true]);
    }

    public function send_manual(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $body     = $request->get_json_params();
        $phone    = sanitize_text_field($body['phone']    ?? '');
        $msg      = sanitize_textarea_field($body['message'] ?? '');
        $channel  = in_array($body['channel'] ?? 'sms', ['sms', 'whatsapp', 'both'], true) ? $body['channel'] : 'sms';
        $doc_type = sanitize_text_field($body['doc_type'] ?? '');
        $doc_id   = absint($body['doc_id']   ?? 0);

        if (empty($phone)) {
            return new WP_Error('missing_phone', 'Numéro de téléphone requis.', ['status' => 400]);
        }
        if (empty($msg)) {
            return new WP_Error('missing_message', 'Message requis.', ['status' => 400]);
        }

        $result = $this->send_sms($phone, $msg, $channel, $doc_type, $doc_id);

        if (is_wp_error($result)) {
            return $result;
        }

        return rest_ensure_response(['success' => true]);
    }

    public function get_logs_for_doc(WP_REST_Request $request): WP_REST_Response
    {
        $doc_type = sanitize_text_field($request->get_param('doc_type') ?? '');
        $doc_id   = absint($request->get_param('doc_id') ?? 0);

        $all_logs = get_option('ecwp_sms_logs', []);

        $filtered = array_values(array_filter($all_logs, function ($log) use ($doc_type, $doc_id) {
            return ($log['doc_type'] ?? '') === $doc_type && (int) ($log['doc_id'] ?? 0) === $doc_id;
        }));

        // Newest first
        $filtered = array_reverse($filtered);

        return rest_ensure_response($filtered);
    }

    // -------------------------------------------------------------------------
    // Core sending logic
    // -------------------------------------------------------------------------

    /**
     * Send a message via the configured provider and channel.
     *
     * @param string $phone    E.164 phone number, e.g. +33612345678
     * @param string $message  Message text
     * @param string $channel  'sms' | 'whatsapp' | 'both'
     * @param string $doc_type Optional doc type ('invoice' | 'quote') for log
     * @param int    $doc_id   Optional doc ID for log
     */
    public function send_sms(string $phone, string $message, string $channel = 'sms', string $doc_type = '', int $doc_id = 0): bool|WP_Error
    {
        $settings = get_option('ecwp_sms_settings', []);
        $provider = $settings['provider'] ?? 'twilio';

        $errors = [];

        // ── SMS channel ──────────────────────────────────────────────────────
        if (in_array($channel, ['sms', 'both'], true)) {
            $result = match ($provider) {
                'twilio' => $this->send_via_twilio($settings, $phone, $message),
                'ovh'    => $this->send_via_ovh($settings, $phone, $message),
                default  => new WP_Error('unknown_provider', 'Fournisseur SMS inconnu.', ['status' => 400]),
            };
            $this->log($phone, $message, $provider . ' (SMS)', $result, $doc_type, $doc_id);
            if (is_wp_error($result)) $errors[] = $result->get_error_message();
        }

        // ── WhatsApp channel ─────────────────────────────────────────────────
        if (in_array($channel, ['whatsapp', 'both'], true)) {
            $wa_provider = $settings['wa_provider'] ?? 'twilio_wa'; // twilio_wa | meta
            $result_wa = match ($wa_provider) {
                'meta'      => $this->send_via_meta_wa($settings, $phone, $message),
                default     => $this->send_via_twilio_wa($settings, $phone, $message),
            };
            $this->log($phone, $message, $wa_provider . ' (WhatsApp)', $result_wa, $doc_type, $doc_id);
            if (is_wp_error($result_wa)) $errors[] = $result_wa->get_error_message();
        }

        if (!empty($errors)) {
            return new WP_Error('send_error', implode(' | ', $errors), ['status' => 500]);
        }

        return true;
    }

    private function log(string $phone, string $message, string $provider, mixed $result, string $doc_type = '', int $doc_id = 0): void
    {
        $logs   = get_option('ecwp_sms_logs', []);
        $logs[] = [
            'date'     => current_time('mysql'),
            'phone'    => substr($phone, 0, -4) . '****',
            'message'  => mb_substr($message, 0, 80) . (mb_strlen($message) > 80 ? '…' : ''),
            'provider' => $provider,
            'status'   => is_wp_error($result) ? 'error' : 'sent',
            'error'    => is_wp_error($result) ? $result->get_error_message() : null,
            'doc_type' => $doc_type,
            'doc_id'   => $doc_id,
        ];
        update_option('ecwp_sms_logs', array_slice($logs, -500));
    }

    private function send_via_twilio(array $s, string $to, string $body): bool|WP_Error
    {
        $sid   = $s['twilio_sid']   ?? '';
        $token = $s['twilio_token'] ?? '';
        $from  = $s['twilio_from']  ?? '';

        if (!$sid || !$token || !$from) {
            return new WP_Error('twilio_config', 'Configuration Twilio incomplète.', ['status' => 500]);
        }

        $url      = "https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json";
        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode("{$sid}:{$token}"),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body' => http_build_query(['From' => $from, 'To' => $to, 'Body' => $body]),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            $resp_body = json_decode(wp_remote_retrieve_body($response), true);
            return new WP_Error('twilio_error', $resp_body['message'] ?? 'Erreur Twilio.', ['status' => 500]);
        }

        return true;
    }

    private function send_via_ovh(array $s, string $to, string $message): bool|WP_Error
    {
        $app_key      = $s['ovh_app_key']      ?? '';
        $app_secret   = $s['ovh_app_secret']   ?? '';
        $consumer_key = $s['ovh_consumer_key'] ?? '';
        $service_name = $s['ovh_service_name'] ?? '';
        $sender       = $s['ovh_sender']       ?? '';

        if (!$app_key || !$app_secret || !$consumer_key || !$service_name) {
            return new WP_Error('ovh_config', 'Configuration OVH SMS incomplète.', ['status' => 500]);
        }

        $url       = "https://eu.api.ovh.com/1.0/sms/{$service_name}/jobs";
        $timestamp = time();
        $body_json = wp_json_encode([
            'message'   => $message,
            'receivers' => [$to],
            'sender'    => $sender ?: null,
        ]);

        // OVH signature: SHA1("$1$" + appSecret + "+" + consumerKey + "+" + GET/POST + "+" + url + "+" + body + "+" + timestamp)
        $pre_hash = implode('+', [
            '$1$',
            $app_secret,
            $consumer_key,
            'POST',
            $url,
            $body_json,
            $timestamp,
        ]);
        $signature = '$1$' . sha1($pre_hash);

        $response = wp_remote_post($url, [
            'headers' => [
                'Content-Type'      => 'application/json',
                'X-Ovh-Application' => $app_key,
                'X-Ovh-Consumer'    => $consumer_key,
                'X-Ovh-Timestamp'   => $timestamp,
                'X-Ovh-Signature'   => $signature,
            ],
            'body'    => $body_json,
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            $resp_body = json_decode(wp_remote_retrieve_body($response), true);
            return new WP_Error('ovh_error', $resp_body['message'] ?? 'Erreur OVH SMS.', ['status' => 500]);
        }

        return true;
    }

    /**
     * Twilio WhatsApp — same credentials as SMS, "From" is whatsapp:+xxx.
     */
    private function send_via_twilio_wa(array $s, string $to, string $body): bool|WP_Error
    {
        $sid   = $s['twilio_sid']           ?? '';
        $token = $s['twilio_token']         ?? '';
        $from  = $s['twilio_whatsapp_from'] ?? '';

        if (!$sid || !$token || !$from) {
            return new WP_Error('twilio_wa_config', 'Configuration Twilio WhatsApp incomplète (numéro expéditeur WhatsApp manquant).', ['status' => 500]);
        }

        // Ensure whatsapp: prefix
        $wa_from = str_starts_with($from, 'whatsapp:') ? $from : 'whatsapp:' . $from;
        $wa_to   = str_starts_with($to,   'whatsapp:') ? $to   : 'whatsapp:' . $to;

        $url      = "https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json";
        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode("{$sid}:{$token}"),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body'    => http_build_query(['From' => $wa_from, 'To' => $wa_to, 'Body' => $body]),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            $resp_body = json_decode(wp_remote_retrieve_body($response), true);
            return new WP_Error('twilio_wa_error', $resp_body['message'] ?? 'Erreur Twilio WhatsApp.', ['status' => 500]);
        }

        return true;
    }

    /**
     * Meta Cloud API — WhatsApp Business.
     * Sends a free-form text message (requires an active conversation / 24h window).
     * For out-of-window messages, a template must be used — this sends plain text.
     */
    private function send_via_meta_wa(array $s, string $to, string $message): bool|WP_Error
    {
        $token    = $s['meta_wa_token']    ?? '';
        $phone_id = $s['meta_wa_phone_id'] ?? '';

        if (!$token || !$phone_id) {
            return new WP_Error('meta_wa_config', 'Configuration Meta WhatsApp incomplète (token ou Phone ID manquant).', ['status' => 500]);
        }

        // Strip leading + for Meta API
        $to_clean = ltrim($to, '+');

        $url      = "https://graph.facebook.com/v19.0/{$phone_id}/messages";
        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode([
                'messaging_product' => 'whatsapp',
                'to'                => $to_clean,
                'type'              => 'text',
                'text'              => ['body' => $message],
            ]),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) return $response;

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            $resp_body = json_decode(wp_remote_retrieve_body($response), true);
            $err_msg   = $resp_body['error']['message'] ?? 'Erreur Meta WhatsApp.';
            return new WP_Error('meta_wa_error', $err_msg, ['status' => 500]);
        }

        return true;
    }

    // -------------------------------------------------------------------------
    // Template substitution
    // -------------------------------------------------------------------------

    public function substitute(string $template, array $vars): string
    {
        foreach ($vars as $key => $value) {
            $template = str_replace('{' . strtoupper($key) . '}', $value, $template);
        }
        return $template;
    }

    public function get_company_name(): string
    {
        global $wpdb;
        if (!defined('ECWP_TABLE_SETTINGS')) return get_bloginfo('name');
        return (string) $wpdb->get_var($wpdb->prepare(
            'SELECT meta_value FROM ' . ECWP_TABLE_SETTINGS . ' WHERE meta_key = %s',
            'company_name'
        )) ?: get_bloginfo('name');
    }
}
