<?php

namespace ECWP\Addon\SMS;

if (!defined('ABSPATH')) exit;

/**
 * Listens to core plugin action hooks and dispatches SMS notifications.
 */
class ECWP_SMS_Hooks
{
    private ECWP_SMS $sms;

    public function __construct()
    {
        $this->sms = new ECWP_SMS();
        $this->register_hooks();
    }

    private function register_hooks()
    {
        // Core plugin fires these actions — we listen here.
        // If the core doesn't fire them yet, these hooks are no-ops (safe).
        add_action('ecwp_invoice_sent',      [$this, 'on_invoice_sent'],      10, 2);
        add_action('ecwp_payment_received',  [$this, 'on_payment_received'],  10, 2);
        add_action('ecwp_quote_accepted',    [$this, 'on_quote_accepted'],    10, 2);
        add_action('ecwp_invoice_overdue',   [$this, 'on_invoice_overdue'],   10, 2);

        // Online-quote addon hook
        add_action('ecwp_online_quote_actioned', [$this, 'on_online_quote_actioned'], 10, 3);
    }

    // -------------------------------------------------------------------------

    public function on_invoice_sent(int $invoice_id, array $invoice_data)
    {
        $this->dispatch('invoice_sent', $invoice_id, $invoice_data);
    }

    public function on_payment_received(int $invoice_id, array $payment_data)
    {
        $this->dispatch('payment_received', $invoice_id, $payment_data);
    }

    public function on_quote_accepted(int $quote_id, array $quote_data)
    {
        $this->dispatch_quote('quote_accepted', $quote_id, $quote_data);
    }

    public function on_invoice_overdue(int $invoice_id, array $invoice_data)
    {
        $this->dispatch('invoice_overdue', $invoice_id, $invoice_data);
    }

    public function on_online_quote_actioned(int $quote_id, string $action, string $comment)
    {
        if ($action !== 'accepted') return;

        $quote = $this->get_quote($quote_id);
        if (!$quote) return;

        $this->dispatch_quote('quote_accepted', $quote_id, (array) $quote);
    }

    // -------------------------------------------------------------------------
    // Internal dispatchers
    // -------------------------------------------------------------------------

    private function dispatch(string $event, int $invoice_id, array $data)
    {
        $settings = get_option('ecwp_sms_settings', []);
        if (empty($settings['enabled'])) return;
        // Manual mode: automatic dispatch is disabled — user sends via NavBar button
        if (($settings['mode'] ?? 'auto') === 'manual') return;

        $ev = $settings['events'][$event] ?? [];
        if (empty($ev['enabled'])) return;

        $template   = $settings['templates'][$event] ?? '';
        $invoice    = $this->get_invoice($invoice_id);
        if (!$invoice) return;

        $client     = $this->get_client((int) $invoice->client_id);
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
        $vars = [
            'CLIENT_NAME'     => $client ? $client->company_name : '',
            'INVOICE_NUMBER'  => $invoice->invoice_number ?? '',
            'QUOTE_NUMBER'    => '',
            'AMOUNT'          => number_format((float) $encrypt->decrypt($invoice->total_amount ?? ''), 2, ',', ' ') . ' €',
            'COMPANY_NAME'    => $this->sms->get_company_name(),
        ];

        $message   = $this->sms->substitute($template, $vars);
        $recipient = $ev['recipient'] ?? 'client';
        $channel   = $ev['channel']   ?? 'sms';

        $this->send_to($recipient, $client, $settings, $message, $channel);
    }

    private function dispatch_quote(string $event, int $quote_id, array $data)
    {
        $settings = get_option('ecwp_sms_settings', []);
        if (empty($settings['enabled'])) return;
        if (($settings['mode'] ?? 'auto') === 'manual') return;

        $ev = $settings['events'][$event] ?? [];
        if (empty($ev['enabled'])) return;

        $template = $settings['templates'][$event] ?? '';
        $quote    = $this->get_quote($quote_id);
        if (!$quote) return;

        $client  = $this->get_client((int) $quote->client_id);
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
        $vars = [
            'CLIENT_NAME'   => $client ? $client->company_name : '',
            'QUOTE_NUMBER'  => $quote->quote_number ?? '',
            'INVOICE_NUMBER'=> '',
            'AMOUNT'        => number_format((float) $encrypt->decrypt($quote->total_amount ?? ''), 2, ',', ' ') . ' €',
            'COMPANY_NAME'  => $this->sms->get_company_name(),
        ];

        $message   = $this->sms->substitute($template, $vars);
        $recipient = $ev['recipient'] ?? 'admin';
        $channel   = $ev['channel']   ?? 'sms';

        $this->send_to($recipient, $client, $settings, $message, $channel);
    }

    private function send_to(string $recipient, ?object $client, array $settings, string $message, string $channel = 'sms')
    {
        $admin_phone  = $settings['admin_phone'] ?? '';
        $client_phone = $client ? ($client->phone ?? '') : '';

        if (in_array($recipient, ['client', 'both'], true) && $client_phone) {
            $this->sms->send_sms($client_phone, $message, $channel);
        }

        if (in_array($recipient, ['admin', 'both'], true) && $admin_phone) {
            $this->sms->send_sms($admin_phone, $message, $channel);
        }
    }

    // -------------------------------------------------------------------------

    private function get_invoice(int $id): ?object
    {
        if (!defined('ECWP_TABLE_INVOICES')) return null;
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ECWP_TABLE_INVOICES . ' WHERE id = %d', $id));
    }

    private function get_quote(int $id): ?object
    {
        if (!defined('ECWP_TABLE_QUOTES')) return null;
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ECWP_TABLE_QUOTES . ' WHERE id = %d', $id));
    }

    private function get_client(int $id): ?object
    {
        if (!defined('ECWP_TABLE_CLIENTS')) return null;
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . ECWP_TABLE_CLIENTS . ' WHERE id = %d', $id));
    }
}
