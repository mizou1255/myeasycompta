<?php

namespace ECWP\Recurring\Migrations;

class ECWPRecurring_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
        $this->schedule_cron();
    }

    public function plugin_deactivation()
    {
        global $wpdb;
        $this->unschedule_cron();
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => ECWP_RECURRING_SETTINGS_VAR));
    }

    public function database_update()
    {
        global $wpdb;
        
        // Activer l'addon dans les settings
        $this->insert_meta_key_if_not_exists(ECWP_RECURRING_SETTINGS_VAR, 1);

        // Table des factures récurrentes
        $table_recurring = ECWP_TABLE_RECURRING_INVOICES;
        $charset_collate = $wpdb->get_charset_collate();

        $sql_recurring = "CREATE TABLE IF NOT EXISTS $table_recurring (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            client_id bigint(20) NOT NULL,
            template_invoice_id bigint(20) DEFAULT NULL COMMENT 'ID de la facture utilisée comme modèle',
            frequency varchar(50) NOT NULL COMMENT 'monthly, quarterly, semi_annual, annual, custom',
            custom_days int(11) DEFAULT NULL COMMENT 'Nombre de jours pour fréquence personnalisée',
            start_date date NOT NULL,
            end_date date DEFAULT NULL,
            next_generation_date date NOT NULL,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            is_paused tinyint(1) NOT NULL DEFAULT 0,
            notification_days_before int(11) DEFAULT 0 COMMENT 'Nombre de jours avant génération pour notification',
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY client_id (client_id),
            KEY template_invoice_id (template_invoice_id),
            KEY is_active (is_active),
            KEY next_generation_date (next_generation_date)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_recurring);

        // Table de l'historique des générations
        $table_history = ECWP_TABLE_RECURRING_INVOICES_HISTORY;
        
        $sql_history = "CREATE TABLE IF NOT EXISTS $table_history (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            recurring_invoice_id bigint(20) NOT NULL,
            generated_invoice_id bigint(20) NOT NULL,
            generation_date datetime NOT NULL,
            scheduled_date date NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'success' COMMENT 'success, failed, skipped',
            error_message text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY recurring_invoice_id (recurring_invoice_id),
            KEY generated_invoice_id (generated_invoice_id),
            KEY generation_date (generation_date)
        ) $charset_collate;";

        dbDelta($sql_history);
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM {$wpdb->prefix}ecwp_settings WHERE meta_key = %s",
            $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert($wpdb->prefix . 'ecwp_settings', array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                $wpdb->prefix . 'ecwp_settings',
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }

    private function schedule_cron()
    {
        // Planifier le cron quotidien pour vérifier les factures à générer
        if (!wp_next_scheduled('ecwp_recurring_invoices_daily_check')) {
            wp_schedule_event(time(), 'daily', 'ecwp_recurring_invoices_daily_check');
        }
    }

    private function unschedule_cron()
    {
        $timestamp = wp_next_scheduled('ecwp_recurring_invoices_daily_check');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'ecwp_recurring_invoices_daily_check');
        }
    }
}






