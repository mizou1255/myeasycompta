<?php

namespace ECWP\Recurring\Modules;

use ECWP\API\Routes;

class ECWPRecurring_APP
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        add_action('admin_menu', array($this, 'add_submenu_page'), 20);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        $this->register_api_routes();
    }

    /**
     * Ajouter la page de sous-menu pour les factures récurrentes
     */
    public function add_submenu_page()
    {
        add_submenu_page(
            'my-easy-compta',
            __('Recurring Invoices', 'my-easy-compta-recurring-invoices'),
            __('Recurring Invoices <sup>PRO</sup>', 'my-easy-compta-recurring-invoices'),
            'manage_options',
            'my-easy-compta-recurring-invoices',
            array($this, 'render_page'),
            4
        );
    }

    /**
     * Enqueue scripts and styles
     */
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts($hook)
    {
        if (!in_array($hook, ['my-easy-compta_page_my-easy-compta-recurring-invoices', 'myeasycompta_page_my-easy-compta-recurring-invoices'])) {
            return;
        }

        // Utiliser les assets du plugin principal
        if (defined('ECWP_URL') && defined('ECWP_VERSION')) {
            wp_enqueue_style('my-easy-compta-main', ECWP_URL . '/assets/css/main.css', array(), ECWP_VERSION);
            wp_enqueue_style('my-easy-compta-admin-style', ECWP_URL . '/assets/dist/style.min.css', array(), ECWP_VERSION);
            wp_enqueue_style('my-easy-compta-index', ECWP_URL . '/assets/dist/index.min.css', array(), ECWP_VERSION);
            wp_enqueue_style('fontawesome', ECWP_URL . '/assets/css/all.min.css', array(), ECWP_VERSION);
            // wp_enqueue_script('vuejs', ECWP_URL . '/assets/js/vue.js', array(), ECWP_VERSION, true); // Bundled in app.min.js

            // Charger le script compilé de l'addon
            if (file_exists(ECWP_RECURRING_PATH . '/assets/dist/app.min.js')) {
                wp_enqueue_script('my-easy-compta-recurring-invoices', ECWP_RECURRING_URL . '/assets/dist/app.min.js', array(), $this->get_version(), true);
                add_filter('script_loader_tag', array($this, 'add_type_attribute'), 10, 2);
            }

            // Charger les traductions
            if (file_exists(ECWP_PATH . '/languages/my-easy-compta-translations.php')) {
                require_once ECWP_PATH . '/languages/my-easy-compta-translations.php';
                wp_localize_script('my-easy-compta-recurring-invoices', 'myEasyComptaAdmin', array(
                    'nonce' => wp_create_nonce('wp_rest'),
                    'easyComptaTranslations' => $translations ?? array(),
                ));
            }
        }
    }

    /**
     * Ajouter l'attribut type="module" aux scripts Vue.js
     */
    public function add_type_attribute($tag, $handle)
    {
        $scripts = array('my-easy-compta-recurring-invoices');
        if (in_array($handle, $scripts)) {
            return str_replace(' src', ' type="module" src', $tag);
        }
        return $tag;
    }

    /**
     * Obtenir la version du plugin
     */
    private function get_version()
    {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        $plugin_data = get_plugin_data(ECWP_RECURRING_PATH . '/myeasycompta-recurring-invoices.php');
        return $plugin_data['Version'] ?? '1.0.0';
    }

    /**
     * Rendre la page d'administration
     */
    public function render_page()
    {
        if (!$this->has_valid_license()) {
            echo '<div class="admin-overlay">
                <div>
                    <p><strong>Licence requise</strong></p>
                    <p>Vous devez acheter une licence pour utiliser ce plugin. Veuillez <a href="' . esc_url(admin_url('admin.php?page=my-easy-compta#/settings?tab=16')) . '">ajouter votre clé de licence ici</a>.</p>
                    <p>Ce plugin ne peut pas être utilisé sans une licence valide.</p>
                </div>
            </div>';
            echo '<div id="ecwp-recurring-invoices-app" class="ecwp-content blur-app"></div>';
        } else {
            echo '<div id="ecwp-recurring-invoices-app" class="ecwp-content"></div>';
        }
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    /**
     * Enregistrer les routes API
     */
    public function register_api_routes()
    {
        // Les routes seront enregistrées dans RecurringInvoices.php
        $this->routes->register_routes();
    }
}

