<?php

namespace ECWP\Recurring\Modules;

class ECWPRecurring_Cron
{
    protected $wpdb;
    protected $last_generated_invoice_id;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        
        // Enregistrer le hook cron
        add_action('ecwp_recurring_invoices_daily_check', array($this, 'check_and_generate_invoices'));
    }

    /**
     * Vérifier et générer les factures récurrentes
     * Cette méthode est appelée quotidiennement par le cron WordPress
     */
    public function check_and_generate_invoices()
    {
        $table = ECWP_TABLE_RECURRING_INVOICES;
        $today = current_time('Y-m-d');

        $recurring_invoices = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$table}
                WHERE is_active = 1
                AND is_paused = 0
                AND next_generation_date <= %s
                AND (end_date IS NULL OR end_date >= %s)",
                $today,
                $today
            ),
            OBJECT
        );

        foreach ($recurring_invoices as $recurring) {
            $this->generate_all_missed_for_recurring($recurring);
        }
    }

    /**
     * Génère TOUTES les factures manquées pour une récurrence donnée.
     * Boucle jusqu'à ce que next_generation_date soit dans le futur.
     * Limite à 36 itérations par sécurité (3 ans max).
     */
    public function generate_all_missed_for_recurring($recurring)
    {
        $table         = ECWP_TABLE_RECURRING_INVOICES;
        $today         = current_time('Y-m-d');
        $generated     = 0;
        $max_iter      = 36;

        // Recharger la récurrence depuis la DB pour avoir next_generation_date à jour
        $recurring = $this->wpdb->get_row(
            $this->wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $recurring->id),
            OBJECT
        );

        while (
            $recurring &&
            $recurring->next_generation_date <= $today &&
            ( $recurring->end_date === null || $recurring->end_date >= $today ) &&
            $generated < $max_iter
        ) {
            $success = $this->generate_invoice_from_recurring($recurring);
            if (!$success) {
                break; // stop on error to avoid infinite loop
            }
            $generated++;

            // Recharger pour obtenir la next_generation_date mise à jour
            $recurring = $this->wpdb->get_row(
                $this->wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $recurring->id),
                OBJECT
            );
        }

        return $generated;
    }

    /**
     * Générer une facture à partir d'une facture récurrente
     * Méthode publique pour permettre l'appel depuis RecurringInvoices.php
     */
    public function generate_invoice_from_recurring($recurring)
    {
        try {
            // Vérifier si le plugin principal est disponible
            if (!class_exists('ECWP\Admin\PDF\PDFGenerator')) {
                error_log('myEasyCompta Recurring Invoices: Plugin principal non disponible');
                return false;
            }

            // Si une facture modèle est définie, l'utiliser
            if (!empty($recurring->template_invoice_id)) {
                $this->generate_from_template($recurring);
            } else {
                // Sinon, créer une facture basique
                $this->generate_basic_invoice($recurring);
            }

            // Mettre à jour la date de prochaine génération
            $this->update_next_generation_date($recurring);

            // Enregistrer dans l'historique
            $this->log_generation($recurring->id, $this->last_generated_invoice_id, 'success');

            // Envoyer notification si l'option est activée
            $this->maybe_send_generation_email($recurring, $this->last_generated_invoice_id);

            return true;
        } catch (\Exception $e) {
            // Enregistrer l'erreur dans l'historique
            $this->log_generation($recurring->id, null, 'failed', $e->getMessage());
            error_log('myEasyCompta Recurring Invoices Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Génère un numéro de facture en respectant le format configuré dans les réglages.
     * Réplique la logique de ECWP_Invoices::generate_document_number().
     */
    private function build_invoice_number(string $prefix, string $format, string $table, int $seq): string
    {
        global $wpdb;
        $year  = (int) current_time('Y');
        $month = (int) current_time('m');

        switch ($format) {
            case 'prefix_year':
                $count = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table} WHERE YEAR(created_at) = %d", $year
                ));
                return $prefix . '-' . $year . '-' . str_pad($count + 1, 4, '0', STR_PAD_LEFT);

            case 'prefix_year_month':
                $count = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table} WHERE YEAR(created_at) = %d AND MONTH(created_at) = %d",
                    $year, $month
                ));
                return $prefix . '-' . $year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT) . '-' . str_pad($count + 1, 4, '0', STR_PAD_LEFT);

            case 'year':
                $count = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table} WHERE YEAR(created_at) = %d", $year
                ));
                return $year . '-' . str_pad($count + 1, 4, '0', STR_PAD_LEFT);

            default: // 'prefix'
                return $prefix . '-' . str_pad($seq, 4, '0', STR_PAD_LEFT);
        }
    }

    /**
     * Générer une facture à partir d'un modèle
     */
    private function generate_from_template($recurring)
    {
        global $wpdb;

        $invoices_table         = ECWP_TABLE_INVOICES;
        $invoice_elements_table = ECWP_TABLE_INVOICE_ELEMENTS;
        $settings_table         = ECWP_TABLE_SETTINGS;
        $encrypt                = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        // Récupérer la facture modèle
        $template = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$invoices_table} WHERE id = %d", $recurring->template_invoice_id),
            OBJECT
        );

        if (!$template) {
            throw new \Exception('Template invoice not found');
        }

        // Récupérer les éléments de la facture modèle
        $template_items = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$invoice_elements_table} WHERE invoice_id = %d", $recurring->template_invoice_id),
            OBJECT
        );

        // Lire les réglages de numérotation
        $invoice_prefix = sanitize_text_field(
            $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$settings_table} WHERE meta_key = %s", 'invoice_prefix')) ?: 'INV'
        );
        $invoice_number_format = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$settings_table} WHERE meta_key = %s", 'invoice_number_format')) ?: 'prefix';

        $wpdb->query('START TRANSACTION');

        // Lock du compteur global pour éviter les doublons concurrents
        $last_seq = (int) $wpdb->get_var("SELECT MAX(number) FROM {$invoices_table} FOR UPDATE");
        $new_seq  = $last_seq + 1;
        $invoice_number_plain = $this->build_invoice_number($invoice_prefix, $invoice_number_format, $invoices_table, $new_seq);

        $now = current_time('Y-m-d H:i:s');

        // Créer la nouvelle facture
        $new_invoice_data = array(
            'number'          => $new_seq,
            'invoice_number'  => $encrypt->encrypt($invoice_number_plain),
            'client_id'       => $recurring->client_id,
            'total_amount'    => $template->total_amount,  // déjà chiffré
            'amount'          => $template->amount,         // déjà chiffré
            'subtotal'        => $template->subtotal,       // déjà chiffré
            'tax'             => $template->tax,            // déjà chiffré
            'discount'        => $template->discount,
            'notes'           => $template->notes,
            'transaction_type'=> $template->transaction_type ?? 'B2B',
            'created_at'      => $now,
            'invoice_date'    => wp_date('Y-m-d'),
            'due_date'        => $this->calculate_due_date($recurring),
            'status'          => $encrypt->encrypt('unpaid'),
            'status_stats'    => 'unpaid',
            'fiscal_status'   => 'draft',
            'sent'            => 0,
            'paid_amount'     => 0,
        );

        $wpdb->insert($invoices_table, $new_invoice_data);
        $new_invoice_id = $wpdb->insert_id;

        if (!$new_invoice_id) {
            $wpdb->query('ROLLBACK');
            throw new \Exception('Failed to create invoice');
        }

        // Copier les éléments de la facture modèle
        foreach ($template_items as $item) {
            $new_item = array(
                'invoice_id' => $new_invoice_id,
                'item_name' => $item->item_name,
                'item_ref' => $item->item_ref,
                'item_description' => $item->item_description,
                'item_category' => $item->item_category,
                'quantity' => $item->quantity,
                'vat_rate' => $item->vat_rate,
                'unit_price' => $item->unit_price,
                'discount' => $item->discount,
                'total_price' => $item->total_price,
                'total_amount' => $item->total_amount,
                'item_order' => $item->item_order,
            );

            if ($wpdb->insert($invoice_elements_table, $new_item) === false) {
                $wpdb->query('ROLLBACK');
                throw new \Exception('Failed to copy invoice items');
            }
        }

        $wpdb->query('COMMIT');

        $this->last_generated_invoice_id = $new_invoice_id;

        // Envoyer une notification si configurée
        if ($recurring->notification_days_before > 0) {
            $this->send_notification($recurring, $new_invoice_id);
        }
    }

    /**
     * Générer une facture brouillon sans modèle.
     * Crée une facture vide (aucun article) en statut brouillon afin que
     * l'utilisateur puisse la compléter manuellement.
     */
    private function generate_basic_invoice($recurring)
    {
        global $wpdb;

        $invoices_table = ECWP_TABLE_INVOICES;
        $settings_table = ECWP_TABLE_SETTINGS;
        $encrypt        = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        $invoice_prefix        = sanitize_text_field(
            $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$settings_table} WHERE meta_key = %s", 'invoice_prefix')) ?: 'INV'
        );
        $invoice_number_format = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$settings_table} WHERE meta_key = %s", 'invoice_number_format')) ?: 'prefix';

        $wpdb->query('START TRANSACTION');

        $last_seq = (int) $wpdb->get_var("SELECT MAX(number) FROM {$invoices_table} FOR UPDATE");
        $new_seq  = $last_seq + 1;
        $invoice_number_plain = $this->build_invoice_number($invoice_prefix, $invoice_number_format, $invoices_table, $new_seq);

        $zero = $encrypt->encrypt('0');
        $now  = current_time('Y-m-d H:i:s');

        $new_invoice_data = array(
            'number'          => $new_seq,
            'invoice_number'  => $encrypt->encrypt($invoice_number_plain),
            'client_id'       => $recurring->client_id,
            'total_amount'    => $zero,
            'amount'          => $zero,
            'subtotal'        => $zero,
            'tax'             => $zero,
            'transaction_type'=> 'B2B',
            'created_at'      => $now,
            'invoice_date'    => wp_date('Y-m-d'),
            'due_date'        => $this->calculate_due_date($recurring),
            'status'          => $encrypt->encrypt('draft'),
            'status_stats'    => 'draft',
            'fiscal_status'   => 'draft',
            'sent'            => 0,
            'paid_amount'     => 0,
        );

        $wpdb->insert($invoices_table, $new_invoice_data);
        $new_invoice_id = $wpdb->insert_id;

        if (!$new_invoice_id) {
            $wpdb->query('ROLLBACK');
            throw new \Exception('Failed to create basic invoice');
        }

        $wpdb->query('COMMIT');
        $this->last_generated_invoice_id = $new_invoice_id;
    }

    /**
     * Calculer la date d'échéance
     */
    private function calculate_due_date($recurring)
    {
        // Utiliser les conditions de paiement par défaut du plugin
        $settings = new \ECWP\Admin\Settings\ECWP_Settings();
        $payment_conditions = $settings->get_setting('payment_conditions');
        
        // Par défaut, 30 jours
        $days = 30;
        if (!empty($payment_conditions)) {
            // Extraire le nombre de jours si présent
            if (preg_match('/(\d+)/', $payment_conditions, $matches)) {
                $days = intval($matches[1]);
            }
        }

        $due_date = wp_date('Y-m-d', strtotime("+{$days} days"));
        return $due_date;
    }

    /**
     * Mettre à jour la date de prochaine génération
     */
    private function update_next_generation_date($recurring)
    {
        $table = ECWP_TABLE_RECURRING_INVOICES;
        $next_date = $this->calculate_next_generation_date($recurring);

        $this->wpdb->update(
            $table,
            array(
                'next_generation_date' => $next_date,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $recurring->id),
            array('%s', '%s'),
            array('%d')
        );
    }

    /**
     * Calculer la prochaine date de génération
     */
    private function calculate_next_generation_date($recurring)
    {
        $current_date = $recurring->next_generation_date;
        
        switch ($recurring->frequency) {
            case 'monthly':
                return wp_date('Y-m-d', strtotime($current_date . ' +1 month'));

            case 'quarterly':
                return wp_date('Y-m-d', strtotime($current_date . ' +3 months'));

            case 'semi_annual':
                return wp_date('Y-m-d', strtotime($current_date . ' +6 months'));

            case 'annual':
                return wp_date('Y-m-d', strtotime($current_date . ' +1 year'));

            case 'custom':
                if (!empty($recurring->custom_days)) {
                    return wp_date('Y-m-d', strtotime($current_date . ' +' . $recurring->custom_days . ' days'));
                }
                break;
        }

        // Par défaut, mensuel
        return wp_date('Y-m-d', strtotime($current_date . ' +1 month'));
    }

    /**
     * Enregistrer la génération dans l'historique
     */
    private function log_generation($recurring_id, $invoice_id, $status, $error_message = null)
    {
        $table = ECWP_TABLE_RECURRING_INVOICES_HISTORY;

        $this->wpdb->insert($table, array(
            'recurring_invoice_id' => $recurring_id,
            'generated_invoice_id' => $invoice_id,
            'generation_date' => current_time('mysql'),
            'scheduled_date' => current_time('Y-m-d'),
            'status' => $status,
            'error_message' => $error_message,
            'created_at' => current_time('mysql'),
        ));
    }

    /**
     * Envoyer une notification (legacy hook – kept for third-party compatibility).
     */
    private function send_notification($recurring, $invoice_id)
    {
        do_action('ecwp_recurring_invoice_generated', $recurring, $invoice_id);
    }

    /**
     * Send admin + client email after a recurring invoice is generated.
     * Only fires when the ecwp_recurring_notify_on_generation option is '1'.
     */
    private function maybe_send_generation_email($recurring, $invoice_id): void
    {
        if (get_option('ecwp_recurring_notify_on_generation', '1') !== '1') {
            return;
        }

        // Fetch client email
        $client_email = '';
        if (!empty($recurring->client_id)) {
            $client_row = $this->wpdb->get_row(
                $this->wpdb->prepare("SELECT email FROM " . ECWP_TABLE_CLIENTS . " WHERE id = %d", $recurring->client_id)
            );
            if ($client_row) {
                $encrypt      = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
                $client_email = $encrypt->decrypt($client_row->email);
            }
        }

        $site_name   = get_bloginfo('name') ?: 'myEasyCompta';
        $admin_email = get_option('admin_email');
        $subject     = sprintf('[%s] Facture récurrente générée — #%d', $site_name, $invoice_id);

        $body  = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="font-family:Arial,sans-serif;background:#f8fafc;padding:32px">';
        $body .= '<div style="max-width:560px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08)">';
        $body .= '<div style="background:linear-gradient(135deg,#7c3aed,#4f46e5);padding:28px 36px">';
        $body .= '<h1 style="color:white;font-size:20px;font-weight:900;margin:0">⚡ myEasyCompta</h1></div>';
        $body .= '<div style="padding:32px 36px">';
        $body .= '<h2 style="font-size:17px;font-weight:800;color:#1e293b;margin:0 0 12px">Facture récurrente générée</h2>';
        $body .= '<p style="color:#475569;font-size:14px;line-height:1.6;margin:0 0 20px">Une nouvelle facture a été générée automatiquement.</p>';
        $body .= '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px 20px;margin-bottom:20px">';
        $body .= '<p style="margin:0 0 6px;font-size:13px;color:#64748b">Règle récurrente : <strong style="color:#1e293b">' . esc_html($recurring->name ?? 'N/A') . '</strong></p>';
        $body .= '<p style="margin:0;font-size:13px;color:#64748b">ID de facture générée : <strong style="color:#7c3aed">#' . (int) $invoice_id . '</strong></p>';
        $body .= '</div>';
        $body .= '<p style="color:#94a3b8;font-size:12px;margin:0">Généré le ' . wp_date('d/m/Y à H:i') . '</p>';
        $body .= '</div></div></body></html>';

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $site_name . ' <' . $admin_email . '>',
        ];

        // Always notify admin
        wp_mail($admin_email, $subject, $body, $headers);

        // Notify client if we have their email and it differs from admin
        if ($client_email && is_email($client_email) && $client_email !== $admin_email) {
            wp_mail($client_email, $subject, $body, $headers);
        }
    }
}

