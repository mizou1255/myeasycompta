<?php

namespace ECWP\Recurring\Modules;

use ECWP\API\Routes;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

class ECWPRecurring_Invoices
{
    protected $routes;
    protected $wpdb;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    /**
     * Enregistrer les routes API REST
     */
    public function register_api_routes()
    {
        // Liste des factures récurrentes
        $this->routes->add_route('recurring-invoices', 'GET', $this, 'get_recurring_invoices', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Détails d'une facture récurrente
        $this->routes->add_route('recurring-invoices/(?P<id>\d+)', 'GET', $this, 'get_recurring_invoice', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Créer une facture récurrente
        $this->routes->add_route('recurring-invoices', 'POST', $this, 'create_recurring_invoice', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Mettre à jour une facture récurrente
        $this->routes->add_route('recurring-invoices/(?P<id>\d+)', 'PUT', $this, 'update_recurring_invoice', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Supprimer une facture récurrente
        $this->routes->add_route('recurring-invoices/(?P<id>\d+)', 'DELETE', $this, 'delete_recurring_invoice', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Pause/Reprendre une facture récurrente
        $this->routes->add_route('recurring-invoices/(?P<id>\d+)/toggle-pause', 'POST', $this, 'toggle_pause_recurring_invoice', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Historique des générations
        $this->routes->add_route('recurring-invoices/(?P<id>\d+)/history', 'GET', $this, 'get_generation_history', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Générer manuellement (rattraper toutes les manquées pour une règle)
        $this->routes->add_route('recurring-invoices/(?P<id>\d+)/generate', 'POST', $this, 'generate_invoice_manually', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Déclencher le cron maintenant (rattraper toutes les règles en retard)
        $this->routes->add_route('recurring-invoices/run-cron', 'POST', $this, 'run_cron_now', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        // Paramètres de notification
        $this->routes->add_route('recurring-invoices/settings', 'GET', $this, 'get_recurring_settings', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });
        $this->routes->add_route('recurring-invoices/settings', 'POST', $this, 'save_recurring_settings', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        $this->routes->register_routes();
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    /**
     * Récupérer la liste des factures récurrentes
     */
    public function get_recurring_invoices(WP_REST_Request $request)
    {
        $table = ECWP_TABLE_RECURRING_INVOICES;
        $clients_table = ECWP_TABLE_CLIENTS;

        $recurring_invoices = $this->wpdb->get_results(
            "SELECT 
                r.*,
                c.company_name as client_name
            FROM {$table} r
            LEFT JOIN {$clients_table} c ON r.client_id = c.id
            ORDER BY r.created_at DESC",
            OBJECT
        );

        return new WP_REST_Response($recurring_invoices, 200);
    }

    /**
     * Récupérer les détails d'une facture récurrente
     */
    public function get_recurring_invoice(WP_REST_Request $request)
    {
        $id = absint($request['id']);
        $table = ECWP_TABLE_RECURRING_INVOICES;
        $clients_table = ECWP_TABLE_CLIENTS;

        $recurring = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT 
                    r.*,
                    c.company_name as client_name
                FROM {$table} r
                LEFT JOIN {$clients_table} c ON r.client_id = c.id
                WHERE r.id = %d",
                $id
            ),
            OBJECT
        );

        if (!$recurring) {
            return new WP_Error('recurring_not_found', __('Recurring invoice not found', 'my-easy-compta-recurring-invoices'), array('status' => 404));
        }

        return new WP_REST_Response($recurring, 200);
    }

    /**
     * Créer une nouvelle facture récurrente
     */
    public function create_recurring_invoice(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta-recurring-invoices'), array('status' => 403));
        }

        $params = $request->get_json_params();

        // Validation des données
        $required_fields = ['name', 'client_id', 'frequency', 'start_date', 'next_generation_date'];
        foreach ($required_fields as $field) {
            if (empty($params[$field])) {
                return new WP_Error('missing_field', sprintf(__('Field %s is required', 'my-easy-compta-recurring-invoices'), $field), array('status' => 400));
            }
        }

        $table = ECWP_TABLE_RECURRING_INVOICES;

        $data = array(
            'name' => sanitize_text_field($params['name']),
            'client_id' => absint($params['client_id']),
            'template_invoice_id' => !empty($params['template_invoice_id']) ? absint($params['template_invoice_id']) : null,
            'frequency' => sanitize_text_field($params['frequency']),
            'custom_days' => !empty($params['custom_days']) ? absint($params['custom_days']) : null,
            'start_date' => sanitize_text_field($params['start_date']),
            'end_date' => !empty($params['end_date']) ? sanitize_text_field($params['end_date']) : null,
            'next_generation_date' => sanitize_text_field($params['next_generation_date']),
            'is_active' => isset($params['is_active']) ? (int) $params['is_active'] : 1,
            'is_paused' => isset($params['is_paused']) ? (int) $params['is_paused'] : 0,
            'notification_days_before' => !empty($params['notification_days_before']) ? absint($params['notification_days_before']) : 0,
            'created_at' => current_time('mysql'),
        );

        $result = $this->wpdb->insert($table, $data);

        if ($result === false) {
            return new WP_Error('creation_failed', __('Failed to create recurring invoice', 'my-easy-compta-recurring-invoices'), array('status' => 500));
        }

        $id = $this->wpdb->insert_id;
        return new WP_REST_Response(array('success' => true, 'id' => $id, 'message' => __('Recurring invoice created successfully', 'my-easy-compta-recurring-invoices')), 201);
    }

    /**
     * Mettre à jour une facture récurrente
     */
    public function update_recurring_invoice(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta-recurring-invoices'), array('status' => 403));
        }

        $id = absint($request['id']);
        $params = $request->get_json_params();
        $table = ECWP_TABLE_RECURRING_INVOICES;

        // Vérifier que la facture récurrente existe
        $existing = $this->wpdb->get_var($this->wpdb->prepare("SELECT id FROM {$table} WHERE id = %d", $id));
        if (!$existing) {
            return new WP_Error('recurring_not_found', __('Recurring invoice not found', 'my-easy-compta-recurring-invoices'), array('status' => 404));
        }

        $data = array();
        $format = array();

        if (isset($params['name'])) {
            $data['name'] = sanitize_text_field($params['name']);
            $format[] = '%s';
        }
        if (isset($params['client_id'])) {
            $data['client_id'] = absint($params['client_id']);
            $format[] = '%d';
        }
        if (isset($params['template_invoice_id'])) {
            $data['template_invoice_id'] = !empty($params['template_invoice_id']) ? absint($params['template_invoice_id']) : null;
            $format[] = '%d';
        }
        if (isset($params['frequency'])) {
            $data['frequency'] = sanitize_text_field($params['frequency']);
            $format[] = '%s';
        }
        if (isset($params['custom_days'])) {
            $data['custom_days'] = !empty($params['custom_days']) ? absint($params['custom_days']) : null;
            $format[] = '%d';
        }
        if (isset($params['start_date'])) {
            $data['start_date'] = sanitize_text_field($params['start_date']);
            $format[] = '%s';
        }
        if (isset($params['end_date'])) {
            $data['end_date'] = !empty($params['end_date']) ? sanitize_text_field($params['end_date']) : null;
            $format[] = '%s';
        }
        if (isset($params['next_generation_date'])) {
            $data['next_generation_date'] = sanitize_text_field($params['next_generation_date']);
            $format[] = '%s';
        }
        if (isset($params['is_active'])) {
            $data['is_active'] = (int) $params['is_active'];
            $format[] = '%d';
        }
        if (isset($params['is_paused'])) {
            $data['is_paused'] = (int) $params['is_paused'];
            $format[] = '%d';
        }
        if (isset($params['notification_days_before'])) {
            $data['notification_days_before'] = absint($params['notification_days_before']);
            $format[] = '%d';
        }

        $data['updated_at'] = current_time('mysql');
        $format[] = '%s';

        $result = $this->wpdb->update(
            $table,
            $data,
            array('id' => $id),
            $format,
            array('%d')
        );

        if ($result === false) {
            return new WP_Error('update_failed', __('Failed to update recurring invoice', 'my-easy-compta-recurring-invoices'), array('status' => 500));
        }

        return new WP_REST_Response(array('success' => true, 'message' => __('Recurring invoice updated successfully', 'my-easy-compta-recurring-invoices')), 200);
    }

    /**
     * Supprimer une facture récurrente
     */
    public function delete_recurring_invoice(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta-recurring-invoices'), array('status' => 403));
        }

        $id = absint($request['id']);
        $table = ECWP_TABLE_RECURRING_INVOICES;

        $result = $this->wpdb->delete($table, array('id' => $id), array('%d'));

        if ($result === false) {
            return new WP_Error('delete_failed', __('Failed to delete recurring invoice', 'my-easy-compta-recurring-invoices'), array('status' => 500));
        }

        return new WP_REST_Response(array('success' => true, 'message' => __('Recurring invoice deleted successfully', 'my-easy-compta-recurring-invoices')), 200);
    }

    /**
     * Pause/Reprendre une facture récurrente
     */
    public function toggle_pause_recurring_invoice(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta-recurring-invoices'), array('status' => 403));
        }

        $id = absint($request['id']);
        $table = ECWP_TABLE_RECURRING_INVOICES;

        $recurring = $this->wpdb->get_row($this->wpdb->prepare("SELECT is_paused FROM {$table} WHERE id = %d", $id), OBJECT);

        if (!$recurring) {
            return new WP_Error('recurring_not_found', __('Recurring invoice not found', 'my-easy-compta-recurring-invoices'), array('status' => 404));
        }

        // Convertir en int pour s'assurer que la comparaison fonctionne
        // is_paused peut être 0, 1, '0', '1', ou null
        $current_pause_status = (int) $recurring->is_paused;
        $new_pause_status = ($current_pause_status == 1) ? 0 : 1;

        $result = $this->wpdb->update(
            $table,
            array('is_paused' => $new_pause_status, 'updated_at' => current_time('mysql')),
            array('id' => $id),
            array('%d', '%s'),
            array('%d')
        );

        if ($result === false) {
            return new WP_Error('update_failed', __('Failed to toggle pause status', 'my-easy-compta-recurring-invoices'), array('status' => 500));
        }

        // Vérifier que la mise à jour a bien été effectuée en récupérant toutes les données
        $updated = $this->wpdb->get_row($this->wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id), OBJECT);
        if (!$updated) {
            return new WP_Error('verification_failed', __('Failed to verify update', 'my-easy-compta-recurring-invoices'), array('status' => 500));
        }

        $final_pause_status = (int) $updated->is_paused;

        $message = $final_pause_status ? __('Recurring invoice paused', 'my-easy-compta-recurring-invoices') : __('Recurring invoice resumed', 'my-easy-compta-recurring-invoices');
        return new WP_REST_Response(array(
            'success' => true,
            'is_paused' => $final_pause_status,
            'message' => $message,
        ), 200);
    }

    /**
     * Récupérer l'historique des générations
     */
    public function get_generation_history(WP_REST_Request $request)
    {
        $id = absint($request['id']);
        $table_history = ECWP_TABLE_RECURRING_INVOICES_HISTORY;
        $table_invoices = ECWP_TABLE_INVOICES;

        $history = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT
                    h.*,
                    i.invoice_number
                FROM {$table_history} h
                LEFT JOIN {$table_invoices} i ON h.generated_invoice_id = i.id
                WHERE h.recurring_invoice_id = %d
                ORDER BY h.generation_date DESC",
                $id
            ),
            OBJECT
        );

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
        foreach ($history as $item) {
            if (!empty($item->invoice_number)) {
                $item->invoice_number = $encrypt->decrypt($item->invoice_number);
            }
        }

        return new WP_REST_Response($history, 200);
    }

    /**
     * Générer manuellement une facture
     */
    public function generate_invoice_manually(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta-recurring-invoices'), array('status' => 403));
        }

        $id = absint($request['id']);
        $table = ECWP_TABLE_RECURRING_INVOICES;

        $recurring = $this->wpdb->get_row(
            $this->wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id),
            OBJECT
        );

        if (!$recurring) {
            return new WP_Error('recurring_not_found', __('Recurring invoice not found', 'my-easy-compta-recurring-invoices'), array('status' => 404));
        }

        // Rattraper toutes les factures manquées pour cette règle
        $cron = new ECWPRecurring_Cron();
        $generated = $cron->generate_all_missed_for_recurring($recurring);

        if ($generated > 0) {
            return new WP_REST_Response(array(
                'success'   => true,
                'generated' => $generated,
                'message'   => sprintf(
                    _n('%d facture générée', '%d factures générées', $generated, 'my-easy-compta-recurring-invoices'),
                    $generated
                ),
            ), 200);
        } else {
            // Rien à rattraper — générer quand même une facture forcée
            $result = $cron->generate_invoice_from_recurring($recurring);
            if ($result) {
                return new WP_REST_Response(array('success' => true, 'generated' => 1, 'message' => __('Facture générée', 'my-easy-compta-recurring-invoices')), 200);
            }
            return new WP_Error('generation_failed', __('Failed to generate invoice', 'my-easy-compta-recurring-invoices'), array('status' => 500));
        }
    }

    /**
     * Déclencher manuellement le cron pour toutes les règles en retard.
     */
    public function run_cron_now(WP_REST_Request $request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta-recurring-invoices'), array('status' => 403));
        }

        $cron = new ECWPRecurring_Cron();
        $cron->check_and_generate_invoices();

        return new WP_REST_Response(array(
            'success' => true,
            'message' => __('Vérification et génération effectuées.', 'my-easy-compta-recurring-invoices'),
        ), 200);
    }

    public function get_recurring_settings(\WP_REST_Request $request): \WP_REST_Response
    {
        return new \WP_REST_Response([
            'notify_on_generation' => get_option('ecwp_recurring_notify_on_generation', '1') === '1',
        ], 200);
    }

    public function save_recurring_settings(\WP_REST_Request $request): \WP_REST_Response|\WP_Error
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('invalid_nonce', __('Nonce invalide', 'my-easy-compta-recurring-invoices'), ['status' => 403]);
        }

        $params = $request->get_json_params();
        $notify = !empty($params['notify_on_generation']) ? '1' : '0';
        update_option('ecwp_recurring_notify_on_generation', $notify);

        return new \WP_REST_Response(['success' => true], 200);
    }
}

