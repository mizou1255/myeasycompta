<?php
/**
 * Plugin Name: myEasyCompta - Recurring Invoices Addon
 * Description: Automate your recurring billing with myEasyCompta Recurring Invoices. Create invoice templates with customizable frequencies (monthly, quarterly, semi-annual, annual, or custom). Automatically generate invoices according to your schedule, manage start/end dates, pause or resume recurrences, and track the history of generated invoices. Perfect for subscriptions and recurring services.
 * Version: 2.0.0
 * Author: MELIOZ.dev
 * Author URI: https://myeasycompta.com
 * Text Domain: my-easy-compta-recurring-invoices
 * Domain Path: /languages/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.2
 * Tested up to: 6.7
 * Requires PHP: 8.0
 * Tags: accounting, invoices, recurring, automation, subscriptions
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ECWP_Easy_Compta_Recurring_Invoices
{
    /**
     * Version du plugin
     *
     * @var string
     */
    public $version = '2.0.0';

    /**
     * Version PHP minimale requise
     *
     * @var string
     */
    private $min_php = '8.0';

    /**
     * Conteneur pour les instances de classe
     *
     * @var array
     */
    private $container = [];

    /**
     * Instance singleton
     *
     * @var ECWP_Easy_Compta_Recurring_Invoices
     */
    private static $instance;

    /**
     * Initialisation du plugin
     *
     * @return ECWP_Easy_Compta_Recurring_Invoices
     */
    public static function init()
    {
        if (!isset(self::$instance) && !(self::$instance instanceof ECWP_Easy_Compta_Recurring_Invoices)) {
            self::$instance = new ECWP_Easy_Compta_Recurring_Invoices();
            self::$instance->setup();
        }

        return self::$instance;
    }

    /**
     * Configuration initiale du plugin
     *
     * @return void
     */
    private function setup()
    {
        register_activation_hook(__FILE__, [$this, 'auto_deactivate']);

        if (!$this->is_supported_php()) {
            return;
        }

        $this->define_constants();
        $this->includes();
        $this->instantiate();
        $this->init_actions();
    }

    /**
     * Définir les constantes du plugin
     *
     * @return void
     */
    private function define_constants()
    {
        global $wpdb;
        
        define('ECWP_RECURRING_PATH', dirname(__FILE__));
        define('ECWP_RECURRING_INCLUDES', ECWP_RECURRING_PATH . '/includes');
        define('ECWP_RECURRING_PATH_DIR', plugin_dir_path(__FILE__));
        define('ECWP_RECURRING_URL', plugins_url('', __FILE__));
        define('ECWP_RECURRING_ASSETS', ECWP_RECURRING_URL . '/assets');
        
        if (!defined('ECWP_PRINCIPAL_PATH')) {
            define('ECWP_PRINCIPAL_PATH', WP_CONTENT_DIR . '/plugins/my-easy-compta');
        }
        if (!defined('ECWP_PREFIX')) {
            define('ECWP_PREFIX', $wpdb->prefix);
        }

        define('ECWP_RECURRING_SETTINGS_VAR', 'easy_compta_recurring_invoices_addon_active');
        define('ECWP_TABLE_RECURRING_INVOICES', ECWP_PREFIX . 'ecwp_recurring_invoices');
        define('ECWP_TABLE_RECURRING_INVOICES_HISTORY', ECWP_PREFIX . 'ecwp_recurring_invoices_history');
    }

    /**
     * Inclure les fichiers requis
     *
     * @return void
     */
    private function includes()
    {
        require_once ECWP_PRINCIPAL_PATH . '/includes/API/Routes.php';
        require_once ECWP_RECURRING_INCLUDES . '/Migrations/migrations.php';
        require_once ECWP_RECURRING_INCLUDES . '/Modules/App.php';
        require_once ECWP_RECURRING_INCLUDES . '/Modules/RecurringInvoices.php';
        require_once ECWP_RECURRING_INCLUDES . '/Modules/Cron.php';
    }

    /**
     * Instancier les classes nécessaires
     *
     * @return void
     */
    private function instantiate()
    {
        $this->container['migration'] = new ECWP\Recurring\Migrations\ECWPRecurring_Migrations();
        $this->container['app'] = new ECWP\Recurring\Modules\ECWPRecurring_APP();
        $this->container['recurring'] = new ECWP\Recurring\Modules\ECWPRecurring_Invoices();
        $this->container['cron'] = new ECWP\Recurring\Modules\ECWPRecurring_Cron();
    }

    /**
     * Initialiser les hooks d'action WordPress
     *
     * @return void
     */
    private function init_actions()
    {
        register_activation_hook(__FILE__, [$this->container['migration'], 'plugin_activation']);
        register_deactivation_hook(__FILE__, [$this->container['migration'], 'plugin_deactivation']);
        add_action('admin_init', [$this, 'check_plugin_dependencies']);

        // Ensure the daily cron is always scheduled (handles upgrades where
        // the activation hook doesn't fire again).
        add_action('admin_init', function () {
            if (!wp_next_scheduled('ecwp_recurring_invoices_daily_check')) {
                wp_schedule_event(time(), 'daily', 'ecwp_recurring_invoices_daily_check');
            }
        });
    }

    /**
     * Vérifier si la version PHP est supportée
     *
     * @return bool
     */
    public function is_supported_php()
    {
        return version_compare(PHP_VERSION, $this->min_php, '>=');
    }

    /**
     * Désactiver le plugin si la version PHP n'est pas supportée
     *
     * @return void
     */
    public function auto_deactivate()
    {
        if (!$this->is_supported_php()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'Le plugin %s nécessite PHP version %s ou supérieure.',
                        'my-easy-compta-recurring-invoices'
                    ),
                    esc_html__('myEasyCompta Recurring Invoices addon', 'my-easy-compta-recurring-invoices'),
                    esc_html($this->min_php)
                ),
                esc_html__('Erreur d\'activation du plugin', 'my-easy-compta-recurring-invoices'),
                ['response' => 200, 'back_link' => true]
            );
        }
        if (!is_plugin_active('my-easy-compta/my-easy-compta.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires the myEasyCompta plugin to be active.',
                        'my-easy-compta-recurring-invoices'
                    ),
                    esc_html__('myEasyCompta Recurring Invoices', 'my-easy-compta-recurring-invoices')
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta-recurring-invoices'),
                ['response' => 200, 'back_link' => true]
            );
        }
    }

    /**
     * Check if myEasyCompta plugin are activated
     */
    public function check_plugin_dependencies()
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            add_action('admin_notices', [$this, 'display_missing_dependencies_notice']);
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }

    /**
     * Display a notice if myEasyCompta plugin are not activated
     */
    public function display_missing_dependencies_notice()
    {
        ?>
<div class="notice notice-error is-dismissible">
    <p><?php _e('myEasyCompta Recurring Invoices requires the myEasyCompta plugin to be activated. Please activate it before activating this plugin.', 'my-easy-compta-recurring-invoices');?>
    </p>
</div>
<?php
    }
}

/**
 * Initialiser le plugin myEasyCompta Recurring Invoices
 *
 * @return ECWP_Easy_Compta_Recurring_Invoices
 */
ECWP_Easy_Compta_Recurring_Invoices::init();






