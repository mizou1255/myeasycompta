<?php

namespace ECWP\Stats;

use ECWP\Admin\Settings\ECWP_Settings;
use ECWP\API\Routes;

class ECWPStats_Stats
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/stats-addon', 'GET', $this, 'get_stats', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });
        $this->routes->add_route('/stats-trimestre', 'GET', $this, 'get_quarterly_stats', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });
        $this->routes->add_route('/stats-addon/monthly-payments', 'GET', $this, 'get_monthly_payments', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });
        $this->routes->add_route('/stats-addon/available-years', 'GET', $this, 'get_available_years', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });
        $this->routes->add_route('/stats-addon/payment-percentage', 'GET', $this, 'get_payment_percentage', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });
        $this->routes->add_route('/stats-addon/top-clients', 'GET', $this, 'get_top_clients', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });
        $this->routes->add_route('/stats-addon/unpaid-by-month', 'GET', $this, 'get_unpaid_by_month', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        $this->routes->register_routes();
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    public function get_stats($request)
    {
        global $wpdb;
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;

        $total_sales = $wpdb->get_var("SELECT SUM(amount) FROM " . ECWP_TABLE_PAYMENTS);
        $paid_this_month = $wpdb->get_var($wpdb->prepare("SELECT SUM(amount) FROM %i WHERE YEAR(payment_date) = %d AND MONTH(payment_date) = %d", ECWP_TABLE_PAYMENTS, (int) current_time('Y'), (int) current_time('m')));
        $paid_this_year = $wpdb->get_var($wpdb->prepare("SELECT SUM(amount) FROM %i WHERE YEAR(payment_date) = %d", ECWP_TABLE_PAYMENTS, (int) current_time('Y')));
        $paid_last_month = $wpdb->get_var($wpdb->prepare("SELECT SUM(amount) FROM %i WHERE YEAR(payment_date) = %d AND MONTH(payment_date) = %d", ECWP_TABLE_PAYMENTS, (int) wp_date('Y', strtotime('-1 month')), (int) wp_date('m', strtotime('-1 month'))));
        $payments_received = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i", ECWP_TABLE_PAYMENTS));
        $total_invoices = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i", ECWP_TABLE_INVOICES));
        // Use status_stats (plaintext) for efficient DB-side filtering
        $unpaid_invoices_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM %i WHERE status_stats IN ('unpaid', 'partial')",
            ECWP_TABLE_INVOICES
        ));

        // Sum remaining balance: total_amount is encrypted, use (total_amount - paid_amount) approach
        // We fetch minimal data and decrypt only what's needed
        $unpaid_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT total_amount, paid_amount FROM %i WHERE status_stats IN ('unpaid', 'partial')",
            ECWP_TABLE_INVOICES
        ));
        $total_unpaid_amount = 0;
        foreach ($unpaid_rows as $row) {
            $total = floatval($encrypt->decrypt($row->total_amount));
            $paid  = floatval($row->paid_amount);
            $total_unpaid_amount += max(0, $total - $paid);
        }

        $invoices_past_due_date = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM %i WHERE status_stats IN ('unpaid', 'partial') AND due_date < NOW()",
            ECWP_TABLE_INVOICES
        ));

        $current_year = (int) current_time('Y');
        $previous_year = $current_year - 1;
        $current_month = (int) current_time('m');
        $current_year_vat = $this->calculateYearlyOrMonthlyVat($current_year);
        $last_year_vat = $this->calculateYearlyOrMonthlyVat($previous_year);

        $monthly_vat = $this->calculateYearlyOrMonthlyVat($current_year, $current_month);
        $total_vat = $this->calculateTotalVat();

        $settings = new ECWP_Settings();
        $default_currency_id = $settings->get_setting('default_currency');
        $limit_declaration = $settings->get_setting('limit_declaration');
        $limit_tva = $settings->get_setting('limit_tva');

        $default_currency_symbol = $wpdb->get_row(
            $wpdb->prepare("SELECT symbol FROM %i WHERE id = %d", ECWP_TABLE_CURRENCY, $default_currency_id)
        );

        $stats_annual_target = floatval($settings->get_setting('stats_annual_target') ?: 0);
        $stats_fiscal_year_start = absint($settings->get_setting('stats_fiscal_year_start') ?: 1);

        // Gross margin: revenue this year − expenses this year
        $total_expenses_this_year = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT SUM(amount) FROM %i WHERE YEAR(expense_date) = %d",
            ECWP_TABLE_EXPENSES,
            $current_year
        )));
        $gross_margin = floatval($paid_this_year) - $total_expenses_this_year;

        // Conversion rate: accepted quotes / total quotes
        $total_quotes  = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i", ECWP_TABLE_QUOTES));
        $accepted_quotes = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM %i WHERE status_stats = 'accepted'",
            ECWP_TABLE_QUOTES
        ));
        $conversion_rate = $total_quotes > 0 ? round($accepted_quotes / $total_quotes * 100, 1) : 0;

        return [
            'total_sales' => $total_sales ? number_format($total_sales, 2) : '0.00',
            'paid_this_month' => $paid_this_month ? number_format($paid_this_month, 2) : '0.00',
            'paid_this_year' => $paid_this_year ? $paid_this_year : '0',
            'paid_last_month' => $paid_last_month ? number_format($paid_last_month, 2) : '0.00',
            'payments_received' => $payments_received ? $payments_received : 0,
            'total_invoices' => $total_invoices ? $total_invoices : 0,
            'unpaid_invoices_count' => $unpaid_invoices_count ? $unpaid_invoices_count : 0,
            'total_unpaid_amount' => $total_unpaid_amount ? number_format($total_unpaid_amount, 2) : '0.00',
            'invoices_past_due_date' => $invoices_past_due_date ? $invoices_past_due_date : 0,
            'total_vat' => $total_vat ? number_format($total_vat, 2) : '0.00',
            'monthly_vat' => $monthly_vat ? number_format($monthly_vat, 2) : '0.00',
            'current_year_vat' => $current_year_vat ? number_format($current_year_vat, 2) : '0.00',
            'last_year_vat' => $last_year_vat ? number_format($last_year_vat, 2) : '0.00',
            'default_currency_symbol' => $default_currency_symbol ? $default_currency_symbol->symbol : '€',
            'limit_declaration' => $limit_declaration,
            'limit_tva' => $limit_tva,
            'stats_annual_target' => $stats_annual_target,
            'stats_fiscal_year_start' => $stats_fiscal_year_start,
            'gross_margin' => number_format($gross_margin, 2),
            'conversion_rate' => $conversion_rate,
        ];
    }

    private function calculateYearlyOrMonthlyVat($year, $month = null)
    {
        global $wpdb;
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;
        $sql = "
            SELECT elements.total_amount, elements.vat_rate
            FROM %i AS elements
            JOIN %i AS invoices
            ON elements.invoice_id = invoices.id
            WHERE invoices.status_stats = 'paid'
            AND YEAR(invoices.created_at) = %d";

        if ($month !== null) {
            $sql .= " AND MONTH(invoices.created_at) = %d";
            $query = $wpdb->prepare($sql, ECWP_TABLE_INVOICE_ELEMENTS, ECWP_TABLE_INVOICES, $year, $month);
        } else {
            $query = $wpdb->prepare($sql, ECWP_TABLE_INVOICE_ELEMENTS, ECWP_TABLE_INVOICES, $year);
        }

        $invoice_elements = $wpdb->get_results($query);
        $yearly_vat = 0;

        foreach ($invoice_elements as $element) {
            $total_amount = floatval($encrypt->decrypt($element->total_amount));
            $vat_rate = floatval($element->vat_rate);

            if ($vat_rate > 0) {
                $vat_exclusive_amount = $total_amount / (1 + $vat_rate / 100);
                $yearly_vat += $total_amount - $vat_exclusive_amount;
            }
        }

        return $yearly_vat;
    }

    private function calculateTotalVat()
    {
        global $wpdb;
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;
        $sql = "
        SELECT elements.total_amount, elements.vat_rate
        FROM %i AS elements
        JOIN %i AS invoices
        ON elements.invoice_id = invoices.id
        WHERE invoices.status_stats = 'paid'
    ";

        $query = $wpdb->prepare($sql, ECWP_TABLE_INVOICE_ELEMENTS, ECWP_TABLE_INVOICES);

        $invoice_elements = $wpdb->get_results($query);

        $total_vat = 0;

        foreach ($invoice_elements as $element) {
            $total_amount = floatval($encrypt->decrypt($element->total_amount));
            $vat_rate = floatval($element->vat_rate);

            if ($vat_rate > 0) {
                $vat_exclusive_amount = $total_amount / (1 + $vat_rate / 100);
                $total_vat += $total_amount - $vat_exclusive_amount;
            }
        }

        return $total_vat;
    }

    public function get_monthly_payments($request)
    {
        global $wpdb;
        $params = $request->get_params();
        $year = absint($params['year']);

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT MONTH(payment_date) as month, SUM(amount) as total
             FROM %i
             WHERE YEAR(payment_date) = %d
             GROUP BY MONTH(payment_date)",
            ECWP_TABLE_PAYMENTS,
            $year
        ));

        $months = [];
        $payments = [];

        for ($i = 1; $i <= 12; $i++) {
            $months[] = wp_date('F', mktime(0, 0, 0, $i, 1));
            $payments[] = 0;
        }

        foreach ($results as $result) {
            $payments[$result->month - 1] = $result->total;
        }

        return [
            'months' => $months,
            'payments' => $payments,
        ];
    }

    public function get_available_years()
    {
        global $wpdb;

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DISTINCT YEAR(payment_date) as year
             FROM %i
             ORDER BY year DESC",
                ECWP_TABLE_PAYMENTS
            )
        );

        $years = [];
        foreach ($results as $result) {
            $years[] = $result->year;
        }

        return $years;
    }

    public function get_payment_percentage($request)
    {
        global $wpdb;
        $year = isset($request['year']) ? absint($request['year']) : (int) current_time('Y');
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT MONTH(payment_date) as month, SUM(amount) as total
             FROM %i
             WHERE YEAR(payment_date) = %d
             GROUP BY MONTH(payment_date)",
            ECWP_TABLE_PAYMENTS,
            $year
        ));

        $total_amount = 0;
        $payment_percentages = array_fill(1, 12, 0);

        foreach ($results as $result) {
            $total_amount += $result->total;
            $payment_percentages[$result->month] = floatval($result->total);
        }

        if ($total_amount > 0) {
            foreach ($payment_percentages as &$percentage) {
                $percentage = round(($percentage / $total_amount) * 100, 2);
            }
        }

        $response = array(
            'months' => range(1, 12),
            'payment_percentages' => array_values($payment_percentages),
            'total_amount' => $total_amount,
        );

        return rest_ensure_response($response);
    }

    public function get_quarterly_stats($request)
    {
        global $wpdb;

        $current_year = isset($request['year']) ? absint($request['year']) : (int) current_time('Y');
        $monthly_sales = [];
        $total_annual_sales = 0;

        for ($month = 1; $month <= 12; $month++) {
            $start_date = "{$current_year}-" . str_pad($month, 2, '0', STR_PAD_LEFT) . "-01";
            $end_date = wp_date("Y-m-t", strtotime($start_date));

            $monthly_amount = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(amount) FROM %i WHERE payment_date >= %s AND payment_date <= %s",
                ECWP_TABLE_PAYMENTS,
                $start_date,
                $end_date
            ));

            $monthly_sales[$month] = $monthly_amount ? floatval($monthly_amount) : 0.00;
            $total_annual_sales += $monthly_sales[$month];
        }

        $q1_total = $monthly_sales[1] + $monthly_sales[2] + $monthly_sales[3];
        $q2_total = $monthly_sales[4] + $monthly_sales[5] + $monthly_sales[6];
        $q3_total = $monthly_sales[7] + $monthly_sales[8] + $monthly_sales[9];
        $q4_total = $monthly_sales[10] + $monthly_sales[11] + $monthly_sales[12];

        $response = [
            'year' => $current_year,
            'january' => $monthly_sales[1],
            'february' => $monthly_sales[2],
            'march' => $monthly_sales[3],
            'april' => $monthly_sales[4],
            'may' => $monthly_sales[5],
            'june' => $monthly_sales[6],
            'july' => $monthly_sales[7],
            'august' => $monthly_sales[8],
            'september' => $monthly_sales[9],
            'october' => $monthly_sales[10],
            'november' => $monthly_sales[11],
            'december' => $monthly_sales[12],
            'q1_total' => $q1_total,
            'q2_total' => $q2_total,
            'q3_total' => $q3_total,
            'q4_total' => $q4_total,
            'annual_total' => $total_annual_sales,
        ];

        return rest_ensure_response($response);
    }

    public function get_top_clients($request)
    {
        global $wpdb;
        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT c.id, c.company_name, SUM(p.amount) as total
             FROM %i AS p
             JOIN %i AS i ON p.invoice_id = i.id
             JOIN %i AS c ON i.client_id = c.id
             GROUP BY i.client_id
             ORDER BY total DESC
             LIMIT 5",
            ECWP_TABLE_PAYMENTS,
            ECWP_TABLE_INVOICES,
            ECWP_TABLE_CLIENTS
        ));

        $clients = [];
        foreach ($rows as $row) {
            $clients[] = [
                'id'           => (int) $row->id,
                'company_name' => $encrypt->decrypt($row->company_name),
                'total'        => number_format(floatval($row->total), 2),
            ];
        }

        return rest_ensure_response($clients);
    }

    public function get_unpaid_by_month($request)
    {
        global $wpdb;
        $encrypt  = new \ECWP\Admin\Encrypt\ECWP_Encrypt;
        $year = isset($request['year']) ? absint($request['year']) : (int) current_time('Y');

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT MONTH(created_at) AS month, total_amount, paid_amount
             FROM %i
             WHERE YEAR(created_at) = %d AND status_stats IN ('unpaid', 'partial')",
            ECWP_TABLE_INVOICES,
            $year
        ));

        $monthly = array_fill(1, 12, 0.0);
        foreach ($rows as $row) {
            $total  = floatval($encrypt->decrypt($row->total_amount));
            $paid   = floatval($row->paid_amount);
            $monthly[(int) $row->month] += max(0, $total - $paid);
        }

        $months_labels = [];
        for ($i = 1; $i <= 12; $i++) {
            $months_labels[] = wp_date('M', mktime(0, 0, 0, $i, 1));
        }

        return rest_ensure_response([
            'months'  => $months_labels,
            'amounts' => array_values($monthly),
        ]);
    }

}