<?php
namespace ECWP\Stats;

class ECWPStats_Migrations
{
    public function plugin_activation()
    {
        //$this->create_stats_log_table();
        $this->database_update();
    }

    public function database_update()
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            'easy_compta_stats_addon_active'
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => 'easy_compta_stats_addon_active',
                'meta_value' => 1,
            ));
        }
    }

    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_stats_addon_active'));
    }

}
