<?php
namespace ECWP\SureCart;

class ECWPSureCart_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
    }

    public function database_update()
    {
        global $wpdb;

        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM %i WHERE meta_key = %s", ECWP_TABLE_SETTINGS,
            'easy_compta_surecart_addon_active'
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => 'easy_compta_surecart_addon_active',
                'meta_value' => 1,
            ));
        }

        $column_source = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM %i LIKE %s",
                ECWP_TABLE_INVOICES, 'source'
            )
        );
        if (empty($column_source)) {
            $wpdb->query(
                $wpdb->prepare(
                    "ALTER TABLE %i ADD COLUMN source VARCHAR(255) DEFAULT 'WooCommerce'",
                    ECWP_TABLE_INVOICES
                )
            );
        }
        $column_order_id = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM %i LIKE %s",
                ECWP_TABLE_INVOICES, 'order_id'
            )
        );
        if (empty($column_order_id)) {
            $wpdb->query(
                $wpdb->prepare(
                    "ALTER TABLE %i ADD COLUMN order_id VARCHAR(255) NOT NULL AFTER `source`",
                    ECWP_TABLE_INVOICES
                )
            );
        }

        $column_shipping_amount = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM %i LIKE %s",
                ECWP_TABLE_INVOICES, 'shipping_amount'
            )
        );
        if (empty($column_shipping_amount)) {
            $wpdb->query(
                $wpdb->prepare(
                    "ALTER TABLE %i ADD COLUMN shipping_amount VARCHAR(255) NOT NULL AFTER `source`",
                    ECWP_TABLE_INVOICES
                )
            );
        }
    }

    public function plugin_deactivation()
    {
        global $wpdb;

        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_surecart_addon_active'));

        $column_source = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM %i LIKE %s",
                ECWP_TABLE_INVOICES, 'source'
            )
        );
        if (!empty($column_source)) {
            $wpdb->query(
                $wpdb->prepare(
                    "ALTER TABLE %i DROP COLUMN source",
                    ECWP_TABLE_INVOICES
                )
            );
        }

        $column_order_id = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM %i LIKE %s",
                ECWP_TABLE_INVOICES, 'order_id'
            )
        );
        if (!empty($column_order_id)) {
            $wpdb->query(
                $wpdb->prepare(
                    "ALTER TABLE %i DROP COLUMN order_id",
                    ECWP_TABLE_INVOICES
                )
            );
        }

        $column_shipping_amount = $wpdb->get_results(
            $wpdb->prepare(
                "SHOW COLUMNS FROM %i LIKE %s",
                ECWP_TABLE_INVOICES, 'shipping_amount'
            )
        );
        if (!empty($column_shipping_amount)) {
            $wpdb->query(
                $wpdb->prepare(
                    "ALTER TABLE %i DROP COLUMN shipping_amount",
                    ECWP_TABLE_INVOICES
                )
            );
        }
    }

}
