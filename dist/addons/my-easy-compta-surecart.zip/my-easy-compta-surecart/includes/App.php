<?php
namespace ECWP\SureCart;

use ECWP\Admin\Settings\ECWP_Settings;
use SureCart\Models\Product;

class ECWPSureCart_APP
{
    public function __construct()
    {
        if ($this->has_valid_license()) {
            add_action('surecart/checkout_confirmed', array($this, 'handle_checkout_confirmation'), 10, 1);
            add_action('externe_article_results', array($this, 'add_surecart_products_to_results'), 10, 2);
        }
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    public function handle_checkout_confirmation($order)
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            return;
        }

        $this->generate_invoice_for_surecart($order);

        $this->update_invoice_status_on_payment_completed($order);
    }

    public function generate_invoice_for_surecart($order)
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            return;
        }
        $order_id = $order->id;
        $currency_code = $order->currency;
        $currency_symbol = strtoupper($currency_code);

        $customer_email = $order->customer->email;
        $company_name = $order->customer->company ?? $order->customer->name;

        $customer_data = [
            'company_name' => $company_name,
            'manager_name' => $order->customer->name,
            'email' => $customer_email,
            'phone' => $order->customer->phone ?? '',
            'address' => $order->customer->shipping_address->line_1 ?? '',
            'city' => $order->customer->shipping_address->city ?? '',
            'postal_code' => $order->customer->shipping_address->postal_code ?? '',
            'country' => $order->customer->shipping_address->country ?? '',
            'currency_id' => 1,
        ];

        global $wpdb;

        $currency_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . ECWP_TABLE_CURRENCY . " WHERE symbol = %s", $currency_symbol));
        if ($currency_id) {
            $customer_data['currency_id'] = $currency_id;
        }

        $client_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . ECWP_TABLE_CLIENTS . " WHERE email = %s", $customer_email));

        if (!$client_id) {
            $wpdb->insert(ECWP_TABLE_CLIENTS, $customer_data);
            $client_id = $wpdb->insert_id;
        }

        $settings = new ECWP_Settings();
        $invoice_prefix = $settings->get_setting('invoice_prefix') ?: 'INV_';

        $total_without_tax = $order->subtotal_amount / 100;
        $total_with_tax = $order->total_amount / 100;

        $invoice_status = ($order->status === 'completed' || $order->status === 'paid') ? 'paid' : 'unpaid';
        $due_date = ($invoice_status === 'paid') ? current_time('mysql') : wp_date('Y-m-d H:i:s', strtotime('+1 week'));

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        $default_vat_rate = 0;
        $vat_active = $settings->get_setting('vat_active');
        if ($vat_active == 1) {
            $default_vat_id = $settings->get_setting('default_vat');
            $default_vat_rate = $wpdb->get_var($wpdb->prepare(
                "SELECT rate FROM %i WHERE id = %d",
                ECWP_TABLE_VATS,
                $default_vat_id
            ));
        }

        $wpdb->query('START TRANSACTION');

        $last_invoice_id = (int) $wpdb->get_var("SELECT MAX(number) FROM " . ECWP_TABLE_INVOICES . " FOR UPDATE");
        if ($last_invoice_id <= 0) {
            $first = (int) $wpdb->get_var("SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = 'invoice_first'");
            $last_invoice_id = $first > 0 ? $first : 1;
        } else {
            $last_invoice_id++;
        }

        $invoice_number = $invoice_prefix . '-' . str_pad($last_invoice_id, 4, '0', STR_PAD_LEFT);

        $invoice_data = [
            'client_id'      => $client_id,
            'amount'         => $encrypt->encrypt($total_without_tax),
            'total_amount'   => $encrypt->encrypt($total_with_tax),
            'paid_amount'    => ($invoice_status === 'paid') ? $total_with_tax : 0,
            'status'         => $encrypt->encrypt($invoice_status),
            'status_stats'   => $invoice_status,
            'due_date'       => $due_date,
            'created_at'     => current_time('mysql'),
            'source'         => 'SureCart',
            'invoice_number' => $encrypt->encrypt($invoice_number),
            'number'         => $last_invoice_id,
            'order_id'       => $order_id,
            'shipping_amount'=> $encrypt->encrypt($order->shipping_amount / 100),
        ];

        $wpdb->insert(ECWP_TABLE_INVOICES, $invoice_data);
        $invoice_id = $wpdb->insert_id;

        if (!$invoice_id) {
            $wpdb->query('ROLLBACK');
            error_log('myEasyCompta SureCart: Failed to insert invoice for order ' . $order_id);
            return;
        }

        if ($invoice_status === 'paid') {
            $wpdb->insert(ECWP_TABLE_PAYMENTS, [
                'invoice_id'        => $invoice_id,
                'amount'            => $total_with_tax,
                'payment_date'      => current_time('mysql'),
                'client_id'         => $client_id,
                'payment_method_id' => 1,
            ]);
        }

        if (!empty($order->line_items->data) && is_array($order->line_items->data)) {
            $item_order = 1;
            foreach ($order->line_items->data as $item) {
                $product_name = $item->price->product['name'] ?? 'Unknown product';
                $variant_options = $item->variant_options ?? [];
                $variant_option_names = $item->variant_option_names ?? [];

                $variant_description = '';
                if (!empty($variant_options) && !empty($variant_option_names)) {
                    foreach ($variant_options as $index => $option) {
                        $variant_name = $variant_option_names[$index] ?? 'Unknown';
                        $variant_description .= $variant_name . ': ' . $option . ', ';
                    }
                    $variant_description = rtrim($variant_description, ', ');
                }
                $item_quantity = max(1, (int) ($item->quantity ?? 1));
                $item_total = $item->total_amount ?? 0;
                $unit_price = ($item_total / 100) / $item_quantity;

                $inserted = $wpdb->insert(ECWP_TABLE_INVOICE_ELEMENTS, [
                    'invoice_id'       => $invoice_id,
                    'item_name'        => $encrypt->encrypt($product_name),
                    'item_ref'         => $encrypt->encrypt($item->attributes['id'] ?? ''),
                    'item_description' => $encrypt->encrypt($variant_description),
                    'quantity'         => $encrypt->encrypt($item_quantity),
                    'vat_rate'         => $encrypt->encrypt($default_vat_rate),
                    'unit_price'       => $encrypt->encrypt($unit_price),
                    'total_price'      => $encrypt->encrypt($item_total / 100),
                    'total_amount'     => $encrypt->encrypt($item_total / 100),
                    'item_order'       => $item_order++,
                ]);

                if ($inserted === false) {
                    $wpdb->query('ROLLBACK');
                    error_log('myEasyCompta SureCart: Failed to insert item for order ' . $order_id);
                    return;
                }
            }
        }

        $wpdb->query('COMMIT');
    }

    public function update_invoice_status_on_payment_completed($payment)
    {
        global $wpdb;

        $order_id = $payment->order_id;
        $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE order_id = %d", ECWP_TABLE_INVOICES, $order_id));

        if ($invoice) {
            $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
            $total_amount = floatval($encrypt->decrypt($invoice->total_amount));

            $wpdb->update(
                ECWP_TABLE_INVOICES,
                [
                    'status'       => $encrypt->encrypt('paid'),
                    'status_stats' => 'paid',
                    'paid_amount'  => $total_amount,
                ],
                ['id' => $invoice->id]
            );
        }
    }

    public function add_surecart_products_to_results(&$results, $search)
    {
        $url = home_url('/wp-json/surecart/v1/products');

        $response = wp_remote_get($url);

        if (is_wp_error($response)) {
            return;
        }
        $products = json_decode(wp_remote_retrieve_body($response), true);
        if (!empty($products)) {
            foreach ($products as $product) {
                if (!isset($product['name']) || empty($product['name'])) {
                    continue;
                }

                if (!empty($search) && stripos($product['name'], $search) === false) {
                    continue;
                }

                $metrics = $product['metrics'] ?? [];

                $min_price = $metrics['min_price_amount'] ?? 0;
                $max_price = $metrics['max_price_amount'] ?? 0;

                $final_price = $min_price;
                $final_price_in_currency = $final_price / 100;

                $variant_options = $product['variant_options'] ?? [];
                $variant_names = $product['variant_option_names'] ?? [];
                $variation_description = '';
                if (!empty($variant_options) && !empty($variant_names)) {
                    foreach ($variant_options as $key => $option) {
                        $variation_name = $variant_names[$key] ?? 'Option';
                        $variation_description .= $variation_name . ': ' . $option . '; ';
                    }
                }

                $results[] = [
                    'name' => $product['name'] . ' ' . rtrim($variation_description, '; ') . '',
                    'ref' => $product['id'],
                    'description' => $product['description'] ?? '',
                    'unit_price' => $final_price_in_currency,
                ];
            }
        }
    }

}
