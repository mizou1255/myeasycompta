<?php
/**
 * Plugin Name: myEasyCompta - SureCart Addon
 * Description: Integrate myEasyCompta with SureCart to automatically generate invoices for each new order. Sync SureCart sales data, manage transactions, track sales, and handle customer invoicing seamlessly.
 * Version: 2.0.0
 * Author: Moez
 * Author URI: https://moezbettoumi.fr
 * Text Domain: my-easy-compta-surecart
 * Requires at least: 6.2
 * Tested up to: 6.6.1
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ECWP_Easy_Compta_SureCart
{
    /**
     * Plugin version
     *
     * @var string
     */
    public $version = '2.0.0';

    /**
     * Minimum required PHP version
     *
     * @var string
     */
    private $min_php = '8.0';

    private $container = [];

    /**
     * Singleton instance
     *
     * @var ECWP_Easy_Compta_SureCart
     */
    private static $instance;

    /**
     * Initialize the plugin
     *
     * @return ECWP_Easy_Compta_SureCart
     */
    public static function init()
    {
        if (!isset(self::$instance) && !(self::$instance instanceof ECWP_Easy_Compta_SureCart)) {
            self::$instance = new ECWP_Easy_Compta_SureCart();
            self::$instance->setup();
        }

        return self::$instance;
    }

    /**
     * Setup the plugin
     *
     * @return void
     */
    private function setup()
    {
        register_activation_hook(__FILE__, [$this, 'auto_deactivate']);

        if (!$this->is_supported_php()) {
            return;
        }

        $this->define_constants();
        $this->includes();
        $this->instantiate();
        $this->init_actions();
    }

    /**
     * Define plugin constants
     *
     * @return void
     */
    private function define_constants()
    {
        global $wpdb;
        define('ECWP_SURECART_PATH', dirname(__FILE__));
        define('ECWP_SURECART_INCLUDES', ECWP_SURECART_PATH . '/includes');
        define('ECWP_SURECART_URL', plugins_url('', __FILE__));
        if (!defined('ECWP_PRINCIPAL_PATH')) {
            define('ECWP_PRINCIPAL_PATH', WP_CONTENT_DIR . '/plugins/my-easy-compta');
        }
        if (!defined('ECWP_PREFIX')) {
            define('ECWP_PREFIX', $wpdb->prefix);
        }
    }

    /**
     * Include required files
     *
     * @return void
     */
    private function includes()
    {
        require_once ECWP_PRINCIPAL_PATH . '/includes/API/Routes.php';
        require_once ECWP_SURECART_INCLUDES . '/migrations.php';
        require_once ECWP_SURECART_INCLUDES . '/App.php';
    }

    /**
     * Instantiate necessary classes or services
     *
     * @return void
     */
    private function instantiate()
    {
        $this->container['migration'] = new ECWP\SureCart\ECWPSureCart_Migrations();
        $this->container['app'] = new ECWP\SureCart\ECWPSureCart_APP();
    }

    /**
     * Initialize actions and hooks
     *
     * @return void
     */
    private function init_actions()
    {
        register_activation_hook(__FILE__, [$this->container['migration'], 'plugin_activation']);
        register_deactivation_hook(__FILE__, [$this->container['migration'], 'plugin_deactivation']);
        add_action('admin_init', [$this, 'check_plugin_dependencies']);

        add_action('admin_init', [$this, 'maybe_run_migration']);
        add_action('admin_notices', [$this, 'migration_admin_notice']);
    }

    /**
     * Check if the PHP version is supported
     *
     * @return bool
     */
    public function is_supported_php()
    {
        return version_compare(PHP_VERSION, $this->min_php, '>=');
    }

    /**
     * Deactivate the plugin if the PHP version is not supported
     *
     * @return void
     */
    public function auto_deactivate()
    {
        if (!$this->is_supported_php()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires PHP version %s or higher.',
                        'my-easy-compta-surecart'
                    ),
                    esc_html__('myEasyCompta SureCart Addon', 'my-easy-compta-surecart'),
                    esc_html($this->min_php)
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta-surecart'),
                ['response' => 200, 'back_link' => true]
            );
        }
        if (!is_plugin_active('my-easy-compta/my-easy-compta.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires the myEasyCompta plugin to be active.',
                        'my-easy-compta-surecart'
                    ),
                    esc_html__('myEasyCompta SureCart', 'my-easy-compta')
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta'),
                ['response' => 200, 'back_link' => true]
            );
        }
    }

    /**
     * Check if Easy Compta and SureCart plugins are activated
     */
    public function check_plugin_dependencies()
    {
        if (!class_exists('ECWP_Easy_Compta') || !class_exists('SureCart')) {
            add_action('admin_notices', [$this, 'display_missing_dependencies_notice']);
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }

    /**
     * Display a notice if Easy Compta or SureCart plugins are not activated
     */
    public function display_missing_dependencies_notice()
    {?>
<div class="notice notice-error is-dismissible">
    <p><?php _e('myEasyCompta SureCart requires the myEasyCompta and SureCart plugins to be activated. Please activate them before activating this plugin.', 'my-easy-compta');?>
    </p>
</div>
<?php
}

    public function maybe_run_migration()
    {
        if (isset($_POST['run_migration_surecart']) && check_admin_referer('run_migration_surecart_action', 'run_migration_surecart_nonce')) {
            $this->run_migrations();
            add_action('admin_notices', function () {
                echo '<div class="notice notice-success is-dismissible">
                        <p>' . __('Database migration completed successfully.', 'my-easy-compta') . '</p>
                    </div>';
            });
        }
    }

    private function run_migrations()
    {
        $migrations = [

        ];

        $installed_db_version = get_option('ecwp_surecart_db_version', '1.0.0');
        foreach ($migrations as $version => $file) {
            if (version_compare($installed_db_version, $version, '<')) {
                require_once $file;
                $migration_function = 'run_migration_surecart_' . str_replace('.', '_', $version);
                if (function_exists($migration_function)) {
                    $migration_function();
                }
            }
        }
        update_option('ecwp_surecart_db_version', $this->version);
    }

    public function migration_admin_notice()
    {
        $installed_db_version = get_option('ecwp_surecart_db_version', '1.0.0');

        if (version_compare($installed_db_version, $this->version, '<')) {
            echo '<div class="notice notice-warning is-dismissible">
                    <p>' . __('myEasyCompta SureCart requires a database update.', 'my-easy-compta') . '</p>
                    <form method="post">
                        ' . wp_nonce_field('run_migration_surecart_action', 'run_migration_surecart_nonce') . '
                        <p><input type="submit" name="run_migration_surecart" class="button button-primary" value="' . esc_attr__('Update Database', 'my-easy-compta') . '" /></p>
                    </form>
                </div>';
        }
    }
}

/**
 * Initialize the ECWP_Easy_Compta_SureCart plugin
 *
 * @return ECWP_Easy_Compta_SureCart
 */
ECWP_Easy_Compta_SureCart::init();
