<?php

namespace ECWP\Export;

use ECWP\API\Routes;
use WP_Error;

class ECWPExport_Export
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    private function register_api_routes()
    {
        $this->routes->add_route('/export-data', 'POST', $this, 'export_data', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/export-annual-report', 'GET', $this, 'export_annual_report', function () {
            return current_user_can('manage_options');
        });
        $this->routes->add_route('/export-fec', 'GET', $this, 'export_fec', function () {
            return current_user_can('manage_options');
        });

        $this->routes->register_routes();
    }

    public function export_data($request)
    {
        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!$this->verify_nonce($nonce)) {
            return new WP_Error('invalid_nonce', __('Nonce verification failed', 'my-easy-compta'), array('status' => 403));
        }

        $data = $request->get_json_params();
        if (!$this->validate_request_data($data)) {
            return new WP_Error('missing_data', __('Category or fields data missing', 'my-easy-compta'), array('status' => 400));
        }

        $type_export = sanitize_text_field($data['category']);
        $fields_export = $data['fields'];
        $selected_fields = $this->get_selected_fields($fields_export, $type_export);

        if (empty($selected_fields)) {
            return new WP_Error('missing_fields', __('No fields selected for export', 'my-easy-compta'), array('status' => 400));
        }

        $query = $this->build_query($type_export, $selected_fields);
        if (is_wp_error($query)) {
            return $query;
        }

        $results = $this->execute_query($query, [], $type_export);
        if (is_wp_error($results)) {
            return $results;
        }

        $format = isset($data['format']) ? sanitize_key($data['format']) : 'csv';

        if ($format === 'xlsx') {
            $this->generate_xlsx($results, $type_export);
        } else {
            $this->generate_csv($results, $type_export);
        }

        exit;
    }

    private function verify_nonce($nonce)
    {
        return wp_verify_nonce(sanitize_text_field(wp_unslash($nonce)), 'wp_rest');
    }

    private function validate_request_data($data)
    {
        return !empty($data['category']) && !empty($data['fields']);
    }

    private function get_selected_fields($fields_export, $type_export)
    {
        $allowed       = $this->get_allowed_fields($type_export);
        $selected_fields = array_keys(array_filter($fields_export, 'boolval'));

        // Whitelist: keep only explicitly allowed field names.
        $selected_fields = array_values(array_filter($selected_fields, function ($field) use ($allowed) {
            return in_array($field, $allowed, true);
        }));

        if (($type_export === 'quotes' || $type_export === 'invoices') && in_array('total_amount', $selected_fields)) {
            $amount_index = array_search('total_amount', $selected_fields);
            array_splice($selected_fields, $amount_index + 1, 0, 'currency_symbol');
        }

        return $selected_fields;
    }

    private function build_query($type_export, $selected_fields)
    {
        global $wpdb;

        $selected_fields_str = implode(', ', array_map(function ($field) use ($type_export) {
            return $this->map_field($field, $type_export);
        }, $selected_fields));

        switch ($type_export) {
            case 'clients':
                return "SELECT $selected_fields_str FROM " . ECWP_TABLE_CLIENTS . " AS clients
                        LEFT JOIN " . ECWP_TABLE_CURRENCY . " AS currency ON clients.currency_id = currency.id";
            case 'quotes':
                return "SELECT $selected_fields_str
                                    FROM " . ECWP_TABLE_QUOTES . " AS quotes
                                    LEFT JOIN " . ECWP_TABLE_CLIENTS . " AS clients ON quotes.client_id = clients.id
                                    LEFT JOIN " . ECWP_TABLE_CURRENCY . " AS currency ON clients.currency_id = currency.id";
            case 'invoices':
                return "SELECT $selected_fields_str FROM " . ECWP_TABLE_INVOICES . " AS invoices
                        LEFT JOIN " . ECWP_TABLE_CLIENTS . " AS clients ON invoices.client_id = clients.id
                        LEFT JOIN " . ECWP_TABLE_CURRENCY . " AS currency ON clients.currency_id = currency.id";
            case 'payments':
                return "SELECT $selected_fields_str FROM " . ECWP_TABLE_PAYMENTS . " AS payments
                        LEFT JOIN " . ECWP_TABLE_CLIENTS . " AS clients ON payments.client_id = clients.id
                        LEFT JOIN " . ECWP_TABLE_INVOICES . " AS invoices ON payments.invoice_id = invoices.id
                        LEFT JOIN " . ECWP_TABLE_PAYMENTS_METHODS . " AS methods ON payments.payment_method_id = methods.id
                        LEFT JOIN " . ECWP_TABLE_CURRENCY . " AS currency ON clients.currency_id = currency.id";
            case 'expenses':
                return "SELECT $selected_fields_str FROM " . ECWP_TABLE_EXPENSES . " AS expenses
                        LEFT JOIN " . ECWP_TABLE_CLIENTS . " AS clients ON expenses.client_id = clients.id
                        LEFT JOIN " . ECWP_TABLE_EXPENSES_CATEGORIES . " AS ex_cat ON expenses.category_id = ex_cat.id
                        LEFT JOIN " . ECWP_TABLE_EXPENSES_ATTACHMENTS . " AS ex_att ON expenses.attachment_id = ex_att.id";
            default:
                return new WP_Error('invalid_category', __('Invalid export category', 'my-easy-compta'), array('status' => 400));
        }
    }

    private function map_field($field, $type_export)
    {
        switch ($type_export) {
            case 'clients':
                return $this->map_client_field($field);
            case 'payments':
                return $this->map_payment_field($field);
            case 'expenses':
                return $this->map_expense_field($field);
            case 'quotes':
                return $this->map_quote_field($field);
            case 'invoices':
                return $this->map_invoice_field($field);
            default:
                return $field;
        }
    }

    /**
     * Returns the list of allowed fields per export type to prevent SQL injection.
     */
    private function get_allowed_fields(string $type_export): array
    {
        $allowed = [
            'clients'  => ['id', 'company_name', 'first_name', 'last_name', 'email', 'phone', 'address', 'postal_code', 'city', 'country', 'siret', 'vat_number', 'client_id', 'currency_id'],
            'payments' => ['id', 'amount', 'payment_date', 'notes', 'client_id', 'invoice_id', 'payment_method_id'],
            'expenses' => ['id', 'notes', 'expense_date', 'amount', 'client_id', 'category_id', 'attachment_id'],
            'quotes'   => ['id', 'quote_number', 'quote_date', 'due_date', 'total_amount', 'subtotal', 'tax', 'status', 'notes', 'client_id', 'currency_symbol'],
            'invoices' => ['id', 'invoice_number', 'invoice_date', 'due_date', 'total_amount', 'subtotal', 'tax', 'status', 'notes', 'client_id', 'currency_symbol'],
        ];

        return $allowed[$type_export] ?? [];
    }

    private function map_client_field($field)
    {
        switch ($field) {
            case 'client_id':
                return 'clients.company_name AS client_name';
            case 'currency_id':
                return 'currency.symbol AS currency_symbol';
            default:
                return 'clients.' . sanitize_key($field);
        }
    }

    private function map_payment_field($field)
    {
        switch ($field) {
            case 'client_id':
                return 'clients.company_name AS client_name';
            case 'invoice_id':
                return 'invoices.invoice_number AS invoice_number';
            case 'payment_method_id':
                return 'methods.method_name AS method_name';
            default:
                return 'payments.' . sanitize_key($field);
        }
    }

    private function map_expense_field($field)
    {
        switch ($field) {
            case 'client_id':
                return 'clients.company_name AS client_name';
            case 'category_id':
                return 'ex_cat.name AS category_name';
            case 'attachment_id':
                return 'ex_att.filename AS attachment_file_name';
            default:
                return 'expenses.' . sanitize_key($field);
        }
    }

    private function map_quote_field($field)
    {
        switch ($field) {
            case 'client_id':
                return 'clients.company_name AS client_name';
            case 'currency_symbol':
                return 'currency.symbol AS currency_symbol';
            default:
                return 'quotes.' . sanitize_key($field);
        }
    }

    private function map_invoice_field($field)
    {
        switch ($field) {
            case 'client_id':
                return 'clients.company_name AS client_name';
            case 'currency_symbol':
                return 'currency.symbol AS currency_symbol';
            default:
                return 'invoices.' . sanitize_key($field);
        }
    }

    private function execute_query($query, $params = [], $type_export = '')
    {
        global $wpdb;
        if (!empty($params)) {
            $query = $wpdb->prepare($query, ...$params);
        }

        $results = $wpdb->get_results($query, ARRAY_A);

        if (!$results) {
            return new WP_Error('no_results', __('No results found', 'my-easy-compta'), array('status' => 404));
        }

        // Only invoice and payment exports have encrypted fields.
        // Quote fields (quote_number, status, total_amount) are stored plain — do NOT decrypt them.
        if ($type_export === 'invoices' || $type_export === 'payments') {
            $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
            foreach ($results as &$row) {
                if ($type_export === 'invoices') {
                    if (isset($row['invoice_number'])) {
                        $row['invoice_number'] = $encrypt->decrypt($row['invoice_number']);
                    }
                    if (isset($row['status'])) {
                        $row['status'] = $encrypt->decrypt($row['status']);
                    }
                    if (isset($row['total_amount'])) {
                        $row['total_amount'] = $encrypt->decrypt($row['total_amount']);
                    }
                    if (isset($row['exchange_rate'])) {
                        $row['exchange_rate'] = $encrypt->decrypt($row['exchange_rate']);
                    }
                } elseif ($type_export === 'payments') {
                    if (isset($row['invoice_number'])) {
                        $row['invoice_number'] = $encrypt->decrypt($row['invoice_number']);
                    }
                }
            }
        }

        return $results;
    }

    /**
     * Generate a minimal but spec-compliant XLSX file using PHP's ZipArchive.
     * No external dependency — pure OOXML XML strings in a ZIP container.
     */
    private function generate_xlsx(array $results, string $type_export): void
    {
        if (!class_exists('ZipArchive')) {
            // Fallback to CSV if ZipArchive is unavailable
            $this->generate_csv($results, $type_export);
            return;
        }

        $headers = array_keys($results[0]);
        $rows    = $results;

        // Build shared-strings index
        $strings = [];
        $str_index = function (string $val) use (&$strings): int {
            $idx = array_search($val, $strings, true);
            if ($idx === false) {
                $strings[] = $val;
                return count($strings) - 1;
            }
            return $idx;
        };

        // Col letter helper (A–Z then AA–XFD)
        $col_letter = function (int $n): string {
            $s = '';
            while ($n >= 0) {
                $s = chr(65 + ($n % 26)) . $s;
                $n = intdiv($n, 26) - 1;
            }
            return $s;
        };

        // ── Build sheet1.xml ──────────────────────────────────────────────────
        $sheet_rows = '';

        // Header row (row 1) — style index 1 = bold
        $sheet_rows .= '<row r="1">';
        foreach ($headers as $c => $h) {
            $ref = $col_letter($c) . '1';
            $si  = $str_index((string) $h);
            $sheet_rows .= '<c r="' . $ref . '" t="s" s="1"><v>' . $si . '</v></c>';
        }
        $sheet_rows .= '</row>';

        // Data rows (rows 2+)
        foreach ($rows as $ri => $row) {
            $r = $ri + 2;
            $sheet_rows .= '<row r="' . $r . '">';
            foreach (array_values($row) as $c => $val) {
                $ref = $col_letter($c) . $r;
                $val = (string) ($val ?? '');
                if (is_numeric($val) && $val !== '') {
                    $sheet_rows .= '<c r="' . $ref . '"><v>' . htmlspecialchars($val, ENT_XML1) . '</v></c>';
                } else {
                    $si = $str_index($val);
                    $sheet_rows .= '<c r="' . $ref . '" t="s"><v>' . $si . '</v></c>';
                }
            }
            $sheet_rows .= '</row>';
        }

        $sheet_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetData>' . $sheet_rows . '</sheetData>'
            . '</worksheet>';

        // ── Build sharedStrings.xml ───────────────────────────────────────────
        $ss_items = '';
        foreach ($strings as $s) {
            $ss_items .= '<si><t xml:space="preserve">' . htmlspecialchars($s, ENT_XML1 | ENT_QUOTES) . '</t></si>';
        }
        $count = count($strings);
        $ss_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
            . ' count="' . $count . '" uniqueCount="' . $count . '">'
            . $ss_items . '</sst>';

        // ── Minimal styles.xml (index 0 = normal, index 1 = bold) ─────────────
        $styles_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="2">'
            . '<font><sz val="11"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="11"/><name val="Calibri"/></font>'
            . '</fonts>'
            . '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
            . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="2">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0"/>'
            . '</cellXfs>'
            . '</styleSheet>';

        // ── Static boilerplate files ─────────────────────────────────────────
        $content_types = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>';

        $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';

        $workbook_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="Export" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';

        $workbook_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
            . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>';

        // ── Assemble the ZIP ──────────────────────────────────────────────────
        $tmp = tempnam(sys_get_temp_dir(), 'ecwp_xlsx_');
        @unlink($tmp); // ZipArchive needs to create the file itself

        $zip = new \ZipArchive();
        $zip->open($tmp, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        $zip->addFromString('[Content_Types].xml',            $content_types);
        $zip->addFromString('_rels/.rels',                   $rels);
        $zip->addFromString('xl/workbook.xml',               $workbook_xml);
        $zip->addFromString('xl/_rels/workbook.xml.rels',    $workbook_rels);
        $zip->addFromString('xl/worksheets/sheet1.xml',      $sheet_xml);
        $zip->addFromString('xl/sharedStrings.xml',          $ss_xml);
        $zip->addFromString('xl/styles.xml',                 $styles_xml);
        $zip->close();

        $filename = 'export_' . $type_export . '_' . wp_date('Y-m-d') . '.xlsx';

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($tmp));

        readfile($tmp);
        @unlink($tmp);
    }

    public function export_annual_report($request)
    {
        global $wpdb;

        $year = (int) ($request->get_param('year') ?: wp_date('Y'));
        if ($year < 2000 || $year > 2100) {
            return new WP_Error('invalid_year', 'Invalid year.', ['status' => 400]);
        }

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        // ── Invoices for the year ────────────────────────────────────────────
        $invoices_raw = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT i.id, i.invoice_number, i.invoice_date, i.due_date,
                        i.total_amount, i.subtotal, i.tax, i.status,
                        c.company_name AS client_name,
                        cur.symbol AS currency
                 FROM " . ECWP_TABLE_INVOICES . " i
                 LEFT JOIN " . ECWP_TABLE_CLIENTS . " c   ON i.client_id  = c.id
                 LEFT JOIN " . ECWP_TABLE_CURRENCY . " cur ON c.currency_id = cur.id
                 WHERE YEAR(i.invoice_date) = %d
                 ORDER BY i.invoice_date ASC",
                $year
            ),
            ARRAY_A
        );

        $invoices = [];
        $total_ht       = 0.0;
        $total_tax      = 0.0;
        $total_ttc      = 0.0;
        $total_paid     = 0.0;
        $total_unpaid   = 0.0;

        foreach ((array) $invoices_raw as $row) {
            $row['invoice_number'] = $encrypt->decrypt($row['invoice_number']);
            $row['total_amount']   = (float) $encrypt->decrypt($row['total_amount']);
            $row['subtotal']       = (float) $encrypt->decrypt($row['subtotal'] ?? '0');
            $row['tax']            = (float) $encrypt->decrypt($row['tax'] ?? '0');
            $row['status']         = $encrypt->decrypt($row['status']);

            $ht  = $row['subtotal'] ?: ($row['total_amount'] - $row['tax']);
            $tva = $row['tax'];
            $ttc = $row['total_amount'];

            $total_ht  += $ht;
            $total_tax += $tva;
            $total_ttc += $ttc;

            if ($row['status'] === 'paid') {
                $total_paid += $ttc;
            } else {
                $total_unpaid += $ttc;
            }

            $row['subtotal_fmt']     = number_format($ht,  2, '.', ' ');
            $row['tax_fmt']          = number_format($tva, 2, '.', ' ');
            $row['total_amount_fmt'] = number_format($ttc, 2, '.', ' ');
            $invoices[] = $row;
        }

        // ── Expenses for the year ────────────────────────────────────────────
        $expenses_raw = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT e.id, e.expense_date, e.amount, e.notes,
                        cat.name AS category, c.company_name AS client_name
                 FROM " . ECWP_TABLE_EXPENSES . " e
                 LEFT JOIN " . ECWP_TABLE_EXPENSES_CATEGORIES . " cat ON e.category_id = cat.id
                 LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON e.client_id = c.id
                 WHERE YEAR(e.expense_date) = %d
                 ORDER BY e.expense_date ASC",
                $year
            ),
            ARRAY_A
        );

        $expenses     = [];
        $total_expenses = 0.0;

        foreach ((array) $expenses_raw as $row) {
            $row['amount']      = (float) ($row['amount'] ?? 0);
            $total_expenses    += $row['amount'];
            $row['amount_fmt']  = number_format($row['amount'], 2, '.', ' ');
            $expenses[] = $row;
        }

        $gross_margin = $total_ttc - $total_expenses;

        $data = compact(
            'year', 'invoices', 'expenses',
            'total_ht', 'total_tax', 'total_ttc',
            'total_paid', 'total_unpaid', 'total_expenses', 'gross_margin'
        );

        $this->generate_annual_pdf($data);
        exit;
    }

    private function generate_annual_pdf(array $d): void
    {
        $year           = $d['year'];
        $invoices       = $d['invoices'];
        $expenses       = $d['expenses'];
        $total_ht       = $d['total_ht'];
        $total_tax      = $d['total_tax'];
        $total_ttc      = $d['total_ttc'];
        $total_paid     = $d['total_paid'];
        $total_unpaid   = $d['total_unpaid'];
        $total_expenses = $d['total_expenses'];
        $gross_margin   = $d['gross_margin'];

        $company = get_option('ecwp_company_name', get_bloginfo('name'));
        $fmt = function (float $v): string {
            return number_format($v, 2, '.', ' ');
        };

        // ── HTML template ────────────────────────────────────────────────────
        $inv_rows = '';
        foreach ($invoices as $inv) {
            $status_color = $inv['status'] === 'paid' ? '#16a34a' : '#dc2626';
            $inv_rows .= '<tr>'
                . '<td>' . esc_html($inv['invoice_number']) . '</td>'
                . '<td>' . esc_html($inv['invoice_date']) . '</td>'
                . '<td>' . esc_html($inv['client_name']) . '</td>'
                . '<td class="num">' . esc_html($inv['subtotal_fmt']) . '</td>'
                . '<td class="num">' . esc_html($inv['tax_fmt']) . '</td>'
                . '<td class="num">' . esc_html($inv['total_amount_fmt']) . '</td>'
                . '<td style="color:' . $status_color . ';font-weight:600">' . esc_html($inv['status']) . '</td>'
                . '</tr>';
        }

        $exp_rows = '';
        foreach ($expenses as $exp) {
            $exp_rows .= '<tr>'
                . '<td>' . esc_html($exp['expense_date']) . '</td>'
                . '<td>' . esc_html($exp['category'] ?? '—') . '</td>'
                . '<td>' . esc_html($exp['client_name'] ?? '—') . '</td>'
                . '<td>' . esc_html($exp['notes'] ?? '') . '</td>'
                . '<td class="num">' . esc_html($exp['amount_fmt']) . '</td>'
                . '</tr>';
        }

        $margin_color = $gross_margin >= 0 ? '#16a34a' : '#dc2626';

        $html = <<<'HTML'
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body      { font-family: DejaVu Sans, sans-serif; font-size: 9pt; color: #1e293b; }
  h1        { font-size: 16pt; color: #1e293b; margin-bottom: 2px; }
  h2        { font-size: 11pt; color: #334155; margin: 18px 0 6px; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; }
  .meta     { font-size: 8pt; color: #64748b; margin-bottom: 16px; }
  .kpi-grid { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
  .kpi-grid td { padding: 8px 12px; border-radius: 4px; }
  .kpi      { background: #f8fafc; border: 1px solid #e2e8f0; }
  .kpi .label { font-size: 7.5pt; color: #64748b; }
  .kpi .value { font-size: 13pt; font-weight: bold; color: #0f172a; }
  table.data { width: 100%; border-collapse: collapse; font-size: 8pt; margin-bottom: 12px; }
  table.data th { background: #1e293b; color: #fff; padding: 5px 7px; text-align: left; }
  table.data td { padding: 4px 7px; border-bottom: 1px solid #f1f5f9; }
  table.data tr:nth-child(even) td { background: #f8fafc; }
  .num      { text-align: right; }
  .summary  { width: 100%; border-collapse: collapse; margin-top: 6px; font-size: 9pt; }
  .summary td { padding: 5px 10px; }
  .summary .total-row td { font-weight: bold; border-top: 2px solid #1e293b; }
  .footer   { font-size: 7pt; color: #94a3b8; text-align: center; margin-top: 20px; }
  .page-break { page-break-before: always; }
</style>
</head>
<body>

<h1>Récapitulatif comptable {$year}</h1>
<p class="meta">Entreprise : <strong>{$company}</strong> &nbsp;·&nbsp; Généré le : <strong>{$_date}</strong></p>

<table class="kpi-grid">
  <tr>
    <td class="kpi"><div class="label">CA Total TTC</div><div class="value">{$_ttc} €</div></td>
    <td class="kpi"><div class="label">CA HT</div><div class="value">{$_ht} €</div></td>
    <td class="kpi"><div class="label">TVA collectée</div><div class="value">{$_tax} €</div></td>
    <td class="kpi"><div class="label">Factures payées</div><div class="value" style="color:#16a34a">{$_paid} €</div></td>
    <td class="kpi"><div class="label">Impayés</div><div class="value" style="color:#dc2626">{$_unpaid} €</div></td>
  </tr>
  <tr>
    <td class="kpi"><div class="label">Total Dépenses</div><div class="value" style="color:#dc2626">{$_exp} €</div></td>
    <td class="kpi" colspan="2"><div class="label">Marge brute (TTC − Dépenses)</div><div class="value" style="color:{$margin_color}">{$_margin} €</div></td>
    <td class="kpi"><div class="label">Nb factures</div><div class="value">{$_inv_count}</div></td>
    <td class="kpi"><div class="label">Nb dépenses</div><div class="value">{$_exp_count}</div></td>
  </tr>
</table>

<h2>Factures {$year}</h2>
<table class="data">
  <thead>
    <tr>
      <th>N°</th><th>Date</th><th>Client</th>
      <th class="num">HT</th><th class="num">TVA</th><th class="num">TTC</th>
      <th>Statut</th>
    </tr>
  </thead>
  <tbody>{$inv_rows}</tbody>
</table>

<table class="summary">
  <tr><td>Sous-total HT</td><td class="num">{$_ht} €</td></tr>
  <tr><td>Sous-total TVA</td><td class="num">{$_tax} €</td></tr>
  <tr class="total-row"><td>Total TTC</td><td class="num">{$_ttc} €</td></tr>
</table>

<div class="page-break"></div>

<h2>Dépenses {$year}</h2>
<table class="data">
  <thead>
    <tr><th>Date</th><th>Catégorie</th><th>Client/Fournisseur</th><th>Notes</th><th class="num">Montant</th></tr>
  </thead>
  <tbody>{$exp_rows}</tbody>
</table>

<table class="summary">
  <tr class="total-row"><td>Total Dépenses</td><td class="num">{$_exp} €</td></tr>
</table>

<p class="footer">myEasyCompta — Rapport généré automatiquement · {$year}</p>

</body>
</html>
HTML;

        // Replace placeholders
        $html = str_replace(
            ['{$_date}', '{$_ttc}', '{$_ht}', '{$_tax}', '{$_paid}', '{$_unpaid}', '{$_exp}', '{$_margin}', '{$_inv_count}', '{$_exp_count}'],
            [
                wp_date('d/m/Y'),
                $fmt($total_ttc),
                $fmt($total_ht),
                $fmt($total_tax),
                $fmt($total_paid),
                $fmt($total_unpaid),
                $fmt($total_expenses),
                $fmt($gross_margin),
                (string) count($invoices),
                (string) count($expenses),
            ],
            $html
        );

        $mpdf = new \Mpdf\Mpdf([
            'margin_left'   => 12,
            'margin_right'  => 12,
            'margin_top'    => 14,
            'margin_bottom' => 14,
            'default_font_size' => 9,
            'default_font'  => 'dejavusans',
            'mode'          => 'utf-8',
            'format'        => 'A4-L', // Landscape for wide invoice table
        ]);

        $mpdf->SetTitle('Récapitulatif ' . $year);
        $mpdf->SetAuthor($company);
        $mpdf->WriteHTML($html);
        $mpdf->Output('recapitulatif_' . $year . '.pdf', \Mpdf\Output\Destination::DOWNLOAD);
    }

    private function generate_csv($results, $type_export)
    {
        $csv_data = fopen('php://temp', 'w+');
        fwrite($csv_data, "\xEF\xBB\xBF");

        fputcsv($csv_data, array_keys($results[0]), ';');
        foreach ($results as $row) {
            fputcsv($csv_data, $row, ';');
        }

        $filename = 'export_' . $type_export . '_' . wp_date('Y-m-d') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        rewind($csv_data);
        echo stream_get_contents($csv_data);
        fclose($csv_data);
    }

    /**
     * Export FEC (Fichier des Écritures Comptables) — format normalisé DGFiP.
     *
     * Columns (tab-separated, as per art. A 47 A-1 LPF) :
     * JournalCode | JournalLib | EcritureNum | EcritureDate | CompteNum | CompteLib
     * CompAuxNum  | CompAuxLib | PieceRef    | PieceDate    | EcritureLib
     * Debit       | Credit     | EcritureLet | DateLet      | ValidDate
     * Montantdevise | Idevise
     */
    public function export_fec($request)
    {
        global $wpdb;

        $year    = (int) ($request->get_param('year') ?: wp_date('Y'));
        if ($year < 2000 || $year > 2100) {
            return new WP_Error('invalid_year', 'Invalid year.', ['status' => 400]);
        }

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        // Company name for labels
        $company = get_option('ecwp_company_name', get_bloginfo('name'));

        // ── Accounting entries ────────────────────────────────────────────────
        $entries = []; // Each entry: [JournalCode, JournalLib, EcritureNum, EcritureDate, CompteNum, CompteLib, CompAuxNum, CompAuxLib, PieceRef, PieceDate, EcritureLib, Debit, Credit, EcritureLet, DateLet, ValidDate, Montantdevise, Idevise]

        $fec_date = fn (string $d): string => str_replace('-', '', substr($d, 0, 10));
        $fec_amount = fn (float $v): string => number_format(abs($v), 2, ',', '');

        $ecriture_seq = 1;

        // ── Invoices → debit 411 (client) + credit 706 (revenue) + credit 445711 (TVA) ──
        $invoices = $wpdb->get_results($wpdb->prepare(
            "SELECT i.*, c.company_name AS client_name, c.id AS client_id_raw
             FROM " . ECWP_TABLE_INVOICES . " i
             LEFT JOIN " . ECWP_TABLE_CLIENTS . " c ON i.client_id = c.id
             WHERE YEAR(i.invoice_date) = %d
             ORDER BY i.invoice_date ASC, i.id ASC",
            $year
        ), ARRAY_A);

        foreach ($invoices as $inv) {
            $inv_num  = $encrypt->decrypt($inv['invoice_number']);
            $ttc      = (float) $encrypt->decrypt($inv['total_amount']);
            $ht       = (float) $encrypt->decrypt($inv['subtotal'] ?? '') ?: ($ttc - (float) $encrypt->decrypt($inv['tax'] ?? '0'));
            $tva      = $ttc - $ht;
            $date     = $fec_date($inv['invoice_date']);
            $client   = substr(preg_replace('/[^A-Za-z0-9 ]/', '', $inv['client_name'] ?? 'CLIENT'), 0, 30);
            $num      = str_pad($ecriture_seq++, 6, '0', STR_PAD_LEFT);

            // Ligne 1 : debit 411 client
            $entries[] = ['VT', 'Ventes', $num, $date, '411' . str_pad($inv['client_id_raw'], 5, '0', STR_PAD_LEFT), $client, '', '', $inv_num, $date, 'Facture ' . $inv_num, $fec_amount($ttc), '0,00', '', '', $date, '', ''];

            // Ligne 2 : credit 706 produits
            $entries[] = ['VT', 'Ventes', $num, $date, '706000', 'Prestations de services', '', '', $inv_num, $date, 'Facture ' . $inv_num, '0,00', $fec_amount($ht), '', '', $date, '', ''];

            // Ligne 3 : credit 44571 TVA collectée (only if TVA > 0)
            if ($tva > 0.01) {
                $entries[] = ['VT', 'Ventes', $num, $date, '445711', 'TVA collectée', '', '', $inv_num, $date, 'Facture ' . $inv_num, '0,00', $fec_amount($tva), '', '', $date, '', ''];
            }
        }

        // ── Payments → debit 512 (bank) + credit 411 (client) ────────────────
        $payments = $wpdb->get_results($wpdb->prepare(
            "SELECT p.*, c.company_name AS client_name, c.id AS client_id_raw, i.invoice_number AS enc_inv_num
             FROM " . ECWP_TABLE_PAYMENTS . " p
             LEFT JOIN " . ECWP_TABLE_CLIENTS  . " c ON p.client_id  = c.id
             LEFT JOIN " . ECWP_TABLE_INVOICES . " i ON p.invoice_id = i.id
             WHERE YEAR(p.payment_date) = %d
             ORDER BY p.payment_date ASC, p.id ASC",
            $year
        ), ARRAY_A);

        foreach ($payments as $pay) {
            $amount  = (float) $pay['amount'];
            $date    = $fec_date($pay['payment_date']);
            $inv_num = $encrypt->decrypt($pay['enc_inv_num'] ?? '');
            $client  = substr(preg_replace('/[^A-Za-z0-9 ]/', '', $pay['client_name'] ?? 'CLIENT'), 0, 30);
            $num     = str_pad($ecriture_seq++, 6, '0', STR_PAD_LEFT);
            $ref     = 'REG-' . $pay['id'];

            // Debit 512
            $entries[] = ['BQ', 'Banque', $num, $date, '512000', 'Banque', '', '', $ref, $date, 'Règlement ' . $inv_num, $fec_amount($amount), '0,00', '', '', $date, '', ''];
            // Credit 411
            $entries[] = ['BQ', 'Banque', $num, $date, '411' . str_pad($pay['client_id_raw'], 5, '0', STR_PAD_LEFT), $client, '', '', $ref, $date, 'Règlement ' . $inv_num, '0,00', $fec_amount($amount), '', '', $date, '', ''];
        }

        // ── Expenses → debit 606 + credit 401 (fournisseur) ──────────────────
        $expenses = $wpdb->get_results($wpdb->prepare(
            "SELECT e.*, cat.name AS cat_name
             FROM " . ECWP_TABLE_EXPENSES . " e
             LEFT JOIN " . ECWP_TABLE_EXPENSES_CATEGORIES . " cat ON e.category_id = cat.id
             WHERE YEAR(e.expense_date) = %d
             ORDER BY e.expense_date ASC, e.id ASC",
            $year
        ), ARRAY_A);

        foreach ($expenses as $exp) {
            $amount = (float) $exp['amount'];
            $date   = $fec_date($exp['expense_date']);
            $lib    = substr(preg_replace('/[^A-Za-z0-9 ]/', '', $exp['cat_name'] ?? 'Dépense'), 0, 30);
            $ref    = 'DEP-' . $exp['id'];
            $num    = str_pad($ecriture_seq++, 6, '0', STR_PAD_LEFT);

            $entries[] = ['AC', 'Achats', $num, $date, '606000', 'Autres achats', '', '', $ref, $date, $lib, $fec_amount($amount), '0,00', '', '', $date, '', ''];
            $entries[] = ['AC', 'Achats', $num, $date, '401000', 'Fournisseurs', '', '', $ref, $date, $lib, '0,00', $fec_amount($amount), '', '', $date, '', ''];
        }

        // ── Stream the FEC file ───────────────────────────────────────────────
        $cols = ['JournalCode', 'JournalLib', 'EcritureNum', 'EcritureDate', 'CompteNum', 'CompteLib', 'CompAuxNum', 'CompAuxLib', 'PieceRef', 'PieceDate', 'EcritureLib', 'Debit', 'Credit', 'EcritureLet', 'DateLet', 'ValidDate', 'Montantdevise', 'Idevise'];

        $filename = 'FEC_' . preg_replace('/[^A-Za-z0-9]/', '', $company) . '_' . $year . '.txt';

        header('Content-Type: text/plain; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        echo implode("\t", $cols) . "\r\n";
        foreach ($entries as $row) {
            echo implode("\t", $row) . "\r\n";
        }
        exit;
    }
}
