<?php

namespace ECWP\QRCODE;

class ECWPQRCODE_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
    }
    public function database_update()
    {
        $this->insert_meta_key_if_not_exists('easy_compta_qrcode_addon_active', 1);
        $this->insert_meta_key_if_not_exists('easy_compta_stripe_secret_api', '');

    }
    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_qrcode_addon_active'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_stripe_secret_api'));
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                ECWP_TABLE_SETTINGS,
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }
}
