<?php
namespace ECWP\QRCODE;

require_once ECWP_QRCODE_PATH . '/vendor/autoload.php';
use ECWP\Admin\Settings\ECWP_Settings;
use ECWP\API\Routes;
use ECWP\Admin\Encrypt\ECWP_Encrypt;

class ECWPQRCODE_APP
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    public function register_api_routes()
    {
        $this->routes->add_route('/generate-qrcode', 'POST', $this, 'handle_generate_qr_code', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        $this->routes->add_route('/invoices/(?P<id>\d+)/qrcode', 'GET', $this, 'handle_get_invoice_qrcode', function () {
            return current_user_can('manage_options') && $this->has_valid_license();
        });

        $this->routes->register_routes();
    }

    public function handle_get_invoice_qrcode(\WP_REST_Request $request)
    {
        if (!$this->has_valid_license()) {
            return new \WP_REST_Response(array('message' => 'License required'), 403);
        }

        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_REST_Response('Invalid nonce', 403);
        }

        $invoice_id = absint($request->get_param('id'));

        global $wpdb;
        // Using string directly if constant not available, but usually defined
        $table_invoices = defined('ECWP_TABLE_INVOICES') ? ECWP_TABLE_INVOICES : $wpdb->prefix . 'ecwp_invoices';

        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT i.invoice_number, i.amount, i.total_amount, c.company_name, c.email as client_email 
             FROM {$table_invoices} i 
             LEFT JOIN " . (defined('ECWP_TABLE_CLIENTS') ? ECWP_TABLE_CLIENTS : $wpdb->prefix . 'ecwp_clients') . " c ON i.client_id = c.id 
             WHERE i.id = %d",
            $invoice_id
        ));

        if (!$invoice) {
            return new \WP_REST_Response('Invoice not found', 404);
        }

        $encrypt = new ECWP_Encrypt();
        $invoice_ref = $encrypt->decrypt($invoice->invoice_number);
        $decrypted_amount = $encrypt->decrypt($invoice->total_amount);

        // Fallback to 'amount' if 'total_amount' is empty or zero
        if (empty($decrypted_amount) || $decrypted_amount === '0') {
            $decrypted_amount = $encrypt->decrypt($invoice->amount);
        }

        // Clean the amount string: remove spaces, replace comma with dot
        $clean_amount = str_replace([' ', ','], ['', '.'], $decrypted_amount);
        $price = round(floatval($clean_amount) * 100);

        if ($price <= 0) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("QR Code Error: Calculated price is 0 for invoice ID {$invoice_id}. Decrypted amount: '{$decrypted_amount}'");
            }
            return new \WP_REST_Response(['success' => false, 'message' => 'Invoice amount is zero or could not be determined.'], 400);
        }

        $client_info = [
            'email' => $invoice->client_email,
            'name' => $invoice->company_name
        ];

        $payment_url = self::create_stripe_payment_session($invoice_ref, $price, $client_info);

        if ($payment_url) {
            $qrCodeSrc = self::generate_qr_code($payment_url);

            if ($qrCodeSrc) {
                return new \WP_REST_Response(['success' => true, 'data' => ['url' => $qrCodeSrc]], 200);
            } else {
                return new \WP_REST_Response(['success' => false, 'message' => 'Error generating QR Code'], 500);
            }
        } else {
            return new \WP_REST_Response(['success' => false, 'message' => 'Error creating Stripe payment link (Check your API keys in settings)'], 500);
        }
    }

    public function handle_generate_qr_code(\WP_REST_Request $request)
    {
        if (!$this->has_valid_license()) {
            return new \WP_REST_Response(array('message' => 'License required'), 403);
        }

        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_REST_Response('Invalid nonce', 403);
        }

        $params = $request->get_json_params();

        if (!isset($params['invoice_ref']) || !isset($params['price'])) {
            return new \WP_REST_Response('Product name or price missing', 400);
        }

        $invoice_ref = sanitize_text_field($params['invoice_ref']);
        $price = floatval($params['price']) * 100;

        $payment_url = self::create_stripe_payment_session($invoice_ref, $price);

        if ($payment_url) {
            $qrCodeSrc = self::generate_qr_code($payment_url);

            if ($qrCodeSrc) {
                return new \WP_REST_Response(['qr_code' => $qrCodeSrc], 200);
            } else {
                return new \WP_REST_Response('Error generating QR Code', 500);
            }
        } else {
            return new \WP_REST_Response('Error creating Stripe payment link', 500);
        }
    }
    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    // Méthode pour générer le QR code
    private static function generate_qr_code($url)
    {
        try {
            // Utilisation de la bibliothèque Endroid pour générer le QR code
            $qrCode = \Endroid\QrCode\Builder\Builder::create()
                ->writer(new \Endroid\QrCode\Writer\PngWriter())
                ->data($url)
                ->size(300) // Taille du QR code
                ->margin(10) // Marge autour du QR code
                ->build();

            // Encoder le QR code en base64
            return 'data:image/png;base64,' . base64_encode($qrCode->getString());

        } catch (\Exception $e) {
            // Loguer les erreurs en cas de problème lors de la génération du QR code
            error_log('Erreur lors de la génération du QR code : ' . $e->getMessage());
            return false;
        }
    }

    // Méthode pour créer la session de paiement Stripe
    public static function create_stripe_payment_session($invoice_ref, $price, $client_info = [])
    {
        // Récupérer la clé API Stripe depuis les paramètres
        $settings = new ECWP_Settings();

        $test_mode = $settings->get_setting('stripe_test_mode');
        if ($test_mode == 1) {
            $stripe_secret_api = $settings->get_setting('stripe_test_secret_key');
        } else {
            $stripe_secret_api = $settings->get_setting('stripe_live_secret_key');
        }

        if (empty($stripe_secret_api)) {
            error_log('Stripe API Key missing in settings');
            return false;
        }

        try {
            // Initialiser l'API Stripe avec la clé secrète
            \Stripe\Stripe::setApiKey($stripe_secret_api);

            $payment_name = 'Facture ' . $invoice_ref;
            if (!empty($client_info['name'])) {
                $payment_name .= ' - ' . $client_info['name'];
            }

            $session_data = [
                'payment_method_types' => ['card'],
                'line_items' => [
                    [
                        'price_data' => [
                            'currency' => 'eur',
                            'product_data' => [
                                'name' => $payment_name,
                            ],
                            'unit_amount' => $price,
                        ],
                        'quantity' => 1,
                    ]
                ],
                'mode' => 'payment',
                'success_url' => site_url() . '/payment-success?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => site_url() . '/payment-cancelled',
            ];

            if (!empty($client_info['email'])) {
                $session_data['customer_email'] = $client_info['email'];
            }

            // Créer une session de paiement Stripe
            $session = \Stripe\Checkout\Session::create($session_data);

            return $session->url; // Retourner l'URL de la session Stripe

        } catch (\Exception $e) {
            // Loguer les erreurs en cas de problème lors de la création de la session
            error_log('Erreur lors de la création de la session Stripe : ' . $e->getMessage());
            return false;
        }
    }
}
