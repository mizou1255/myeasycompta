<?php
/**
 * Plugin Name: myEasyCompta - QRCode Stripe Addon
 * Description: Adds a button in myEasyCompta to generate a QR code for Stripe payment links, facilitating payments.
 * Version: 2.0.0
 * Author: Moez
 * Text Domain: my-easy-compta-qrcode-stripe
 * Domain Path: /languages/
 * Requires at least: 6.2
 * Requires PHP: 8.0
 */

// Ne pas appeler le fichier directement
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ECWP_QRCode_Stripe_Addon
{
    /**
     * Plugin version
     *
     * @var string
     */
    public $version = '2.0.0';

    /**
     * Minimum required PHP version
     *
     * @var string
     */
    private $min_php = '8.0';

    private $container = [];

    /**
     * Singleton instance
     *
     * @var ECWP_QRCode_Stripe_Addon
     */
    private static $instance;

    /**
     * Initialize the plugin
     *
     * @return ECWP_QRCode_Stripe_Addon
     */
    public static function init()
    {
        if (!isset(self::$instance) && !(self::$instance instanceof ECWP_QRCode_Stripe_Addon)) {
            self::$instance = new ECWP_QRCode_Stripe_Addon();
            self::$instance->setup();
        }

        return self::$instance;
    }

    /**
     * Setup the plugin
     *
     * @return void
     */
    private function setup()
    {
        // Vérifier si les conditions d'activation sont remplies
        register_activation_hook(__FILE__, [$this, 'auto_deactivate']);

        if (!$this->is_supported_php()) {
            return;
        }

        $this->define_constants();
        $this->includes();
        $this->instantiate();
        $this->init_actions();
    }

    /**
     * Define plugin constants
     *
     * @return void
     */
    private function define_constants()
    {
        global $wpdb;
        define('ECWP_QRCODE_PATH', dirname(__FILE__));
        define('ECWP_QRCODE_URL', plugins_url('', __FILE__));
        define('ECWP_QRCODE_INCLUDES', ECWP_QRCODE_PATH . '/includes');
        if (!defined('ECWP_PRINCIPAL_PATH')) {
            define('ECWP_PRINCIPAL_PATH', WP_CONTENT_DIR . '/plugins/my-easy-compta');
        }
        if (!defined('ECWP_PREFIX')) {
            define('ECWP_PREFIX', $wpdb->prefix);
        }
    }

    /**
     * Include required files
     *
     * @return void
     */
    private function includes()
    {
        require_once ECWP_QRCODE_INCLUDES . '/migrations.php';
        require_once ECWP_PRINCIPAL_PATH . '/includes/API/Routes.php';
        require_once ECWP_QRCODE_INCLUDES . '/App.php';
    }

    /**
     * Instantiate necessary classes or services
     *
     * @return void
     */
    private function instantiate()
    {
        $this->container['migration'] = new ECWP\QRCODE\ECWPQRCODE_Migrations();
        $this->container['app'] = new ECWP\QRCODE\ECWPQRCODE_APP();
    }

    /**
     * Initialize actions and hooks
     *
     * @return void
     */
    private function init_actions()
    {
        register_activation_hook(__FILE__, [$this->container['migration'], 'plugin_activation']);
        register_deactivation_hook(__FILE__, [$this->container['migration'], 'plugin_desactivation']);
        add_action('admin_init', [$this, 'check_plugin_dependencies']);
    }

    /**
     * Check if the PHP version is supported
     *
     * @return bool
     */
    public function is_supported_php()
    {
        return version_compare(PHP_VERSION, $this->min_php, '>=');
    }

    /**
     * Check if myEasyCompta plugin are activated
     */
    public function check_plugin_dependencies()
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            add_action('admin_notices', [$this, 'display_missing_dependencies_notice']);
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }
    /**
     * Deactivate the plugin if the PHP version is not supported
     *
     * @return void
     */
    public function auto_deactivate()
    {
        if (!$this->is_supported_php()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires PHP version %s or higher.',
                        'my-easy-compta-qrcode-stripe'
                    ),
                    esc_html__('myEasyCompta QR Code Stripe Addon', 'my-easy-compta-qrcode-stripe'),
                    esc_html($this->min_php)
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta-qrcode-stripe'),
                ['response' => 200, 'back_link' => true]
            );
        }
        if (!is_plugin_active('my-easy-compta/my-easy-compta.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires the myEasyCompta plugin to be active.',
                        'my-easy-compta-qrcode-stripe'
                    ),
                    esc_html__('myEasyCompta QRCode Stripe Addon', 'my-easy-compta-qrcode-stripe')
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta-qrcode-stripe'),
                ['response' => 200, 'back_link' => true]
            );
        }
    }
    /**
     * Display a notice if myEasyCompta plugin are not activated
     */
    public function display_missing_dependencies_notice()
    {?>
<div class="notice notice-error is-dismissible">
    <p><?php _e('myEasyCompta QRCode Stripe requires the <b>myEasyCompta</b> plugin to be activated. Please activate them before activating this plugin.', 'my-easy-compta');?>
    </p>
</div>
<?php
}
}

/**
 * Initialize the ECWP_QRCode_Stripe_Addon plugin
 *
 * @return ECWP_QRCode_Stripe_Addon
 */
ECWP_QRCode_Stripe_Addon::init();
