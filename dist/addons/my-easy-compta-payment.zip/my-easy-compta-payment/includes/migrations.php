<?php

namespace ECWP\Payment;

class ECWPPayment_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
    }
    public function database_update()
    {
        global $wpdb;
        $this->insert_meta_key_if_not_exists('easy_compta_payment_addon_active', 1);
        $column_id_exists = $wpdb->get_var("SHOW COLUMNS FROM " . ECWP_TABLE_INVOICES . " LIKE 'stripe_payed'");

        if (!$column_id_exists) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " ADD COLUMN stripe_payed tinyint(1) NOT NULL DEFAULT 0");
        }

        $stripe_method_id = $wpdb->insert(
            ECWP_TABLE_PAYMENTS_METHODS,
            array('method_name' => 'Stripe')
        );

        if ($stripe_method_id !== false) {
            $inserted_id = $wpdb->insert_id;
            $this->insert_meta_key_if_not_exists('easy_compta_payment_method_stripe', $inserted_id);
        }

    }
    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_payment_addon_active'));

        $id_stripe = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM %i WHERE meta_key = %s", ECWP_TABLE_SETTINGS, 'easy_compta_payment_method_stripe'
        ));
        if ($id_stripe) {
            $wpdb->delete(
                ECWP_TABLE_PAYMENTS_METHODS,
                array('id' => $id_stripe),
                array('%d')
            );

            $wpdb->delete(
                ECWP_TABLE_SETTINGS,
                array('meta_key' => 'easy_compta_payment_method_stripe'),
                array('%s')
            );
        }

        $wpdb->query("ALTER TABLE " . ECWP_TABLE_INVOICES . " DROP COLUMN stripe_payed");
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                ECWP_TABLE_SETTINGS,
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }
}
