<?php

namespace ECWP\Payment;

require ECWP_PAYMENT_PATH . '/vendor/autoload.php';
use ECWP\Admin\Settings\ECWP_Settings;
use ECWP\API\Routes;

class ECWPPayment_APP
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    public function register_api_routes()
    {
        $this->routes->add_route('/payment/pay', 'POST', $this, 'pay_invoice', function () {
            return current_user_can('manage_options');
        });

        $this->routes->add_route('/payment/update-invoice-status', 'POST', $this, 'update_invoice_status', function () {
            return current_user_can('manage_options');
        });

        // Public webhook endpoint — Stripe signs the payload; no WP auth needed.
        $this->routes->add_route('/stripe-webhook', 'POST', $this, 'handle_stripe_webhook', '__return_true');

        $this->routes->register_routes();
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    public function pay_invoice(\WP_REST_Request $request)
    {
        if (!$this->has_valid_license()) {
            return new \WP_REST_Response(array('message' => 'License required'), 403);
        }

        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $raw_amount     = $request->get_param('amount');
        $invoice_number = sanitize_text_field($request->get_param('invoice_number'));
        $invoice_id     = absint($request->get_param('invoice_id'));
        $client_id      = absint($request->get_param('client_id'));

        if (empty($raw_amount) || !is_numeric($raw_amount)) {
            return new \WP_REST_Response('Amount is required and must be numeric.', 400);
        }
        $amount = floatval($raw_amount);
        if ($amount <= 0) {
            return new \WP_REST_Response('Invalid amount.', 400);
        }

        global $wpdb;

        // Resolve client's currency symbol (Stripe expects lowercase ISO code, e.g. "eur").
        $client_row = $wpdb->get_row($wpdb->prepare(
            "SELECT c.company_name, c.email, cur.symbol
             FROM " . ECWP_TABLE_CLIENTS . " c
             LEFT JOIN " . ECWP_TABLE_CURRENCY . " cur ON c.currency_id = cur.id
             WHERE c.id = %d",
            $client_id
        ), ARRAY_A);

        $stripe_currency = $client_row && !empty($client_row['symbol'])
            ? strtolower($client_row['symbol'])
            : 'eur';

        $stripe_mode = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM %i WHERE meta_key = 'stripe_mode'", ECWP_TABLE_SETTINGS
        ));

        $key_meta = $stripe_mode === 'live' ? 'stripe_secret_key_live' : 'stripe_secret_key_test';
        $stripe_secret_api = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM %i WHERE meta_key = %s", ECWP_TABLE_SETTINGS, $key_meta
        ));

        try {
            \Stripe\Stripe::setApiKey($stripe_secret_api);

            // Reuse existing Stripe customer if available, otherwise create one.
            $cust_option_key  = 'ecwp_stripe_cust_' . $client_id;
            $stripe_cust_id   = get_option($cust_option_key, '');
            if ($stripe_cust_id) {
                try {
                    $stripeCustomer = \Stripe\Customer::retrieve($stripe_cust_id);
                    if (isset($stripeCustomer->deleted) && $stripeCustomer->deleted) {
                        $stripe_cust_id = '';
                    }
                } catch (\Exception $e) {
                    $stripe_cust_id = '';
                }
            }
            if (!$stripe_cust_id) {
                $stripeCustomer = \Stripe\Customer::create([
                    'name'  => $client_row['company_name'] ?? '',
                    'email' => $client_row['email']        ?? '',
                ]);
                $stripe_cust_id = $stripeCustomer->id;
                update_option($cust_option_key, $stripe_cust_id, false);
            }

            $paymentIntent = \Stripe\PaymentIntent::create([
                'amount'      => intval($amount * 100),
                'currency'    => $stripe_currency,
                'description' => $invoice_number,
                'customer'    => $stripe_cust_id,
                'metadata'    => [
                    'invoice_id'     => $invoice_id,
                    'invoice_number' => $invoice_number,
                ],
            ]);

            return new \WP_REST_Response([
                'client_secret'     => $paymentIntent->client_secret,
                'payment_intent_id' => $paymentIntent->id,
            ], 200);

        } catch (\Stripe\Exception\CardException $e) {
            return new \WP_REST_Response(['message' => __('Card error. Please check your payment details.', 'my-easy-compta')], 400);
        } catch (\Exception $e) {
            return new \WP_REST_Response(['message' => __('Payment processing error. Please try again.', 'my-easy-compta')], 500);
        }
    }

    /**
     * Stripe webhook — handles payment_intent.succeeded as a fallback when the
     * client tab is closed before the Vue callback fires.
     */
    public function handle_stripe_webhook(\WP_REST_Request $request)
    {
        global $wpdb;

        $webhook_secret = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM %i WHERE meta_key = 'stripe_webhook_secret'", ECWP_TABLE_SETTINGS
        ));

        // Webhook secret is required — refuse unauthenticated calls.
        if (empty($webhook_secret)) {
            return new \WP_REST_Response(['error' => 'Webhook secret not configured'], 503);
        }

        $payload    = file_get_contents('php://input');
        $sig_header = isset($_SERVER['HTTP_STRIPE_SIGNATURE']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_STRIPE_SIGNATURE'])) : '';

        try {
            $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $webhook_secret);
        } catch (\Exception $e) {
            return new \WP_REST_Response(['error' => 'Invalid signature'], 400);
        }

        if ($event->type === 'payment_intent.succeeded') {
            $pi         = $event->data->object;
            $invoice_id = absint($pi->metadata->invoice_id ?? 0);

            if ($invoice_id > 0) {
                // Guard: only update if not already paid to avoid double-payments.
                $invoice = $wpdb->get_row($wpdb->prepare(
                    "SELECT id, status_stats FROM " . ECWP_TABLE_INVOICES . " WHERE id = %d",
                    $invoice_id
                ));
                if ($invoice && $invoice->status_stats !== 'paid') {
                    $this->do_mark_invoice_paid($invoice_id);
                }
            }
        }

        return new \WP_REST_Response(['received' => true], 200);
    }

    public function update_invoice_status(\WP_REST_Request $request)
    {
        if (!$this->has_valid_license()) {
            return new \WP_REST_Response(array('message' => 'License required'), 403);
        }

        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $invoice_id = absint($request->get_param('invoice_id'));
        if (empty($invoice_id)) {
            return new \WP_REST_Response('Invoice ID is required.', 400);
        }

        $result = $this->do_mark_invoice_paid($invoice_id);
        return is_wp_error($result)
            ? $result
            : new \WP_REST_Response(array('success' => true, 'message' => 'Invoice status updated.'), 200);
    }

    /**
     * Core logic to mark an invoice as paid and insert a payment record.
     * Called from both the REST endpoint (after nonce check) and the Stripe
     * webhook (after signature verification) — no auth performed here.
     */
    private function do_mark_invoice_paid(int $invoice_id)
    {
        global $wpdb;

        try {
            $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt;

            $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . ECWP_TABLE_INVOICES . " WHERE id = %d", $invoice_id));
            if (!$invoice) {
                return new \WP_Error('invoice_not_found', __('Invoice not found', 'my-easy-compta'), array('status' => 404));
            }

            $amount_invoice = floatval($encrypt->decrypt($invoice->total_amount));
            $client_currency = $wpdb->get_var($wpdb->prepare("SELECT currency_id FROM " . ECWP_TABLE_CLIENTS . " WHERE id = %d", $invoice->client_id));

            $settings = new ECWP_Settings();
            $default_currency_id = $settings->get_setting('default_currency');
            if ((int) $client_currency !== (int) $default_currency_id) {
                $exchange_rate = floatval($encrypt->decrypt($invoice->exchange_rate));
                if (!$exchange_rate) {
                    return new \WP_Error('currency_exchange_error', __('Failed to retrieve exchange rate for client currency', 'my-easy-compta'), array('status' => 500));
                }
                $amount_invoice *= $exchange_rate;
            }

            $id_stripe = $wpdb->get_var($wpdb->prepare(
                "SELECT meta_value FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
                'easy_compta_payment_method_stripe'
            ));

            $result = $wpdb->insert(
                ECWP_TABLE_PAYMENTS,
                array(
                    'invoice_id'        => $invoice_id,
                    'amount'            => $amount_invoice,
                    'payment_date'      => current_time('mysql'),
                    'client_id'         => $invoice->client_id,
                    'payment_method_id' => $id_stripe,
                ),
                array('%d', '%f', '%s', '%d', '%d')
            );

            if ($result === false) {
                return new \WP_Error('rest_db_insert_error', __('Failed to add payment to database', 'my-easy-compta'), array('status' => 500));
            }

            $total_amount = floatval($encrypt->decrypt($invoice->total_amount));
            $wpdb->update(
                ECWP_TABLE_INVOICES,
                array(
                    'stripe_payed'  => 1,
                    'status'        => $encrypt->encrypt('paid'),
                    'status_stats'  => 'paid',
                    'paid_amount'   => $total_amount,
                ),
                array('id' => $invoice_id),
                array('%d', '%s', '%s', '%f'),
                array('%d')
            );

            return true;

        } catch (\Exception $e) {
            return new \WP_Error('payment_error', __('Payment processing error. Please try again.', 'my-easy-compta'), array('status' => 500));
        }
    }

}
