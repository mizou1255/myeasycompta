<?php

namespace ECWP\Siret;

class ECWPSiret_Migrations
{
    public function plugin_activation()
    {
        $this->database_update();
    }
    public function database_update()
    {
        global $wpdb;
        $this->insert_meta_key_if_not_exists('easy_compta_siret_addon_active', 1);
        $this->insert_meta_key_if_not_exists('easycompta_siret_token_api', '11111111111-11111111111111111111111111');

        $column_id_exists = $wpdb->get_var("SHOW COLUMNS FROM " . ECWP_TABLE_CLIENTS . " LIKE 'siret_number'");

        if (!$column_id_exists) {
            $wpdb->query("ALTER TABLE " . ECWP_TABLE_CLIENTS . " ADD COLUMN siret_number VARCHAR(14) NOT NULL DEFAULT ''");
        } else {
            // Migrate existing BIGINT column to VARCHAR to support leading zeros and non-numeric SIRET
            $col_type = $wpdb->get_var($wpdb->prepare(
                "SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = 'siret_number'",
                ECWP_TABLE_CLIENTS
            ));
            if ($col_type && stripos($col_type, 'bigint') !== false) {
                $wpdb->query("ALTER TABLE " . ECWP_TABLE_CLIENTS . " MODIFY COLUMN siret_number VARCHAR(14) NOT NULL DEFAULT ''");
            }
        }

    }
    public function plugin_desactivation()
    {
        global $wpdb;
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easy_compta_siret_addon_active'));
        $wpdb->delete(ECWP_TABLE_SETTINGS, array('meta_key' => 'easycompta_siret_token_api'));
        $wpdb->query("ALTER TABLE " . ECWP_TABLE_CLIENTS . " DROP COLUMN siret_number");
    }

    private function insert_meta_key_if_not_exists($meta_key, $meta_value)
    {
        global $wpdb;
        $meta_key_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_key FROM " . ECWP_TABLE_SETTINGS . " WHERE meta_key = %s",
            $meta_key
        ));

        if (null === $meta_key_exists) {
            $wpdb->insert(ECWP_TABLE_SETTINGS, array(
                'meta_key' => $meta_key,
                'meta_value' => $meta_value,
            ));
        } else {
            $wpdb->update(
                ECWP_TABLE_SETTINGS,
                array('meta_value' => $meta_value),
                array('meta_key' => $meta_key),
                array('%s'),
                array('%s')
            );
        }
    }
}
