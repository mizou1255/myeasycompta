<?php

namespace ECWP\Siret;

use ECWP\Admin\Settings\ECWP_Settings;
use ECWP\API\Routes;

class ECWPSiret_APP
{
    protected $routes;

    public function __construct()
    {
        $this->routes = new Routes();
        $this->register_api_routes();
    }

    /**
     * @return [type]
     */
    public function register_api_routes()
    {
        $this->routes->add_route('fetch-company-info/(?P<siret>\d+)', 'GET', $this, 'fetch_company_info', function () {
            return current_user_can('manage_options');
        });

        $this->routes->register_routes();
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    function fetch_company_info($request)
    {
        if (!$this->has_valid_license()) {
            return new \WP_Error('rest_forbidden', __('License required', 'my-easy-compta'), array('status' => 403));
        }

        $nonce = sanitize_text_field(wp_unslash($request->get_header('X-WP-Nonce')));
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('rest_nonce_invalid', __('Invalid nonce', 'my-easy-compta'), array('status' => 403));
        }

        $siret = $request->get_param('siret');

        // A valid SIRET is exactly 14 digits. Validate strictly before using in the API URL.
        if (!preg_match('/^\d{14}$/', (string) $siret)) {
            return new \WP_Error('invalid_siret', __('Invalid SIRET format. Must be 14 digits.', 'my-easy-compta'), array('status' => 400));
        }

        $settings = new ECWP_Settings();
        $siret_api_token = $settings->get_setting('easycompta_siret_token_api');
        $api_url = 'https://api.insee.fr/entreprises/sirene/V3.11/siret/' . rawurlencode($siret);

        $response = wp_remote_get($api_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $siret_api_token,
            ),
        ));

        if (is_wp_error($response)) {
            return new \WP_Error('api_error', 'Error fetching company info', array('status' => 500));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);

        if (!$data || empty($data->etablissement)) {
            return new \WP_Error('no_data', 'No company data found', array('status' => 404));
        }

        $company_info = array(
            'company_name' => isset($data->etablissement->uniteLegale->denominationUniteLegale) ? $data->etablissement->uniteLegale->denominationUniteLegale : $data->etablissement->uniteLegale->nomUniteLegale,
            'manager_name' => "{$data->etablissement->uniteLegale->prenom1UniteLegale} {$data->etablissement->uniteLegale->nomUniteLegale}",
            'address' => "{$data->etablissement->adresseEtablissement->numeroVoieEtablissement} {$data->etablissement->adresseEtablissement->typeVoieEtablissement} {$data->etablissement->adresseEtablissement->libelleVoieEtablissement}",
            'postal_code' => $data->etablissement->adresseEtablissement->codePostalEtablissement,
            'city' => $data->etablissement->adresseEtablissement->libelleCommuneEtablissement,
            'siren' => $data->etablissement->siren,
        );

        return $company_info;
    }

}
