<?php
/**
 * Plugin Name: myEasyCompta - SIRET Search Addon
 * Description: The Easy-Compta SIRET plugin adds a field to quickly retrieve customer information using the French government business directory API (https://api.gouv.fr). This enhances the efficiency of managing client data within the Easy-Compta system.
 * Version: 2.0.0
 * Author: Moez BETTOUMI
 * Author URI: https://moezbettoumi.fr
 * Text Domain: my-easy-compta-siret
 * Domain Path: /languages
 * Requires at least: 5.2
 * Tested up to: 6.6.2
 * Requires PHP: 8.0
 * Tags: accounting, quotes, invoices, expenses, Vue.js, TailwindCSS
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

final class ECWP_Easy_Compta_Siret
{
    /**
     * Version du plugin
     *
     * @var string
     */
    public $version = '2.0.0';

    /**
     * Version PHP minimale requise
     *
     * @var string
     */
    private $min_php = '8.0';

    /**
     * Conteneur pour les instances de classe
     *
     * @var array
     */
    private $container = [];

    /**
     * Instance singleton
     *
     * @var ECWP_Easy_Compta_Siret
     */
    private static $instance;

    /**
     * Initialisation du plugin
     *
     * @return ECWP_Easy_Compta_Siret
     */
    public static function init()
    {
        if (!isset(self::$instance) && !(self::$instance instanceof ECWP_Easy_Compta_Siret)) {
            self::$instance = new ECWP_Easy_Compta_Siret();
            self::$instance->setup();
        }

        return self::$instance;
    }

    /**
     * Configuration initiale du plugin
     *
     * @return void
     */
    private function setup()
    {

        register_activation_hook(__FILE__, [$this, 'auto_deactivate']);

        if (!$this->is_supported_php()) {
            return;
        }

        $this->define_constants();
        $this->includes();
        $this->instantiate();
        $this->init_actions();
    }

    /**
     * Définir les constantes du plugin
     *
     * @return void
     */
    private function define_constants()
    {
        define('ECWP_SIRET_PATH', dirname(__FILE__));
        define('ECWP_SIRET_INCLUDES', ECWP_SIRET_PATH . '/includes');
        define('ECWP_SIRET_PATH_DIR', plugin_dir_path(__FILE__));
        define('ECWP_SIRET_URL', plugins_url('', __FILE__));
        if (!defined('ECWP_PRINCIPAL_PATH')) {
            define('ECWP_PRINCIPAL_PATH', WP_CONTENT_DIR . '/plugins/my-easy-compta');
        }

        define('ECWP_SIRET_SETTINGS_VAR', 'easy_compta_siret_addon_active');
    }

    /**
     * Inclure les fichiers requis
     *
     * @return void
     */
    private function includes()
    {
        require_once ECWP_PRINCIPAL_PATH . '/includes/API/Routes.php';
        require_once ECWP_SIRET_INCLUDES . '/migrations.php';
        require_once ECWP_SIRET_INCLUDES . '/App.php';
    }

    /**
     * Instancier les classes nécessaires
     *
     * @return void
     */
    private function instantiate()
    {
        $this->container['migration'] = new ECWP\Siret\ECWPSiret_Migrations();
        $this->container['app'] = new ECWP\Siret\ECWPSiret_APP();
    }

    /**
     * Initialiser les hooks d'action WordPress
     *
     * @return void
     */
    private function init_actions()
    {
        register_activation_hook(__FILE__, [$this->container['migration'], 'plugin_activation']);
        register_deactivation_hook(__FILE__, [$this->container['migration'], 'plugin_desactivation']);
        add_action('admin_init', [$this, 'check_plugin_dependencies']);
    }

    /**
     * Vérifier si la version PHP est supportée
     *
     * @return bool
     */
    public function is_supported_php()
    {
        return version_compare(PHP_VERSION, $this->min_php, '>=');
    }

    /**
     * Désactiver le plugin si la version PHP n'est pas supportée
     *
     * @return void
     */
    public function auto_deactivate()
    {
        if (!$this->is_supported_php()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'Le plugin %s nécessite PHP version %s ou supérieure.',
                        'my-easy-compta'
                    ),
                    esc_html__('myEasyCompta Siret addon', 'my-easy-compta'),
                    esc_html($this->min_php)
                ),
                esc_html__('Erreur d\'activation du plugin', 'my-easy-compta'),
                ['response' => 200, 'back_link' => true]
            );
        }
        if (!is_plugin_active('my-easy-compta/my-easy-compta.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                sprintf(
                    esc_html__(
                        'The %s plugin requires the myEasyCompta plugin to be active.',
                        'myEasyCompta Siret'
                    ),
                    esc_html__('myEasyCompta Siret', 'my-easy-compta')
                ),
                esc_html__('Plugin Activation Error', 'my-easy-compta'),
                ['response' => 200, 'back_link' => true]
            );
        }
    }
    /**
     * Check if myEasyCompta plugin are activated
     */
    public function check_plugin_dependencies()
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            add_action('admin_notices', [$this, 'display_missing_dependencies_notice']);
            deactivate_plugins(plugin_basename(__FILE__));
        }
    }

    /**
     * Display a notice if myEasyCompta plugin are not activated
     */
    public function display_missing_dependencies_notice()
    {?>
<div class="notice notice-error is-dismissible">
    <p><?php _e('myEasyCompta Siret requires the myEasyCompta plugin to be activated. Please activate them before activating this plugin.', 'my-easy-compta');?>
    </p>
</div>
<?php
}
}

/**
 * Initialiser le plugin Mon_Plugin_Compta
 *
 * @return ECWP_Easy_Compta_Siret
 */

ECWP_Easy_Compta_Siret::init();