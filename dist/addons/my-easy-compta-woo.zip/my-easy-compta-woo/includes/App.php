<?php
namespace ECWP\Woo;

use ECWP\Admin\Settings\ECWP_Settings;

class ECWPWoo_APP
{
    public function __construct()
    {
        if ($this->has_valid_license()) {
            add_action('woocommerce_thankyou', array($this, 'generate_invoice'), 10, 1);
            add_action('externe_article_results', array($this, 'add_woocommerce_products_to_results'), 10, 2);
            add_action('woocommerce_order_status_changed', array($this, 'update_invoice_status_on_order_completed'), 10, 4);
        }
    }

    public function has_valid_license()
    {
        $license_data = get_option('ecwp_client_license_data');
        return is_array($license_data) && !empty($license_data['valid']);
    }

    public function generate_invoice($order_id)
    {
        if (!class_exists('ECWP_Easy_Compta')) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        $order = wc_get_order($order_id);
        $customer_id = $order->get_customer_id();
        $currency_code = $order->get_currency();
        $currency_symbol = html_entity_decode(get_woocommerce_currency_symbol($currency_code), ENT_QUOTES, 'UTF-8');

        $company_name = $order->get_billing_company();
        if (empty($company_name)) {
            $company_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
        }

        $customer_data = [
            'company_name' => $company_name,
            'manager_name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            'email' => $order->get_billing_email(),
            'phone' => $order->get_billing_phone(),
            'address' => $order->get_billing_address_1(),
            'city' => $order->get_billing_city(),
            'postal_code' => $order->get_billing_postcode(),
            'country' => $order->get_billing_country(),
            'currency_id' => 1,
        ];

        global $wpdb;
        $currency_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . ECWP_TABLE_CURRENCY . " WHERE symbol = %s", $currency_symbol));
        if ($currency_id) {
            $customer_data['currency_id'] = $currency_id;
        }

        $client_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . ECWP_TABLE_CLIENTS . " WHERE email = %s", $customer_data['email']));

        if (!$client_id) {
            $wpdb->insert(ECWP_TABLE_CLIENTS, $customer_data);
            $client_id = $wpdb->insert_id;
        }

        $settings = new ECWP_Settings;
        $invoice_prefix = $settings->get_setting('invoice_prefix');

        if (!$invoice_prefix) {
            $invoice_prefix = 'INV_';
        }

        $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();

        $order_status = $order->get_status();
        if ($order_status === 'completed' || $order_status === 'processing') {
            $invoice_status = 'paid';
            $due_date = current_time('mysql');
        } else {
            $invoice_status = 'unpaid';
            $due_date = wp_date('Y-m-d H:i:s', strtotime('+1 week'));
        }

        $total_without_tax = $order->get_total() - $order->get_total_tax();
        $total_with_tax = $order->get_total();

        $shipping_methods = $order->get_shipping_methods();
        $shipping_amount = 0;

        foreach ($shipping_methods as $shipping_method) {
            $shipping_total = $shipping_method->get_total();
            $shipping_tax = $shipping_method->get_total_tax();

            if ($shipping_method->get_taxes() && $shipping_tax > 0) {
                $shipping_amount += $shipping_total + $shipping_tax;
            } else {
                $shipping_amount += $shipping_total;
            }
        }

        $default_vat_rate = 0;
        $vat_active = $settings->get_setting('vat_active');
        if ($vat_active == 1) {
            $default_vat_id = $settings->get_setting('default_vat');
            $default_vat_rate = $wpdb->get_var($wpdb->prepare(
                "SELECT rate FROM %i WHERE id = %d",
                ECWP_TABLE_VATS,
                $default_vat_id
            ));
        }

        $wpdb->query('START TRANSACTION');

        $last_invoice_id = (int) $wpdb->get_var("SELECT MAX(number) FROM " . ECWP_TABLE_INVOICES . " FOR UPDATE");
        if ($last_invoice_id <= 0) {
            $first = (int) $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM %i WHERE meta_key = 'invoice_first'", ECWP_TABLE_SETTINGS));
            $last_invoice_id = $first > 0 ? $first : 1;
        } else {
            $last_invoice_id += 1;
        }

        $invoice_number = $invoice_prefix . '-' . str_pad($last_invoice_id, 4, '0', STR_PAD_LEFT);

        $invoice_data = [
            'client_id'       => $client_id,
            'amount'          => $encrypt->encrypt($total_without_tax),
            'total_amount'    => $encrypt->encrypt($total_with_tax),
            'paid_amount'     => ($invoice_status === 'paid') ? $total_with_tax : 0,
            'status'          => $encrypt->encrypt($invoice_status),
            'status_stats'    => $invoice_status,
            'due_date'        => $due_date,
            'created_at'      => current_time('mysql'),
            'source'          => 'WooCommerce',
            'invoice_number'  => $encrypt->encrypt($invoice_number),
            'number'          => $last_invoice_id,
            'order_id'        => $order->get_id(),
            'shipping_amount' => $encrypt->encrypt($shipping_amount),
        ];

        $wpdb->insert(ECWP_TABLE_INVOICES, $invoice_data);
        $invoice_id = $wpdb->insert_id;

        if (!$invoice_id) {
            $wpdb->query('ROLLBACK');
            error_log('myEasyCompta WooCommerce: Failed to insert invoice for order ' . $order_id);
            return;
        }

        if ($invoice_status === 'paid') {
            $client_currency = $wpdb->get_var($wpdb->prepare("SELECT currency_id FROM " . ECWP_TABLE_CLIENTS . " WHERE id = %d", $client_id));
            $default_currency_id = $settings->get_setting('default_currency');
            $amount_invoice = $total_with_tax;

            if ($client_currency && $client_currency != $default_currency_id) {
                $exchange_rate_raw = $wpdb->get_var($wpdb->prepare("SELECT exchange_rate FROM " . ECWP_TABLE_INVOICES . " WHERE id = %d", $invoice_id));
                $exchange_rate = $exchange_rate_raw ? floatval($encrypt->decrypt($exchange_rate_raw)) : 1;
                if ($exchange_rate > 0) {
                    $amount_invoice *= $exchange_rate;
                }
            }

            $wpdb->insert(
                ECWP_TABLE_PAYMENTS,
                array(
                    'invoice_id'        => $invoice_id,
                    'amount'            => $amount_invoice,
                    'payment_date'      => current_time('mysql'),
                    'client_id'         => $client_id,
                    'payment_method_id' => 1,
                ),
                array('%d', '%f', '%s', '%d', '%d')
            );
        }

        $items = $order->get_items();
        $item_order = 1;
        foreach ($items as $item) {
            $item_quantity = $item->get_quantity();

            $product = $item->get_product();

            if ($product) {
                $item_sku = $product->get_sku();
                $item_description = $product->get_description();
                $unit_price = $product->get_price();
            } else {
                $item_sku = '';
                $item_description = '';
                $unit_price = 0;
            }
            $total_price = $unit_price * $item_quantity;
            $vat_rate_total = ($total_price * $default_vat_rate) / 100;
            $total_amount = $vat_rate_total + $total_price;

            $inserted = $wpdb->insert(ECWP_TABLE_INVOICE_ELEMENTS, [
                'invoice_id'      => $invoice_id,
                'item_name'       => $encrypt->encrypt($item->get_name()),
                'item_ref'        => $encrypt->encrypt($item_sku),
                'item_description'=> $encrypt->encrypt($item_description),
                'quantity'        => $encrypt->encrypt($item_quantity),
                'vat_rate'        => $encrypt->encrypt($default_vat_rate),
                'unit_price'      => $encrypt->encrypt($unit_price),
                'total_price'     => $encrypt->encrypt($total_price),
                'total_amount'    => $encrypt->encrypt($total_amount),
                'item_order'      => $item_order++,
            ]);

            if ($inserted === false) {
                $wpdb->query('ROLLBACK');
                error_log('myEasyCompta WooCommerce: Failed to insert invoice item for order ' . $order_id);
                return;
            }
        }

        $wpdb->query('COMMIT');
    }

    public function add_woocommerce_products_to_results(&$results, $search)
    {
        if (!class_exists('WooCommerce')) {
            return;
        }
        $args = [
            'limit' => 10,
            'status' => 'publish',
            's' => $search,
            'return' => 'objects',
        ];

        $product_query = new \WC_Product_Query($args);
        $products = $product_query->get_products();

        foreach ($products as $product) {
            $results[] = [
                'name' => $product->get_name(),
                'ref' => $product->get_sku(),
                'description' => $product->get_description(),
                'unit_price' => $product->get_price(),
            ];
        }
    }

    public function update_invoice_status_on_order_completed($order_id, $old_status, $new_status, $order)
    {
        if ($new_status === 'completed') {
            global $wpdb;

            $invoice = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM %i WHERE order_id = %d",
                ECWP_TABLE_INVOICES,
                $order_id
            ));

            if ($invoice) {
                $encrypt = new \ECWP\Admin\Encrypt\ECWP_Encrypt();
                $total_amount = floatval($encrypt->decrypt($invoice->total_amount));

                $wpdb->update(
                    ECWP_TABLE_INVOICES,
                    [
                        'status'       => $encrypt->encrypt('paid'),
                        'status_stats' => 'paid',
                        'paid_amount'  => $total_amount,
                    ],
                    ['id' => $invoice->id]
                );

                // Insert payment record if not already present
                $payment_exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM %i WHERE invoice_id = %d",
                    ECWP_TABLE_PAYMENTS,
                    $invoice->id
                ));

                if (!$payment_exists) {
                    $wpdb->insert(
                        ECWP_TABLE_PAYMENTS,
                        [
                            'invoice_id'        => $invoice->id,
                            'amount'            => $total_amount,
                            'payment_date'      => current_time('mysql'),
                            'client_id'         => $invoice->client_id,
                            'payment_method_id' => 1,
                        ],
                        ['%d', '%f', '%s', '%d', '%d']
                    );
                }
            }
        }
    }
}
