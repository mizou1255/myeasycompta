<?php
if (!defined('ABSPATH')) {
    exit;
}

function run_migration_woo_1_1_0()
{
    global $wpdb;

    $meta_key_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT meta_key FROM %i WHERE meta_key = %s", ECWP_TABLE_SETTINGS,
        'easy_compta_woo_addon_active'
    ));

    if (null === $meta_key_exists) {
        $wpdb->insert(ECWP_TABLE_SETTINGS, array(
            'meta_key' => 'easy_compta_woo_addon_active',
            'meta_value' => 1,
        ));
    }

    $column_order_id = $wpdb->get_var(
        $wpdb->prepare(
            "SHOW COLUMNS FROM %i LIKE %s",
            ECWP_TABLE_INVOICES, 'order_id'
        )
    );

    if (is_null($column_order_id)) {
        $wpdb->query($wpdb->prepare(
            "ALTER TABLE %i ADD COLUMN `order_id` VARCHAR(255) NOT NULL AFTER `source`",
            ECWP_TABLE_INVOICES
        ));
    }

    $column_shipping = $wpdb->get_var(
        $wpdb->prepare(
            "SHOW COLUMNS FROM %i LIKE %s",
            ECWP_TABLE_INVOICES, 'shipping_amount'
        )
    );

    if (is_null($column_shipping)) {
        $wpdb->query($wpdb->prepare(
            "ALTER TABLE %i ADD COLUMN `shipping_amount` VARCHAR(255) NOT NULL AFTER `source`",
            ECWP_TABLE_INVOICES
        ));
    }
}
